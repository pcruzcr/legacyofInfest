# EP1 — El Gran Shaman Paburu (Stage 4-2)

**Alejandro Josué Rodríguez Zamora**
Computación Gráfica y PDI I — Universidad Invenio
Evaluación Práctica I — Prototipo Funcional (15%)

---

## Cómo correrlo

Este ZIP contiene **solo mis archivos**. Las rutas replican las del
repositorio: se descomprime **encima de la raíz de `legacyofInfest`** y todo
queda en su lugar, sin mover nada a mano.

```bash
python main.py --boss boss_paburu
```

En Windows también sirve doble clic en `jugar_paburu.bat`, incluido acá: busca
un Python que tenga las dependencias y, si no encuentra ninguno, ofrece crear
el entorno solo.

Requiere **Python 3.12** — el `requirements.txt` del curso no instala en 3.13
ni en 3.14.

**Teclas 1, 2, 3 y 4:** cambian de forma en vivo. EP1 implementa la Forma 1;
las otras tres están cargadas con su hoja de sprites y su iluminación, pero en
partida normal el boss todavía no baja de fase, así que sin estas teclas no
habría manera de verlas.

**`REPORTE_MOTOR.md`** va en la raíz de este ZIP. **No es parte de EP1**:
registra los 29 bugs del motor que aparecieron construyendo este stage y que
se corrigieron con permiso explícito del profesor. Se adjunta como evidencia
del trabajo, no como entregable de la evaluación.

---

**`REPORTE_MOTOR.md`** va en la raíz de este ZIP. **No es parte de EP1**:
registra los 29 bugs del motor que aparecieron construyendo este stage y
que se corrigieron con permiso explícito del profesor. Se adjunta como
evidencia del trabajo, no como entregable de la evaluación.

---

## Dónde está cada cosa

### El código — `src/stages/boss_paburu/`

| Archivo | Qué hace |
|---|---|
| `boss_paburu.py` | La entidad. Hereda de `BossBase`, declara las 4 formas, lleva el reloj de ataques y dibuja el cuerpo con su aura espectral. |
| `form1_attacks.py` | Los tres ataques de la Forma 1: `STONE_SPIT` (balística), `EYE_BEAM` (rayo) y `EL SELLO` (columnas + ánimas). Acá viven las fórmulas de vectores y curvas. |
| `boss_paburu_scene.py` | La escena. Hereda de `StageScene`, monta la iluminación de los cuencos de fuego y sube la luz ambiente con cada forma. |
| `arena.py` | Constantes de la arena: límites, altura del suelo, paleta. Un solo sitio donde cambiar la geometría. |
| `sprites.py` | Carga las hojas de sprites. Si falta una, devuelve lista vacía y el boss dibuja su placeholder gris — así el juego corre con el arte a medio hacer. |
| `intro.py` | La secuencia de entrada: penumbra, cuencos, la forma real de Paburu, su diálogo y la transformación en piedra. Hereda de `CutsceneAction` del framework. |
| `guardianes.py` | Los tres espíritus del cielo. Se mueven con trayectorias de Lissajous y aparecen recién en la Forma 2. |
| `__init__.py` | Marca el paquete. |

### La documentación — misma carpeta

| Archivo | Qué es |
|---|---|
| `README.md` | **El entregable de documentación.** Es el `README_template.md` completado: concepto, patrones de ataque, transiciones de fase, las fórmulas exactas de vectores y curvas, el Z-order, y el mapeo de cada mecánica a su unidad del curso. |
| `GDD.md` | Documento de diseño completo del jefe: lore, las 4 formas, todos los movesets y el roadmap de las tres entregas. |
| `ARTE.md` | Guía para dibujar los sprites a mano: tamaños, nombres de archivo y anatomía de cada forma. |
| `referencia_arte.png` | La referencia visual del espíritu. |

### Los assets

| Ruta | Qué es |
|---|---|
| `assets/maps/boss_paburu/boss_paburu.tmx` | El mapa. Arena de 800×608, las 8 capas obligatorias, `PlayerSpawn` + `Checkpoint` + `NextTrigger`, y la geometría de colisión: 6 sólidos, 4 plataformas one-way y 2 refugios. |
| `assets/tilesets/tileset_paburu.png` | Tileset propio, 64 tiles de 16×16: losas, lápidas, cruces, obeliscos, cuencos de fuego, columnas, arcos, cornisas y siluetas de fondo. |
| `assets/backgrounds/paburu/` | Los tres planos de parallax: cielo con luna, los guardianes espectrales, y el cementerio en silueta. |
| `assets/sprites/boss_paburu/` | Las hojas del boss: piedra, daño, golpe, grieta, máscara, las dos reliquias y el espíritu. |

### Los generadores — `tools/`

Todo el arte y el mapa se generan por código, **sin `random`**: mismo código,
mismo archivo, siempre. Eso los hace reproducibles y auditables.

| Archivo | Genera |
|---|---|
| `gen_paburu_tmx.py` | El mapa completo, capa por capa. |
| `gen_paburu_tileset.py` | El tileset. |
| `gen_paburu_fondos.py` | Los tres fondos de parallax. |
| `gen_paburu_art.py` | Las hojas de la Forma 1. |
| `gen_paburu_art_formas.py` | Las hojas de las Formas 2, 3 y 4. |

---

## Los requisitos, y dónde se cumplen

| Requisito | Dónde |
|---|---|
| Vectores con `math_utils` | `form1_attacks.py:139` — `vec2_distance` calcula el tiempo de vuelo de la piedra. `:486` — `vec2_normalize` da el rumbo del ánima. `:492` — la distancia al centro la desvanece. |
| Curvas con `CurveTools` | `form1_attacks.py:468` — `catmull_rom` construye la trayectoria del ánima. `:480` — `sample_path` la recorre. |
| Representación gráfica y Z-order | `boss_paburu.py:452` — el Z-order interno en 4 capas. El TMX usa las 8 capas con tiles reales del tileset propio, no placeholders. |
| Corre sin errores | `main.py --boss boss_paburu` arranca y se juega sin un solo traceback en consola. |

---

## Alcance de EP1

Implementado y jugable: la **Forma 1** completa con sus tres ataques, la barra
de vida del boss y la transición 1→2.

Las Formas 2, 3 y 4 están **declaradas** y se ven con las teclas 1-4, pero sus
mecánicas corresponden a EP2 y EP3 según el roadmap del `GDD.md` (§7).
