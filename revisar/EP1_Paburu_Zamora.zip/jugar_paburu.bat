@echo off
rem ============================================================
rem  Legacy of InFest - Stage 4-2: El Gran Shaman Paburu
rem  Doble clic para jugar el boss directamente.
rem
rem  Busca un Python que tenga las dependencias instaladas.
rem  Si no encuentra ninguno, ofrece crear un venv con 3.12
rem  (el requirements del profesor NO instala en 3.13/3.14).
rem ============================================================
setlocal EnableDelayedExpansion
title Legacy of InFest - Paburu (Stage 4-2)
cd /d "%~dp0"

set "PY="

rem --- 1) venv del proyecto -----------------------------------
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import pygame,pytmx,pyscroll" >nul 2>&1
    if not errorlevel 1 set "PY=.venv\Scripts\python.exe"
)

rem --- 2) venv propio de 3.12 ---------------------------------
if not defined PY if exist ".venv312\Scripts\python.exe" (
    ".venv312\Scripts\python.exe" -c "import pygame,pytmx,pyscroll" >nul 2>&1
    if not errorlevel 1 set "PY=.venv312\Scripts\python.exe"
)

rem --- 3) Python del sistema ----------------------------------
if not defined PY (
    for %%P in ("py -3.12" "py -3.11" "python") do (
        if not defined PY (
            %%~P -c "import pygame,pytmx,pyscroll" >nul 2>&1
            if not errorlevel 1 set "PY=%%~P"
        )
    )
)

rem --- 4) nada sirve: ofrecer instalar ------------------------
if not defined PY (
    echo.
    echo   No encontre ningun Python con las dependencias del proyecto.
    echo.
    py -3.12 --version >nul 2>&1
    if errorlevel 1 (
        echo   Tampoco tenes Python 3.12 instalado.
        echo   Instalalo desde https://www.python.org/downloads/release/python-3129/
        echo   ^(marca "Add python.exe to PATH"^) y volve a correr este archivo.
        echo.
        pause
        exit /b 1
    )
    echo   Si tenes Python 3.12. Puedo crear el entorno .venv312 e instalar
    echo   todo lo del requirements.txt. Tarda unos minutos, una sola vez.
    echo.
    choice /c SN /m "Lo creo ahora"
    if errorlevel 2 exit /b 1
    echo.
    echo   Creando .venv312 ...
    py -3.12 -m venv .venv312 || goto :fallo
    echo   Instalando dependencias ...
    ".venv312\Scripts\python.exe" -m pip install --upgrade pip
    ".venv312\Scripts\python.exe" -m pip install -r requirements.txt || goto :fallo
    set "PY=.venv312\Scripts\python.exe"
    echo.
    echo   Listo. Arrancando el boss.
    echo.
)

rem --- 5) a jugar ---------------------------------------------
echo   Interprete: !PY!
echo   Corriendo: main.py --boss boss_paburu
echo.
!PY! main.py --boss boss_paburu
set "CODE=%errorlevel%"
if not "%CODE%"=="0" (
    echo.
    echo   El juego termino con codigo %CODE%. El error esta arriba.
    pause
)
exit /b %CODE%

:fallo
echo.
echo   Fallo la instalacion. Copiame el error de arriba.
pause
exit /b 1
