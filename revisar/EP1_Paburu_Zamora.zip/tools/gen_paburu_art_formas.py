"""
Generador del arte de idle de las Formas 2, 3A/3B y 4 de Paburu.

Escribe en `assets/sprites/boss_paburu/`:

    boss_paburu_mask.png    6f · 56×72 · Forma 2 — La Máscara Espectral
    boss_paburu_gold.png    6f · 32×32 · Forma 3A — La Pepita
    boss_paburu_black.png   6f · 32×32 · Forma 3B — La Perla
    boss_paburu_spirit.png  8f · 64×80 · Forma 4 — El Espíritu del Shaman

Ejecutar desde la raíz del proyecto:  python tools/gen_paburu_art_formas.py

ALCANCE: esto es **solo arte de idle**. Las mecánicas de las Formas 2-4
llegan en EP2/EP3 según el roadmap del GDD §7 — hoy esas formas están
declaradas, transicionan y reciben daño, pero no atacan ni se mueven.

Restricción que manda sobre todo lo demás: el juego corre a 800×600 con
escala 1:1. La Forma 4 mide 64×80 px en pantalla, o sea el 13 % del alto.
A esa escala sobreviven tres cosas y ninguna más — la silueta, una forma
firma reconocible, y el contraste de color. Los rasgos finos (rostro,
pliegues, filigrana) se pierden y no se intentan.

Mismas técnicas que `gen_paburu_art.py`, mismo mapeo académico:
  - Unidad V  — rampas de tono cuantizadas, paleta canónica del Asset Bible.
  - Unidad VI — ruido de valor con smoothstep para textura y disolución.
Determinista: mismo código, mismo PNG. No hay `random`.
"""
from __future__ import annotations

import math
import os
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

OUT_DIR = Path("assets/sprites/boss_paburu")

# ── Paleta (Asset Bible, GDD §3.1) ────────────────────────────────
SPECTRAL_HI = (170, 255, 210)
SPECTRAL = (0, 200, 100)
SPECTRAL_MID = (24, 150, 88)
SPECTRAL_DK = (16, 92, 60)

GOLD_HI = (255, 230, 150)
GOLD = (232, 177, 44)
GOLD_DK = (150, 112, 30)

PEARL = (13, 13, 20)
PEARL_MID = (44, 42, 62)
PEARL_RIM = (150, 142, 180)

STONE_HI = (200, 195, 184)
STONE = (156, 150, 138)
STONE_DK = (96, 92, 84)
STONE_BLACK = (44, 42, 40)

ROBE_HI = (252, 246, 220)
ROBE = (228, 216, 176)
ROBE_SH = (176, 162, 124)
ROBE_DK = (120, 110, 84)
FACE = (206, 200, 180)
FACE_SH = (150, 144, 126)
FACE_DK = (72, 68, 58)
EYE_WHITE = (255, 255, 245)
GLOW = (255, 240, 190)


def _hash(x: int, y: int, s: int = 0) -> float:
    n = (x * 374761393 + y * 668265263 + s * 982451653) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 0xFFFF


def _put(s: pygame.Surface, x: int, y: int, c: tuple[int, ...]) -> None:
    if 0 <= x < s.get_width() and 0 <= y < s.get_height():
        s.set_at((x, y), c)


def _rim_glow(sp: pygame.Surface, color: tuple[int, int, int],
              alpha: int = 90, density: float = 0.45) -> pygame.Surface:
    """Halo irregular de 1 px. Sin él, una figura de luz se lee como estatua."""
    w, h = sp.get_size()
    out = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(h):
        for x in range(w):
            if sp.get_at((x, y)).a:
                continue
            near = any(
                0 <= x + dx < w and 0 <= y + dy < h and sp.get_at((x + dx, y + dy)).a
                for dy in (-1, 0, 1) for dx in (-1, 0, 1)
            )
            if near and _hash(x, y, 9) > density:
                out.set_at((x, y), (*color, alpha))
    out.blit(sp, (0, 0))
    return out


def save_sheet(frames: list[pygame.Surface], name: str, fw: int, fh: int) -> None:
    sheet = pygame.Surface((fw * len(frames), fh), pygame.SRCALPHA)
    for i, f in enumerate(frames):
        sheet.blit(f, (i * fw, 0))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / name
    pygame.image.save(sheet, str(path))
    print(f"  {path}  {len(frames)}f  {fw}x{fh}")


# ══════════════════════════════════════════════════════════════════
#  FORMA 2 — "La Máscara Espectral"  56×72
# ══════════════════════════════════════════════════════════════════
# Canon §6.4: figura espectral de energía verde; donde iría el rostro,
# una máscara Tilawa flotante y translúcida. La máscara es el punto
# débil (hurtbox 40×40 en EP2), así que visualmente tiene que ser lo
# más sólido y contrastado del sprite: el jugador debe saber a dónde
# pegarle de un vistazo. El cuerpo es deliberadamente difuso.

MW, MH = 56, 72
MCX = 28


def build_mask(frame: int) -> pygame.Surface:
    s = pygame.Surface((MW, MH), pygame.SRCALPHA)
    ph = frame / 6 * 2 * math.pi

    # Cuerpo: cintas verticales de energía, NO ruido por píxel.
    # Un cutoff aleatorio pixel a pixel se lee como estática de TV; lo que
    # da sensación de fluido son pocas cintas continuas que ondulan y se
    # acortan a distinta altura.
    for i in range(7):
        u = (i - 3) / 3.0                     # -1 .. 1
        length = MH - int(abs(u) * 22) - 4    # las de los costados, más cortas
        for y in range(26, length):
            t = (y - 26) / max(length - 26, 1)
            sway = math.sin(y * 0.26 + ph + i * 0.9) * (1.6 + t * 2.4)
            x = int(MCX + u * (12 - t * 5) + sway)
            w = 2 if abs(u) < 0.5 else 1
            for dx in range(-w, w + 1):
                if t > 0.82 and (y + i) % 2:
                    continue                  # solo el final se deshilacha
                c = SPECTRAL if dx == 0 else (SPECTRAL_MID if abs(dx) == 1 else SPECTRAL_DK)
                if abs(u) < 0.35 and dx == 0 and (y + i * 3) % 9 == 0:
                    c = SPECTRAL_HI
                _put(s, x + dx, y, c)

    # Hombros: dos volutas que enmarcan la máscara.
    for sgn in (-1, 1):
        for k in range(11):
            x = MCX + sgn * (11 + k)
            y = 28 + int(k * k * 0.13) + int(math.sin(k * 0.5 + ph))
            _put(s, x, y, SPECTRAL)
            _put(s, x, y + 1, SPECTRAL_MID)
            _put(s, x, y + 2, SPECTRAL_DK)

    # Máscara Tilawa: 40×40 nominal, dibujada 34×30 con el resto de aire.
    mx0, my0 = MCX - 17, 6
    for y in range(my0, my0 + 30):
        for x in range(mx0, mx0 + 34):
            ny = (y - my0) / 30
            hw = 17 - (0 if ny < 0.62 else (ny - 0.62) * 26)
            if abs(x - MCX) > hw:
                continue
            c = STONE if x < MCX else STONE_DK
            if ny < 0.12:
                c = STONE_HI
            _put(s, x, y, c)
    # Borde tallado
    for x in range(mx0, mx0 + 34):
        _put(s, x, my0, STONE_BLACK)
    # Greca de la frente
    for x in range(MCX - 14, MCX + 15, 5):
        _put(s, x, my0 + 4, STONE_BLACK)
        _put(s, x + 1, my0 + 5, STONE_BLACK)
        _put(s, x, my0 + 6, STONE_HI)
    # Ojos: huecos con luz espectral adentro
    for sgn in (-1, 1):
        ex = MCX + (4 if sgn > 0 else -12)
        for y in range(my0 + 11, my0 + 16):
            for x in range(ex, ex + 8):
                _put(s, x, y, STONE_BLACK)
        for x in range(ex + 1, ex + 7):
            _put(s, x, my0 + 12, SPECTRAL_HI)
            _put(s, x, my0 + 13, SPECTRAL)
    # Colmillos: la boca de la máscara
    for x in range(MCX - 10, MCX + 11):
        _put(s, x, my0 + 21, STONE_BLACK)
    for x in range(MCX - 8, MCX + 9, 4):
        _put(s, x, my0 + 22, STONE_HI)
        _put(s, x, my0 + 23, STONE)
    return s


# ══════════════════════════════════════════════════════════════════
#  FORMA 3A / 3B — las reliquias  32×32
# ══════════════════════════════════════════════════════════════════
# Canon §6.5: esferas. A 32×32 una esfera es casi todo el sprite, así
# que lo que las distingue no es la forma sino el COMPORTAMIENTO de la
# luz: la Pepita irradia hacia afuera, La Perla absorbe y solo devuelve
# un borde. Es la misma lectura que en el concept art.

def build_relic(frame: int, gold: bool) -> pygame.Surface:
    n = 32
    s = pygame.Surface((n, n), pygame.SRCALPHA)
    c = 15.5
    ph = frame / 6 * 2 * math.pi
    r = 10.5 + math.sin(ph) * 0.6

    for y in range(n):
        for x in range(n):
            d = math.hypot(x - c, y - c)
            if d > r:
                continue
            # Terminador esférico: luz desde arriba-izquierda.
            lam = ((c - x) * 0.5 + (c - y) * 0.7) / r
            if gold:
                col = GOLD_HI if lam > 0.45 else (GOLD if lam > -0.15 else GOLD_DK)
            else:
                col = PEARL_MID if lam > 0.55 else PEARL
            _put(s, x, y, col)

    if gold:
        # Corona radiante: 8 destellos que laten (RELIC_SURGE en EP3).
        for i in range(8):
            a = ph * 0.5 + i * math.pi / 4
            for k in range(2, 5):
                d = r + k + math.sin(ph + i) * 0.8
                _put(s, int(c + math.cos(a) * d), int(c + math.sin(a) * d),
                     GOLD_HI if k < 3 else GOLD)
        _put(s, int(c - 3), int(c - 3), (255, 255, 240))
    else:
        # Borde perlado: sin esto, negro sobre cementerio negro no existe.
        for y in range(n):
            for x in range(n):
                d = math.hypot(x - c, y - c)
                if r < d <= r + 1.2:
                    _put(s, x, y, PEARL_RIM)
        for i in range(5):
            a = -ph * 0.4 + i * 2 * math.pi / 5
            _put(s, int(c + math.cos(a) * (r - 3)), int(c + math.sin(a) * (r - 3)),
                 (110, 104, 140))
    return s


# ══════════════════════════════════════════════════════════════════
#  FORMA 4 — "El Espíritu del Shaman"  64×80
# ══════════════════════════════════════════════════════════════════
# Traducción directa del concept art. De la ilustración sobreviven la
# silueta (manto ancho — angosto se lee como cono, no como manto), la
# corona de greca escalonada, y las dos reliquias en las manos, que es
# lo que cuenta la historia entera de la forma sin una línea de diálogo.
# El rostro son 12×13 px: dos píxeles blancos y una mancha oscura.

SW, SH = 64, 80
SCX = 32


def _robe_hw(y: int) -> float:
    if y < 26:
        return 0.0
    if y < 30:
        return 11 + (y - 26) * 1.2
    if y < 46:
        return 16.0
    if y < 64:
        return 16 - (y - 46) * 0.52
    if y < 74:
        return 7 - (y - 64) * 0.30
    return max(0.0, 4.0 - (y - 74) * 0.8)


def build_spirit(frame: int) -> pygame.Surface:
    s = pygame.Surface((SW, SH), pygame.SRCALPHA)
    ph = frame / 8 * 2 * math.pi

    # Manto
    for y in range(26, SH):
        hw = _robe_hw(y)
        if hw <= 0:
            continue
        off = math.sin(y * 0.22 + ph) * 1.6
        for x in range(int(SCX - hw + off), int(SCX + hw + off) + 1):
            t = (x - (SCX + off)) / max(hw, 1)
            nz = _hash(x, y, 3)
            if y > 68 and nz < 0.5:
                continue
            if t < -0.55:
                c = ROBE_HI
            elif t < 0.1:
                c = ROBE
            elif t < 0.6:
                c = ROBE_SH
            else:
                c = ROBE_DK
            if (x + int(off)) % 7 == 0 and nz > 0.4:
                c = ROBE_HI
            _put(s, x, y, c)

    # Banda ceremonial vertical con greca
    for y in range(30, 62):
        for x in range(SCX - 4, SCX + 5):
            _put(s, x, y, ROBE_HI if x < SCX - 2 else (ROBE if x < SCX + 3 else ROBE_SH))
    for y in range(32, 60, 7):
        for x in range(SCX - 3, SCX + 4):
            _put(s, x, y, GOLD_DK)
        _put(s, SCX - 3, y + 1, GOLD_DK)
        _put(s, SCX + 3, y + 2, GOLD_DK)
        _put(s, SCX + 3, y + 1, GOLD)
        _put(s, SCX - 3, y + 2, GOLD)

    # Cinturón
    for x in range(SCX - 12, SCX + 13):
        _put(s, x, 44, GOLD_DK)
        _put(s, x, 45, GOLD)
        _put(s, x, 46, GOLD_DK)
    for x in (SCX - 9, SCX - 3, SCX + 3, SCX + 9):
        _put(s, x, 45, GOLD_HI)

    # Brazos abiertos, con la mano dorada al final
    for sgn in (-1, 1):
        for k in range(15):
            x = SCX + sgn * (13 + k)
            y = 33 + int(k * 0.42) + int(math.sin(k * 0.35 + ph) * 0.7)
            for dy in range(4):
                _put(s, x, y + dy,
                     ROBE_HI if dy == 0 else (ROBE if dy < 3 else ROBE_SH))
        xw = SCX + sgn * 26
        for dy in range(5):
            for dx in range(-3, 4):
                _put(s, xw + dx, 40 + dy, GOLD if 1 <= dy <= 3 else GOLD_DK)
        for dx in range(-3, 4):
            _put(s, xw + dx, 45, ROBE_HI)

    # Pectoral
    for y in range(24, 31):
        hw = 14 - abs(y - 27)
        for x in range(SCX - hw, SCX + hw + 1):
            _put(s, x, y, GOLD_HI if y == 24 else (GOLD if y < 28 else GOLD_DK))
    for x in range(SCX - 10, SCX + 11, 5):
        _put(s, x, 27, GOLD_DK)
        _put(s, x, 28, GOLD_HI)

    # ── Rostro ────────────────────────────────────────────────────
    # El rostro de la Forma 4 es el ÚNICO momento en que Paburu se muestra
    # como fue en vida (GDD §2.1: "juzga como él mismo, cara a cara"). Las
    # otras tres formas son máscaras: piedra, madera y reliquia.
    #
    # Por eso acá hay rasgos y no una cara genérica: barba cerrada, bigote,
    # cejas marcadas y el pelo peinado hacia atrás bajo la corona. A 64×80
    # ninguno de esos rasgos es un retrato —son cuatro píxeles cada uno—,
    # pero bastan para que se lea "un hombre" y no "una figura". Es un
    # homenaje al autor del personaje.
    #
    # Los ojos quedan BLANCOS y sin pupila (canon §6.6): es lo único que
    # recuerda que ya no está vivo.
    for y in range(12, 25):
        hw = 7 if y < 21 else 6
        for x in range(SCX - hw, SCX + hw + 1):
            _put(s, x, y, FACE if x < SCX + 2 else FACE_SH)
    for x in range(SCX - 7, SCX + 8):
        _put(s, x, 11, FACE_SH)

    HAIR = (58, 48, 44)          # pelo y barba: marrón muy oscuro, no negro
    HAIR_HI = (86, 72, 64)       # el borde que recibe la luz de arriba

    # Pelo peinado hacia atrás: solo asoma en las sienes, dos píxeles.
    # Más ancho que esto y el rostro deja de leerse como piel.
    for sgn in (-1, 1):
        for dy in range(0, 4):
            _put(s, SCX + sgn * 6, 12 + dy, HAIR)
            _put(s, SCX + sgn * 7, 12 + dy, HAIR_HI if dy == 0 else HAIR)

    # Cejas: bajas y gruesas. Son lo que da la expresión seria.
    for x in range(SCX - 6, SCX - 1):
        _put(s, x, 16, HAIR)
    for x in range(SCX + 2, SCX + 7):
        _put(s, x, 16, HAIR)

    for x in range(SCX - 5, SCX - 2):
        _put(s, x, 17, EYE_WHITE)
    for x in range(SCX + 3, SCX + 6):
        _put(s, x, 17, EYE_WHITE)

    # Nariz
    for y in range(18, 21):
        _put(s, SCX, y, FACE_SH)
        _put(s, SCX + 1, y, FACE_DK)

    # Patillas: bajan por el borde de la cara y enganchan con la barba.
    for sgn in (-1, 1):
        for y in range(17, 22):
            _put(s, SCX + sgn * 6, y, HAIR)

    # Bigote, dejando el filtro libre en el centro.
    for x in range(SCX - 4, SCX + 5):
        if abs(x - SCX) == 0:
            continue
        _put(s, x, 21, HAIR)

    # Barba: se dibuja SOLO en el mentón y la mandíbula, y se angosta hacia
    # abajo. La primera versión la hizo de siete píxeles de ancho desde la
    # nariz y el resultado fue una mancha oscura: el rostro se leía como
    # otra máscara, justo lo contrario de lo que esta forma significa.
    # Las mejillas tienen que quedar de piel.
    for y, ancho in ((22, 5), (23, 5), (24, 4), (25, 3), (26, 2)):
        for x in range(SCX - ancho, SCX + ancho + 1):
            _put(s, x, y, HAIR if (x + y) % 4 else HAIR_HI)
    _put(s, SCX - 1, 22, (150, 120, 110))     # labio inferior, apenas
    _put(s, SCX, 22, (150, 120, 110))

    # Corona de greca + cresta
    for y in range(3, 12):
        hw = 12 if y < 5 else (18 if y < 9 else 15)
        for x in range(SCX - hw, SCX + hw + 1):
            c = GOLD_HI if y < 5 else (GOLD if y < 9 else GOLD_DK)
            if y >= 9 and abs(x - SCX) > 12:
                c = GOLD
            _put(s, x, y, c)
    for x in range(SCX - 16, SCX + 17, 5):
        _put(s, x, 6, GOLD_DK)
        _put(s, x, 7, GOLD_DK)
        _put(s, x + 1, 7, GOLD_DK)
        _put(s, x, 8, GOLD_HI)
    for dx, hgt in ((-14, 3), (-8, 5), (0, 7), (8, 5), (14, 3)):
        for k in range(hgt):
            _put(s, SCX + dx, 3 - k, GOLD_HI if k < 2 else GOLD)
            if hgt > 3 and k < hgt - 2:
                _put(s, SCX + dx - 1, 3 - k, GOLD)
                _put(s, SCX + dx + 1, 3 - k, GOLD)
    # Orejeras
    for sgn in (-1, 1):
        cx2 = SCX + sgn * 11
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                if dx * dx + dy * dy <= 4:
                    _put(s, cx2 + dx, 19 + dy,
                         GOLD if abs(dx) + abs(dy) > 1 else GOLD_DK)

    # Las dos reliquias en las manos
    puls = 0.5 + 0.5 * math.sin(ph)
    for sgn, base, hi in ((-1, GOLD, GOLD_HI), (1, PEARL, PEARL_MID)):
        cx2 = SCX + sgn * 29
        cy2 = 40
        r = 4
        for dy in range(-r - 1, r + 2):
            for dx in range(-r - 1, r + 2):
                d = math.hypot(dx, dy)
                if d <= r:
                    _put(s, cx2 + dx, cy2 + dy, hi if d < 1.6 else base)
                elif d <= r + 1 and sgn > 0:
                    _put(s, cx2 + dx, cy2 + dy, PEARL_RIM)
        for k in range(5):
            wob = int(math.sin(ph + k * 0.9) * 1.4)
            if sgn < 0:
                _put(s, cx2 + wob, cy2 - r - 1 - k,
                     GOLD_HI if k < 2 + puls else GOLD)
                if k < 3:
                    _put(s, cx2 + wob + 1, cy2 - r - 1 - k, GOLD)
            else:
                _put(s, cx2 + wob, cy2 - r - 1 - k, PEARL_MID if k < 1 else (44, 40, 58))
                if k < 3:
                    _put(s, cx2 + wob - 1, cy2 - r - 1 - k, (30, 28, 42))
    return s


def main() -> None:
    pygame.init()
    pygame.display.set_mode((1, 1))
    print("Generando arte de idle de las Formas 2-4 de Paburu:")

    save_sheet([_rim_glow(build_mask(i), SPECTRAL_HI, 70) for i in range(6)],
               "boss_paburu_mask.png", MW, MH)
    save_sheet([build_relic(i, gold=True) for i in range(6)],
               "boss_paburu_gold.png", 32, 32)
    save_sheet([build_relic(i, gold=False) for i in range(6)],
               "boss_paburu_black.png", 32, 32)
    save_sheet([_rim_glow(build_spirit(i), GLOW, 90) for i in range(8)],
               "boss_paburu_spirit.png", SW, SH)
    print("Listo. Recordá: esto es arte de idle; las mecánicas son EP2/EP3.")


if __name__ == "__main__":
    main()
