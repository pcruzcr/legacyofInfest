"""
Generador de los fondos de parallax del Cementerio Sagrado — Stage 4-2.

Escribe en `assets/backgrounds/paburu/`:

    bg_paburu_far.png    800×600 · cielo púrpura, luna velada, montañas
    bg_paburu_mid.png    800×600 · los tres guardianes + niebla
    bg_paburu_near.png   800×600 · el cementerio en silueta

Ejecutar desde la raíz del proyecto:  python tools/gen_paburu_fondos.py

El TMX los pide con la propiedad `background_zone = "paburu"`: el loader
arma la ruta `assets/backgrounds/{zone}/bg_{zone}_{far,mid,near}.png`.
Zona propia por el mismo motivo que el tileset — `generate_all_assets.py`
del profesor regenera las zonas que tiene en su tabla, y `paburu` no está
en ella, así que no puede pisarlos.

Se dibujan a 800×600, que es la resolución interna del juego: el loader
escala lo que encuentre a ese tamaño, y los fondos viejos medían 224 px
de alto, así que se estiraban casi 3× y salían borrosos.

La cámara de esta arena está fijada con `CameraLock` en los dos ejes, así
que el parallax no se mueve: estos tres fondos tienen que funcionar como
una sola imagen quieta. Por eso la composición está pensada como un cuadro
y no como una tira que se repite.

Mapeo académico:
  - Unidad IV — representación de escenas: separación en planos de
                profundidad y orden de composición.
  - Unidad V  — paleta canónica, degradado atmosférico y halo lunar.
  - Unidad VI — ruido de valor + smoothstep para nubes, niebla y estrellas.
Determinista: mismo código, mismo PNG. Sin `random`.
"""
from __future__ import annotations

import math
import os
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

W, H = 800, 600
OUT_DIR = Path("assets/backgrounds/paburu")

# ── Paleta (Asset Bible / GDD §3.1) ───────────────────────────────
SKY_TOP = (16, 8, 24)          # casi negro arriba
SKY_BOT = (46, 24, 62)         # púrpura hacia el horizonte
CLOUD = (58, 42, 78)
CLOUD_LIT = (96, 118, 108)     # nube tocada por la luna, verdosa
MOON = (206, 226, 208)
MOON_HALO = (120, 158, 136)
MOUNTAIN_FAR = (30, 20, 44)
MOUNTAIN_NEAR = (22, 14, 34)
SPECTRAL = (0, 200, 100)
STONE_SIL = (34, 28, 44)
STONE_SIL_2 = (44, 38, 56)


def _hash(x: int, y: int, s: int = 0) -> float:
    n = (x * 374761393 + y * 668265263 + s * 982451653) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 0xFFFF


def vnoise(x: float, y: float, scale: float, s: int = 0) -> float:
    fx, fy = x / scale, y / scale
    ix, iy = int(fx), int(fy)
    tx, ty = fx - ix, fy - iy
    tx = tx * tx * (3 - 2 * tx)
    ty = ty * ty * (3 - 2 * ty)
    a, b = _hash(ix, iy, s), _hash(ix + 1, iy, s)
    c, d = _hash(ix, iy + 1, s), _hash(ix + 1, iy + 1, s)
    return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty


def fbm(x: float, y: float, scale: float, s: int = 0, oct_: int = 3) -> float:
    v, amp, tot = 0.0, 1.0, 0.0
    for i in range(oct_):
        v += vnoise(x, y, scale / (2 ** i), s + i * 13) * amp
        tot += amp
        amp *= 0.5
    return v / tot


def _mix(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    t = max(0.0, min(1.0, t))
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _ridge(x: float, seed: int, base: float, amp: float, scale: float) -> float:
    """Perfil de montaña: fbm proyectado a una altura por columna."""
    return base - fbm(x, 0, scale, seed, 4) * amp


# ══════════════════════════════════════════════════════════════════
#  BG_Far — cielo, luna velada, montañas lejanas
# ══════════════════════════════════════════════════════════════════

MOON_X, MOON_Y, MOON_R = 596, 118, 46


def build_far() -> pygame.Surface:
    s = pygame.Surface((W, H))

    # Degradado del cielo + halo de la luna sobre el propio degradado.
    for y in range(H):
        base = _mix(SKY_TOP, SKY_BOT, (y / H) ** 0.75)
        for x in range(W):
            d = math.hypot(x - MOON_X, y - MOON_Y)
            if d < 300:
                glow = (1.0 - d / 300) ** 2.4 * 0.55
                s.set_at((x, y), _mix(base, MOON_HALO, glow))
            else:
                s.set_at((x, y), base)

    # Estrellas: pocas y tenues, solo en la mitad superior.
    for i in range(150):
        x = int(_hash(i, 1, 5) * W)
        y = int(_hash(i, 2, 5) ** 1.6 * H * 0.55)
        if math.hypot(x - MOON_X, y - MOON_Y) < 150:
            continue
        b = _hash(i, 3, 5)
        c = _mix(s.get_at((x, y))[:3], (200, 210, 220), 0.25 + b * 0.5)
        s.set_at((x, y), c)

    # La luna, velada: disco + nubes por delante.
    for y in range(MOON_Y - MOON_R - 2, MOON_Y + MOON_R + 3):
        for x in range(MOON_X - MOON_R - 2, MOON_X + MOON_R + 3):
            if not (0 <= x < W and 0 <= y < H):
                continue
            d = math.hypot(x - MOON_X, y - MOON_Y)
            if d <= MOON_R:
                # Mares lunares con ruido suave.
                m = fbm(x, y, 22, 9, 2)
                s.set_at((x, y), _mix(MOON, MOON_HALO, (m - 0.4) * 0.9))
            elif d <= MOON_R + 2:
                s.set_at((x, y), _mix(s.get_at((x, y))[:3], MOON, 0.35))

    # Bandas de nube que cruzan por delante de la luna.
    for y in range(40, 260):
        for x in range(W):
            n = fbm(x * 0.55, y * 1.9, 90, 21, 3)
            band = math.sin((y - 40) / 220 * math.pi * 2.0) * 0.5 + 0.5
            v = n * 0.72 + band * 0.28
            if v > 0.60:
                t = min(1.0, (v - 0.60) / 0.28)
                lit = 1.0 - min(1.0, math.hypot(x - MOON_X, y - MOON_Y) / 240)
                col = _mix(CLOUD, CLOUD_LIT, lit * 0.8)
                s.set_at((x, y), _mix(s.get_at((x, y))[:3], col, t * 0.85))

    # Montañas lejanas.
    for x in range(W):
        h1 = _ridge(x, 31, H * 0.62, 130, 260)
        for y in range(int(h1), H):
            s.set_at((x, y), MOUNTAIN_FAR)
    for x in range(W):
        h2 = _ridge(x + 400, 47, H * 0.70, 95, 170)
        for y in range(int(h2), H):
            s.set_at((x, y), MOUNTAIN_NEAR)
    return s


# ══════════════════════════════════════════════════════════════════
#  BG_Mid — los tres guardianes + niebla
# ══════════════════════════════════════════════════════════════════
# GDD §3.1: "siluetas de los 3 guardianes, translúcidos, observan".
# Son el venado, la serpiente y el gavilán — los guardianes de Paburu en
# vida (§2.3). Se dibujan como siluetas espectrales verdes reconocibles
# por su contorno, no por detalle: a esta distancia el jugador solo lee
# la forma.

# Las siluetas se definen como POLÍGONOS y no como trazos procedurales.
# El primer intento las dibujaba píxel a píxel con senos y bucles, y salían
# un venado que parecía una mesa y un gavilán que eran dos arcos sueltos.
# A esta distancia el jugador solo lee el contorno, así que el contorno
# tiene que ser una forma cerrada y deliberada.

def _poly(s: pygame.Surface, cx: float, cy: float, k: float,
          pts: list[tuple[float, float]], col: tuple[int, int, int, int]) -> None:
    pygame.draw.polygon(s, col, [(cx + x * k, cy + y * k) for x, y in pts])


def _deer(s: pygame.Surface, cx: int, cy: int, k: float,
          col: tuple[int, int, int, int]) -> None:
    """Venado de perfil: cuerpo, cuello, cabeza y astas ramificadas."""
    _poly(s, cx, cy, k, [
        (-26, 2), (-20, -6), (-6, -9), (8, -8), (18, -4), (22, 2),
        (20, 10), (6, 14), (-8, 14), (-22, 11),
    ], col)                                                   # cuerpo
    _poly(s, cx, cy, k, [(16, -4), (20, -16), (26, -26), (30, -25),
                         (25, -14), (23, -2)], col)           # cuello
    _poly(s, cx, cy, k, [(24, -27), (34, -30), (37, -26), (33, -22),
                         (25, -23)], col)                     # cabeza
    for x0, x1 in ((-20, -17), (-10, -7), (6, 9), (16, 19)):   # patas
        _poly(s, cx, cy, k, [(x0, 10), (x1, 10), (x1 - 1, 34), (x0 - 1, 34)], col)
    # Astas: dos ramas con puntas
    for base, lean in ((25, -1.0), (30, 0.6)):
        _poly(s, cx, cy, k, [(base, -28), (base + 1.6, -28),
                             (base + lean * 4 + 1.6, -44), (base + lean * 4, -44)], col)
        for i, up in enumerate((-34, -39)):
            tip = base + lean * (4 * (up + 44) / 16)
            _poly(s, cx, cy, k, [(tip, up), (tip + 1.4, up),
                                 (tip + lean * 5 - 4, up - 6),
                                 (tip + lean * 5 - 5.4, up - 6)], col)
    _poly(s, cx, cy, k, [(-26, 2), (-34, -4), (-33, 3), (-27, 6)], col)   # cola


def _serpent(s: pygame.Surface, cx: int, cy: int, k: float,
             col: tuple[int, int, int, int]) -> None:
    """Serpiente en S: una cinta senoidal que se afina hacia la cola."""
    top: list[tuple[float, float]] = []
    bot: list[tuple[float, float]] = []
    for i in range(61):
        u = i / 60
        x = -34 + u * 68
        y = math.sin(u * math.pi * 2.1) * 17 + 4
        w = 8.0 * (1.0 - u * 0.82)                 # gruesa en la cabeza
        dx = math.cos(u * math.pi * 2.1) * 17 * (math.pi * 2.1 / 68)
        nx, ny = -dx, 1.0
        n = math.hypot(nx, ny) or 1.0
        top.append((x + nx / n * w, y + ny / n * w))
        bot.append((x - nx / n * w, y - ny / n * w))
    _poly(s, cx, cy, k, top + bot[::-1], col)

    # Cabeza. Los vértices se meten HACIA ADENTRO de la cinta —hasta x=-24,
    # cuando la cinta arranca en -34— a propósito: el borde inicial del
    # cuerpo es una diagonal, y una cabeza que apenas lo tocaba dejaba una
    # costura que a esta escala se leía como un trozo suelto flotando. Con
    # solape generoso los dos polígonos se funden en una silueta sola.
    _poly(s, cx, cy, k, [
        (-24, 4), (-38, 11), (-50, 6), (-54, -3), (-46, -10), (-32, -6),
    ], col)
    # Lengua bífida, naciendo desde dentro de la cabeza.
    _poly(s, cx, cy, k, [(-52, -4), (-64, -7), (-63, -4), (-52, -2)], col)
    _poly(s, cx, cy, k, [(-52, 0), (-63, 1), (-64, 4), (-52, 2)], col)


def _hawk(s: pygame.Surface, cx: int, cy: int, k: float,
          col: tuple[int, int, int, int]) -> None:
    """Gavilán con las alas abiertas: la silueta más reconocible de las tres."""
    for sgn in (-1, 1):
        _poly(s, cx, cy, k, [
            (sgn * 4, -6), (sgn * 16, -18), (sgn * 30, -22), (sgn * 42, -18),
            (sgn * 40, -12), (sgn * 30, -8), (sgn * 24, 0), (sgn * 14, 4),
            (sgn * 5, 4),
        ], col)                                                # ala
        _poly(s, cx, cy, k, [(sgn * 30, -22), (sgn * 38, -26), (sgn * 42, -18)], col)
    _poly(s, cx, cy, k, [(-5, -10), (5, -10), (6, 8), (3, 22),
                         (-3, 22), (-6, 8)], col)              # cuerpo
    _poly(s, cx, cy, k, [(-4, -12), (4, -12), (5, -20), (-5, -20)], col)   # cabeza
    _poly(s, cx, cy, k, [(4, -18), (11, -16), (4, -14)], col)              # pico
    _poly(s, cx, cy, k, [(-7, 20), (7, 20), (4, 32), (-4, 32)], col)       # cola


def _spectral(shape: pygame.Surface, fade_from: float, alpha: int) -> pygame.Surface:
    """Convierte una silueta PLANA en una aparición.

    El problema de la versión anterior no era el dibujo de los animales sino
    cómo se componían: tres polígonos de un solo color, con el mismo alpha
    global y el mismo tamaño, recortados con borde duro contra el cielo.
    Eso no se lee como espíritu, se lee como calcomanía pegada.

    Tres operaciones lo arreglan:
      1. HALO — reducir la silueta y volver a ampliarla produce un desenfoque
         barato y determinista (nada de `random` ni de scipy). Compuesto
         debajo del cuerpo, da el resplandor que separa un fantasma de un
         recorte.
      2. DISOLUCIÓN — un gradiente vertical multiplicado sobre el canal alpha
         hace que la figura se deshaga hacia abajo en vez de cortarse en
         seco. Es lo que más vende la idea de que no es materia.
      3. PROFUNDIDAD — cada guardián recibe su propia escala y su propio
         alpha, así dejan de estar los tres en el mismo plano.

    Unidad V (composición por canal alfa) y Unidad VI (interpolación del
    gradiente y remuestreo bilineal del halo).
    """
    w, h = shape.get_size()
    out = pygame.Surface((w, h), pygame.SRCALPHA)

    # 1 — halo por remuestreo: bajar a 1/6 y volver a subir difumina.
    chico = pygame.transform.smoothscale(shape, (max(1, w // 6), max(1, h // 6)))
    halo = pygame.transform.smoothscale(chico, (w, h))
    halo.set_alpha(int(alpha * 0.85))
    out.blit(halo, (0, 0))
    out.blit(halo, (0, 0))          # segunda pasada: el resplandor gana cuerpo

    cuerpo = shape.copy()
    cuerpo.set_alpha(alpha)
    out.blit(cuerpo, (0, 0))

    # 2 — disolución hacia abajo, multiplicando el alpha por el gradiente.
    y0 = fade_from * h
    mascara = pygame.Surface((w, h), pygame.SRCALPHA)
    for y in range(h):
        t = 0.0 if y <= y0 else (y - y0) / max(1.0, h - y0)
        a = int(255 * max(0.0, 1.0 - t) ** 1.6)
        pygame.draw.line(mascara, (255, 255, 255, a), (0, y), (w, y))
    out.blit(mascara, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    return out


def build_mid() -> pygame.Surface:
    s = pygame.Surface((W, H), pygame.SRCALPHA)

    # Niebla espectral baja.
    for y in range(300, H):
        for x in range(W):
            n = fbm(x, y * 2.2, 120, 55, 3)
            t = (y - 300) / (H - 300)
            v = n * 0.8 + t * 0.35
            if v > 0.62:
                a = int(min(120, (v - 0.62) * 300 * (0.4 + t)))
                s.set_at((x, y), (*_mix((30, 60, 48), (70, 120, 96), t), a))

    # Los tres guardianes, translúcidos. Van arriba del horizonte de las
    # lápidas (y≈452 en BG_Near) para que no se confundan con la piedra, y
    # con alpha bajo: observan, no compiten con la pelea.
    # Escala y alpha bajos a propósito: en la primera versión medían el
    # doble y con alpha 58 se comían la escena. Son testigos.
    # Los tres guardianes YA NO van horneados acá.
    #
    # Estaban pintados dentro de este PNG, y por eso quedaban clavados: un
    # fondo es una imagen, no puede moverse por sí sola. El lore §2.3 dice
    # que llevan siglos esperando a Paburu, y tres siluetas inmóviles y
    # equidistantes no comunican espera: comunican calcomanía.
    #
    # Ahora se generan aparte, en `guardianes.png`, y los anima la escena
    # (`src/stages/boss_paburu/guardianes.py`). Acá queda solo la niebla,
    # que sí es fondo de verdad.
    return s


# ══════════════════════════════════════════════════════════════════
#  Los tres guardianes, como hoja aparte para que la escena los anime
# ══════════════════════════════════════════════════════════════════
GUARDIAN_W, GUARDIAN_H = 160, 120


def build_guardianes() -> pygame.Surface:
    """Hoja de 3 celdas: venado, serpiente y gavilán, ya espectrales.

    Cada celda mide 160×120 y trae la figura centrada con su halo y su
    disolución ya aplicados, para que la escena solo tenga que moverlos y
    modular su alfa. Se pre-renderiza acá y no en tiempo real porque el
    remuestreo del halo es caro para hacerlo 60 veces por segundo.
    """
    hoja = pygame.Surface((GUARDIAN_W * 3, GUARDIAN_H), pygame.SRCALPHA)
    cx, cy = GUARDIAN_W // 2, GUARDIAN_H // 2
    for i, (fn, k) in enumerate(((_deer, 0.92), (_serpent, 1.05), (_hawk, 1.18))):
        celda = pygame.Surface((GUARDIAN_W, GUARDIAN_H), pygame.SRCALPHA)
        fn(celda, cx, cy, k, (*SPECTRAL, 255))
        hoja.blit(_spectral(celda, 0.72, 255), (i * GUARDIAN_W, 0))
    return hoja


# ══════════════════════════════════════════════════════════════════
#  BG_Near — el cementerio en silueta
# ══════════════════════════════════════════════════════════════════

def build_near() -> pygame.Surface:
    s = pygame.Surface((W, H), pygame.SRCALPHA)

    def slab(x0: int, y0: int, w: int, h: int, col: tuple[int, int, int],
             round_top: bool = False, lean: float = 0.0) -> None:
        for y in range(y0, y0 + h):
            dx = int((y - y0) * lean)
            for x in range(x0 + dx, x0 + w + dx):
                if round_top:
                    ry = y - y0
                    if ry < w // 2:
                        cxx = x0 + w / 2 + dx
                        if abs(x - cxx) > math.sqrt(max(0.0, (w / 2) ** 2 - (w // 2 - ry) ** 2)):
                            continue
                if 0 <= x < W and 0 <= y < H:
                    s.set_at((x, y), col)

    # Fila lejana: lápidas chicas y apretadas.
    for i in range(26):
        x = 8 + i * 31 + int(_hash(i, 7, 3) * 9)
        w = 12 + int(_hash(i, 8, 3) * 8)
        h = 22 + int(_hash(i, 9, 3) * 20)
        slab(x, 452 - h, w, h, STONE_SIL, round_top=_hash(i, 10, 3) > 0.55,
             lean=(_hash(i, 11, 3) - 0.5) * 0.16)

    # Cruces lejanas.
    for i, x in enumerate((96, 268, 470, 690)):
        top = 418 - int(_hash(i, 12, 4) * 14)
        slab(x, top, 6, 46, STONE_SIL)
        slab(x - 9, top + 10, 24, 6, STONE_SIL)

    # Obeliscos: los verticales que rompen la línea del horizonte. Anchos
    # y no muy altos — finos y largos se leían como postes flotando.
    for x, h in ((196, 74), (556, 88), (742, 62)):
        slab(x, 452 - h, 26, h, STONE_SIL_2)
        slab(x + 4, 452 - h - 6, 18, 6, STONE_SIL_2)   # remate, pegado al fuste
        slab(x - 4, 444, 34, 10, STONE_SIL_2)          # basamento

    # Fila cercana: más grandes, más separadas, tono apenas más claro.
    for i in range(11):
        x = 20 + i * 74 + int(_hash(i, 13, 6) * 16)
        w = 22 + int(_hash(i, 14, 6) * 12)
        h = 40 + int(_hash(i, 15, 6) * 26)
        slab(x, 486 - h, w, h, STONE_SIL_2, round_top=_hash(i, 16, 6) > 0.45,
             lean=(_hash(i, 17, 6) - 0.5) * 0.22)
    return s


def main() -> None:
    pygame.init()
    pygame.display.set_mode((1, 1))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print("Generando fondos del Cementerio Sagrado:")
    for name, surf in (("far", build_far()), ("mid", build_mid()), ("near", build_near())):
        p = OUT_DIR / f"bg_paburu_{name}.png"
        pygame.image.save(surf, str(p))
        print(f"  {p}  {W}x{H}")
    g = build_guardianes()
    pg = OUT_DIR / "paburu_guardianes.png"
    pygame.image.save(g, str(pg))
    print(f"  {pg}  {g.get_width()}x{g.get_height()}  (3 celdas de "
          f"{GUARDIAN_W}x{GUARDIAN_H})")


if __name__ == "__main__":
    main()
