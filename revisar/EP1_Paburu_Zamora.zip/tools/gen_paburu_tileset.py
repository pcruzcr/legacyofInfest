"""
Generador del tileset del Cementerio Sagrado — Stage 4-2.

Escribe `assets/tilesets/tileset_paburu.png`: 128×128 px = 64 tiles de 16×16.

Ejecutar desde la raíz del proyecto:  python tools/gen_paburu_tileset.py

POR QUÉ UN TILESET PROPIO Y NO `tileset_cemetery.png`:
`tools/generate_all_assets.py` (código del profesor) tiene en su tabla
`"tileset_cemetery": {"floor": (50,50,70), "wall": (70,70,90),
"deco": (40,40,60)}` — tres colores planos. Cualquiera que corra ese
script sobrescribe el tileset. Con nombre propio, no lo toca. Es la misma
decisión que tomamos con los sprites del boss.

El tileset viejo tenía 8 diseños genéricos repetidos 8 veces (losa gris,
azul con una línea, madera, ladrillo rojo) y el mapa solo usaba 4 de
ellos. No había una sola lápida.

Mapeo académico:
  - Unidad V  — paleta canónica del Asset Bible, rampa de tonos cuantizada
                y sombreado direccional coherente en todos los tiles.
  - Unidad VI — texturizado procedural con ruido de valor + smoothstep
                para el granito, las grietas y el musgo.
Determinista: mismo código, mismo PNG. Sin `random`.
"""
from __future__ import annotations

import math
import os
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

T = 16                      # lado del tile
COLS = ROWS = 8             # 64 tiles
OUT = Path("assets/tilesets/tileset_paburu.png")

# ── Paleta (Asset Bible / GDD §3.1) ───────────────────────────────
# Piedra pálida #c8c3b8 desaturada hacia el frío del cementerio.
STONE = [
    (26, 24, 32), (44, 42, 52), (66, 63, 74),
    (94, 90, 100), (126, 122, 130), (162, 158, 162), (196, 192, 190),
]
MOSS = [(30, 56, 40), (44, 84, 56), (62, 110, 72)]
EARTH = [(38, 30, 28), (58, 46, 40), (82, 66, 54)]
SPECTRAL = (0, 200, 100)
SPECTRAL_DIM = (24, 92, 62)
GOLD = (232, 177, 44)
VOID = (18, 10, 26)         # el fondo del cementerio, para huecos


def _hash(x: int, y: int, s: int = 0) -> float:
    n = (x * 374761393 + y * 668265263 + s * 982451653) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 0xFFFF


def vnoise(x: float, y: float, scale: float, s: int = 0) -> float:
    fx, fy = x / scale, y / scale
    ix, iy = int(fx), int(fy)
    tx, ty = fx - ix, fy - iy
    tx = tx * tx * (3 - 2 * tx)
    ty = ty * ty * (3 - 2 * ty)
    a, b = _hash(ix, iy, s), _hash(ix + 1, iy, s)
    c, d = _hash(ix, iy + 1, s), _hash(ix + 1, iy + 1, s)
    return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty


class Tile:
    """Un tile de 16×16. `gx, gy` son sus coordenadas globales en el atlas,
    para que el ruido sea continuo entre tiles vecinos del mismo material."""

    def __init__(self, gx: int, gy: int) -> None:
        self.s = pygame.Surface((T, T), pygame.SRCALPHA)
        self.gx, self.gy = gx, gy

    def put(self, x: int, y: int, c: tuple[int, ...]) -> None:
        if 0 <= x < T and 0 <= y < T:
            self.s.set_at((x, y), c)

    def fill(self, c: tuple[int, ...]) -> None:
        self.s.fill(c)

    def granite(self, base: int = 3, spread: int = 1, seed: int = 0) -> None:
        """Granito: ruido de dos octavas sobre un tono base."""
        for y in range(T):
            for x in range(T):
                n = vnoise(self.gx * T + x, self.gy * T + y, 3.4, seed) * 0.6
                n += vnoise(self.gx * T + x, self.gy * T + y, 1.6, seed + 7) * 0.4
                idx = base + round((n - 0.5) * 2 * spread)
                self.put(x, y, STONE[max(0, min(6, idx))])

    def bevel(self, top: int = 5, bottom: int = 1) -> None:
        """Borde superior a la luz, inferior en sombra: define la losa."""
        for x in range(T):
            self.put(x, 0, STONE[top])
            self.put(x, T - 1, STONE[bottom])
        for y in range(T):
            self.put(0, y, STONE[min(6, top - 1)])
            self.put(T - 1, y, STONE[bottom])

    def crack(self, seed: int, n_pts: int = 5) -> None:
        """Una grieta que serpentea de arriba a abajo."""
        x = 2 + int(_hash(self.gx, self.gy, seed) * (T - 4))
        y = 0
        for k in range(n_pts):
            self.put(x, y, STONE[0])
            self.put(x, min(y + 1, T - 1), STONE[1])
            x += -1 if _hash(x, y, seed + k) < 0.5 else 1
            x = max(1, min(T - 2, x))
            y += max(2, T // n_pts)
            if y >= T:
                break

    def moss_patch(self, amount: float = 0.30, seed: int = 3) -> None:
        """Musgo, concentrado abajo: el agua baja."""
        for y in range(T):
            for x in range(T):
                bias = (y / T) ** 2 * 0.35
                if vnoise(self.gx * T + x, self.gy * T + y, 4.0, seed) + bias > 1.0 - amount:
                    self.put(x, y, MOSS[1 if (x + y) % 3 else 2])


# ══════════════════════════════════════════════════════════════════
#  Los 64 tiles. El índice en esta lista + 1 es el GID que usa el TMX.
# ══════════════════════════════════════════════════════════════════

def build() -> list[pygame.Surface]:
    tiles: list[pygame.Surface] = []

    def new(i: int) -> Tile:
        return Tile(i % COLS, i // COLS)

    # 1 — vacío (transparente). El GID 0 del TMX ya es "nada", pero tener
    #     un tile vacío explícito simplifica el generador del mapa.
    tiles.append(pygame.Surface((T, T), pygame.SRCALPHA))

    # 2-5 — LOSA DEL SUELO, cuatro variantes para romper la repetición
    for v in range(4):
        t = new(len(tiles))
        t.granite(base=3, spread=1, seed=v)
        t.bevel(top=5, bottom=1)
        if v in (1, 3):
            t.crack(seed=10 + v)
        if v == 2:
            t.moss_patch(0.22, seed=20)
        tiles.append(t.s)

    # 6-8 — PIEDRA DE MURO, más oscura y con junta horizontal
    for v in range(3):
        t = new(len(tiles))
        t.granite(base=2, spread=1, seed=30 + v)
        for x in range(T):
            t.put(x, 7, STONE[1])
            t.put(x, 8, STONE[3])
        t.put(7 + v * 3, 0, STONE[1])
        for y in range(7):
            t.put(7 + v * 3, y, STONE[1])
        for y in range(9, T):
            t.put(3 + v * 4, y, STONE[1])
        tiles.append(t.s)

    # 9-11 — TIERRA / relleno bajo el suelo
    for v in range(3):
        t = new(len(tiles))
        for y in range(T):
            for x in range(T):
                n = vnoise(t.gx * T + x, t.gy * T + y, 2.8, 40 + v)
                t.put(x, y, EARTH[min(2, int(n * 3))])
        tiles.append(t.s)

    # 12-14 — LÁPIDA: base, cuerpo con inscripción, remate redondeado
    t = new(len(tiles))            # 12 base
    t.granite(base=4, spread=1, seed=50)
    for x in range(T):
        t.put(x, 0, STONE[6])
    for y in range(T):
        t.put(0, y, STONE[0])
        t.put(T - 1, y, STONE[0])
    t.moss_patch(0.30, seed=51)
    tiles.append(t.s)

    t = new(len(tiles))            # 13 cuerpo con inscripción
    t.granite(base=4, spread=1, seed=52)
    for y in range(T):
        t.put(0, y, STONE[0])
        t.put(1, y, STONE[6])
        t.put(T - 1, y, STONE[0])
        t.put(T - 2, y, STONE[2])
    for ly, w in ((4, 8), (7, 9), (10, 6)):
        for x in range(4, 4 + w):
            t.put(x, ly, STONE[2])
    tiles.append(t.s)

    t = new(len(tiles))            # 14 remate redondeado
    t.fill((0, 0, 0, 0))
    for y in range(T):
        for x in range(T):
            dx, dy = x - 7.5, y - 11.0
            inside = (y >= 6 and 1 <= x <= T - 2) or (dx * dx / 42 + dy * dy / 30 <= 1 and y < 7)
            if not inside:
                continue
            n = vnoise(t.gx * T + x, t.gy * T + y, 3.0, 53)
            t.put(x, y, STONE[max(0, min(6, 4 + int((n - 0.5) * 2)))])
    for x in range(2, T - 2):
        if t.s.get_at((x, 2)).a:
            t.put(x, 2, STONE[6])
    tiles.append(t.s)

    # 15-16 — CRUZ DE PIEDRA: parte alta y parte baja
    t = new(len(tiles))            # 15 brazos
    for y in range(T):
        for x in range(T):
            on = (6 <= x <= 9 and y >= 3) or (2 <= x <= 13 and 6 <= y <= 9)
            if on:
                n = vnoise(t.gx * T + x, t.gy * T + y, 2.6, 60)
                t.put(x, y, STONE[max(0, min(6, 4 + int((n - 0.5) * 2)))])
    for x in range(6, 10):
        t.put(x, 3, STONE[6])
    tiles.append(t.s)

    t = new(len(tiles))            # 16 mástil
    for y in range(T):
        for x in range(6, 10):
            n = vnoise(t.gx * T + x, t.gy * T + y, 2.6, 61)
            t.put(x, y, STONE[max(0, min(6, 4 + int((n - 0.5) * 2)))])
    t.moss_patch(0.26, seed=62)
    for y in range(T):
        t.put(6, y, STONE[6])
        t.put(9, y, STONE[1])
    tiles.append(t.s)

    # 17-19 — OBELISCO: remate, fuste, base
    for v, (x0, x1) in enumerate(((5, 10), (4, 11), (3, 12))):
        t = new(len(tiles))
        for y in range(T):
            for x in range(x0, x1 + 1):
                n = vnoise(t.gx * T + x, t.gy * T + y, 3.0, 70 + v)
                t.put(x, y, STONE[max(0, min(6, 4 + int((n - 0.5) * 2)))])
            t.put(x0, y, STONE[6])
            t.put(x1, y, STONE[1])
        if v == 0:
            for y in range(4):
                for x in range(T):
                    if abs(x - 7.5) > y + 1.5:
                        t.put(x, y, (0, 0, 0, 0))
        if v == 2:
            t.moss_patch(0.30, seed=72)
        tiles.append(t.s)

    # 20-22 — LOSA GRABADA: el sello del suelo (Terrain_Detail)
    for v in range(3):
        t = new(len(tiles))
        t.granite(base=3, spread=1, seed=80 + v)
        t.bevel(top=5, bottom=1)
        if v == 0:      # greca
            for x in range(3, 13, 4):
                t.put(x, 6, SPECTRAL_DIM)
                t.put(x + 1, 6, SPECTRAL_DIM)
                t.put(x + 1, 7, SPECTRAL_DIM)
                t.put(x + 1, 8, SPECTRAL_DIM)
        elif v == 1:    # espiral
            for k, (dx, dy) in enumerate(((0, 0), (1, 0), (2, 0), (2, 1),
                                          (2, 2), (1, 2), (0, 2), (0, 3))):
                t.put(6 + dx, 6 + dy, SPECTRAL_DIM)
        else:           # círculo
            for a in range(0, 360, 30):
                r = math.radians(a)
                t.put(int(8 + math.cos(r) * 4), int(8 + math.sin(r) * 4), SPECTRAL_DIM)
        tiles.append(t.s)

    # 23-25 — ESCOMBRO: piedras sueltas sobre el suelo
    for v in range(3):
        t = new(len(tiles))
        for y in range(T):
            for x in range(T):
                n = vnoise(t.gx * T + x, t.gy * T + y, 2.2, 90 + v)
                if n > 0.62:
                    t.put(x, y, STONE[3 + (1 if n > 0.78 else 0)])
                elif n > 0.55:
                    t.put(x, y, STONE[1])
        tiles.append(t.s)

    # 26 — CUENCO DE FUEGO apagado (el encendido lo dibuja el LightSystem)
    t = new(len(tiles))
    for y in range(8, 14):
        w = 6 - (y - 8) // 2
        for x in range(8 - w, 8 + w):
            t.put(x, y, STONE[3] if x < 8 else STONE[2])
    for x in range(2, 14):
        t.put(x, 7, STONE[5])
        t.put(x, 8, STONE[1])
    for x in range(4, 12, 3):
        t.put(x, 10, GOLD)
    for x in range(6, 10):
        t.put(x, 14, STONE[2])
        t.put(x, 15, STONE[1])
    tiles.append(t.s)

    # 27-30 — SILUETAS DE FONDO: las mismas formas pero muy oscuras.
    # Sin esto, las lápidas de BG_Near salían del mismo gris que el suelo
    # jugable y todo se empastaba: no había separación de profundidad.
    # El valor es lo que crea la distancia, no el detalle.
    SIL = (30, 27, 38)
    SIL_HI = (40, 36, 50)
    for kind in ("tomb_body", "tomb_top", "cross_top", "cross_low"):
        t = new(len(tiles))
        t.fill((0, 0, 0, 0))
        if kind == "tomb_body":
            for y in range(T):
                for x in range(2, T - 2):
                    t.put(x, y, SIL_HI if x < 4 else SIL)
        elif kind == "tomb_top":
            for y in range(T):
                for x in range(2, T - 2):
                    if y < 6 and abs(x - 7.5) > math.sqrt(max(0.0, 36 - (6 - y) ** 2)):
                        continue
                    t.put(x, y, SIL_HI if x < 4 else SIL)
        elif kind == "cross_top":
            for y in range(T):
                for x in range(T):
                    if (6 <= x <= 9 and y >= 3) or (2 <= x <= 13 and 6 <= y <= 9):
                        t.put(x, y, SIL_HI if x < 7 else SIL)
        else:
            for y in range(T):
                for x in range(6, 10):
                    t.put(x, y, SIL_HI if x < 7 else SIL)
        tiles.append(t.s)

    # ── 31-45 — ARQUITECTURA DEL TEMPLO ───────────────────────────
    # Antes, del 31 al 64 eran 34 variantes de granito idénticas entre sí:
    # medio atlas gastado en relleno que el mapa nunca usó. El centro de la
    # arena quedaba vacío porque no existían piezas con las que construirlo.
    # Estas quince dan columnas, arcos y cornisas.
    #
    # Convención de luz: el foco está arriba a la izquierda, igual que en el
    # resto del atlas y que en los sprites del boss. Cada pieza lleva su
    # borde izquierdo claro (STONE[6]) y el derecho en sombra (STONE[1]).

    def stone_at(t: Tile, x: int, y: int, seed: int, base: int = 4) -> None:
        """Píxel de piedra con la misma textura de granito del resto."""
        n = vnoise(t.gx * T + x, t.gy * T + y, 3.0, seed)
        t.put(x, y, STONE[max(0, min(6, base + int((n - 0.5) * 2)))])

    # 31 — CAPITEL: la moldura que corona la columna
    t = new(len(tiles))
    for y in range(T):
        x0, x1 = (1, 14) if y < 3 else (2, 13) if y < 6 else (4, 11)
        for x in range(x0, x1 + 1):
            stone_at(t, x, y, 110)
        t.put(x0, y, STONE[6])
        t.put(x1, y, STONE[1])
    for x in range(1, 15):
        t.put(x, 0, STONE[6])
    for x in range(2, 14):
        t.put(x, 5, STONE[1])
    tiles.append(t.s)

    # 32 — FUSTE: el cuerpo, con acanaladuras verticales
    t = new(len(tiles))
    for y in range(T):
        for x in range(4, 12):
            stone_at(t, x, y, 111)
        for x in (5, 8):            # acanaladuras: luz a la izquierda...
            t.put(x, y, STONE[5])
        for x in (6, 9):            # ...y su sombra inmediata
            t.put(x, y, STONE[2])
        t.put(4, y, STONE[6])
        t.put(11, y, STONE[1])
    tiles.append(t.s)

    # 33 — BASA: se ensancha para apoyar en el suelo
    t = new(len(tiles))
    for y in range(T):
        x0, x1 = (4, 11) if y < 10 else (2, 13) if y < 13 else (1, 14)
        for x in range(x0, x1 + 1):
            stone_at(t, x, y, 112)
        t.put(x0, y, STONE[6])
        t.put(x1, y, STONE[1])
    for x in range(1, 15):
        t.put(x, T - 1, STONE[0])
    tiles.append(t.s)

    # 34 — FUSTE ROTO: remate irregular, para las columnas caídas del fondo
    t = new(len(tiles))
    for y in range(T):
        for x in range(4, 12):
            corte = 3 + int(_hash(x, 0, 113) * 4)
            if y < corte:
                continue
            stone_at(t, x, y, 113)
            if y == corte:
                t.put(x, y, STONE[6])
        t.put(4, y, STONE[6]) if y >= 6 else None
        t.put(11, y, STONE[1]) if y >= 6 else None
    tiles.append(t.s)

    # 35-37 — ARCO: arranque izquierdo, clave, arranque derecho.
    # El vano se calcula con la ecuación de la circunferencia: un punto es
    # piedra si cae FUERA del círculo de radio 16 centrado en la clave.
    # Así los tres tiles encajan sin costura, porque comparten el círculo.
    for v, (cx, seed) in enumerate(((16.0, 114), (0.0, 115), (-16.0, 116))):
        t = new(len(tiles))
        for y in range(T):
            for x in range(T):
                dx, dy = (x + 0.5) - (cx + 8.0), (y + 0.5) - 16.0
                if v == 1:
                    dx = (x + 0.5) - 8.0
                r = math.hypot(dx, dy)
                if r > 15.5 or dy > 0:
                    stone_at(t, x, y, seed)
                    if 15.5 < r <= 16.8:       # el intradós, iluminado
                        t.put(x, y, STONE[6] if dx < 0 else STONE[2])
        tiles.append(t.s)

    # 38-40 — CORNISA: extremo izquierdo, tramo central, extremo derecho.
    # Es la pieza de las plataformas one-way. La fila 0 va clara (canto que
    # recibe la luz) y justo debajo una franja oscura que hace de sombra
    # propia: eso es lo que la separa del fondo y la vuelve legible como
    # saliente y no como una tira de ladrillos flotando.
    for v in range(3):
        t = new(len(tiles))
        for y in range(T):
            for x in range(T):
                if y > 9:
                    continue                      # la cornisa no llega al piso
                if v == 0 and x < 2 and y > 5:
                    continue                      # esquina achaflanada
                if v == 2 and x > 13 and y > 5:
                    continue
                stone_at(t, x, y, 117 + v, base=4)
        for x in range(T):
            if t.s.get_at((x, 0)).a:
                t.put(x, 0, STONE[6])             # canto a la luz
            if t.s.get_at((x, 1)).a:
                t.put(x, 1, STONE[5])
            for y in (8, 9):
                if t.s.get_at((x, y)).a:
                    t.put(x, y, STONE[1 if y == 9 else 2])   # sombra propia
        if v == 0:
            for y in range(2, 10):
                t.put(2 if y > 5 else 0, y, STONE[6])
        if v == 2:
            for y in range(2, 10):
                t.put(13 if y > 5 else T - 1, y, STONE[0])
        tiles.append(t.s)

    # 41-45 — SILUETAS de las mismas piezas, para BG_Near.
    # Mismo criterio que las lápidas de fondo (GID 27-30): lo que crea la
    # profundidad es el valor, no el detalle. Si el fondo usara las piezas
    # normales, se empastaría con la arquitectura jugable.
    # Las siluetas van MÁS ANCHAS que sus equivalentes iluminadas (fuste de
    # 12 px contra 8): a esta escala un fuste de 8 px en silueta plana no se
    # lee como columna sino como un poste de luz. Sin volumen ni sombreado
    # que las delate, lo único que comunica "columna" es el grosor.
    for kind in ("cap", "shaft", "base", "arch_l", "arch_r"):
        t = new(len(tiles))
        t.fill((0, 0, 0, 0))
        if kind == "cap":
            for y in range(T):
                x0, x1 = (0, 15) if y < 5 else (2, 13)
                for x in range(x0, x1 + 1):
                    t.put(x, y, SIL_HI if x < x0 + 3 else SIL)
        elif kind == "shaft":
            for y in range(T):
                for x in range(2, 14):
                    t.put(x, y, SIL_HI if x < 5 else SIL)
        elif kind == "base":
            for y in range(T):
                x0, x1 = (2, 13) if y < 11 else (0, 15)
                for x in range(x0, x1 + 1):
                    t.put(x, y, SIL_HI if x < x0 + 3 else SIL)
        else:
            cx = 16.0 if kind == "arch_l" else -16.0
            for y in range(T):
                for x in range(T):
                    dx, dy = (x + 0.5) - (cx + 8.0), (y + 0.5) - 16.0
                    if math.hypot(dx, dy) > 15.5 or dy > 0:
                        t.put(x, y, SIL_HI if dx < 0 else SIL)
        tiles.append(t.s)

    # 46-49 — PILARES EN RUINAS (silueta), en mitades izquierda y derecha.
    #
    # El primer intento fue una columnata fina con arquitrabe. Renderizada
    # se leía como postes de portería: a 16 px de ancho y 20 tiles de alto,
    # una silueta plana no dice "columna". Estas piezas van de a dos tiles
    # (32 px de ancho) y se cortan arriba en quiebre irregular. Un pilar
    # roto no necesita capitel para leerse, y encaja mejor con un
    # cementerio sagrado en ruinas que una nave intacta.
    #
    # Se parten en mitades L/R para poder poner el filo de luz solo en el
    # borde izquierdo del pilar y la sombra solo en el derecho. Un único
    # tile repetido dejaría una franja clara en mitad del fuste.
    SIL_DK = (20, 18, 27)
    for kind in ("block_l", "block_r", "broken_l", "broken_r"):
        t = new(len(tiles))
        t.fill((0, 0, 0, 0))
        roto = kind.startswith("broken")
        izq = kind.endswith("_l")
        for x in range(T):
            # Perfil del quiebre: determinista, distinto en cada columna
            # de píxeles, para que el corte no salga recto.
            corte = 0
            if roto:
                gx = x if izq else x + T
                corte = 2 + int(_hash(gx, 0, 130) * 7)
            for y in range(T):
                if y < corte:
                    continue
                if izq and x < 3:
                    c = SIL_HI
                elif (not izq) and x > 12:
                    c = SIL_DK
                else:
                    c = SIL
                # El labio del quiebre va claro: es la piedra recién partida.
                if roto and y == corte:
                    c = SIL_HI
                t.put(x, y, c)
        tiles.append(t.s)

    # 50-52 — CEMENTERIO LEJANO: las mismas lápidas, un escalón más oscuras.
    # Van en la capa BG_Far. Si usaran el valor de las siluetas normales
    # (GID 27-30), el fondo lejano y el cercano quedarían al mismo tono y no
    # habría profundidad: se vería un único muro de lápidas. En una escena
    # nocturna la distancia se comunica bajando el contraste contra el
    # cielo, no dibujando menos detalle.
    FAR = (23, 20, 30)
    FAR_HI = (29, 26, 37)
    for kind in ("body", "top", "cross"):
        t = new(len(tiles))
        t.fill((0, 0, 0, 0))
        if kind == "body":
            for y in range(T):
                for x in range(5, 11):
                    t.put(x, y, FAR_HI if x < 7 else FAR)
        elif kind == "top":
            for y in range(T):
                for x in range(5, 11):
                    if y < 3 and abs(x - 7.5) > math.sqrt(max(0.0, 9 - (3 - y) ** 2)):
                        continue
                    t.put(x, y, FAR_HI if x < 7 else FAR)
        else:
            for y in range(T):
                for x in range(T):
                    if (7 <= x <= 8 and y >= 4) or (5 <= x <= 10 and 6 <= y <= 7):
                        t.put(x, y, FAR_HI if x < 8 else FAR)
        tiles.append(t.s)

    # 53-64 — reserva. Granito coherente para que cualquier GID futuro
    # dibuje algo válido en vez de un hueco.
    while len(tiles) < COLS * ROWS:
        t = new(len(tiles))
        t.granite(base=2, spread=1, seed=100 + len(tiles))
        tiles.append(t.s)
    return tiles


def main() -> None:
    pygame.init()
    pygame.display.set_mode((1, 1))
    tiles = build()
    atlas = pygame.Surface((COLS * T, ROWS * T), pygame.SRCALPHA)
    for i, s in enumerate(tiles):
        atlas.blit(s, ((i % COLS) * T, (i // COLS) * T))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    pygame.image.save(atlas, str(OUT))
    print(f"  {OUT}  {COLS * T}x{ROWS * T}  ({len(tiles)} tiles de {T}x{T})")


if __name__ == "__main__":
    main()
