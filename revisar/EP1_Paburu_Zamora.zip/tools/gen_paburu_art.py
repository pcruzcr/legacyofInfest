"""
Generador del arte de la Forma 1 de Paburu — "La Cabeza de Piedra".

Escribe en `assets/sprites/boss_paburu/`:

    boss_paburu_stone.png            4f · 64×64 · idle
    boss_paburu_hurt.png             4f · 64×64 · reacción al golpe
    boss_paburu_stone_slam.png       8f · 64×64 · pose de EL SELLO
    boss_paburu_stone_crack.png      8f · 64×64 · transición 1→2
    boss_paburu_stone_proyectil.png  3f ·  8×8  · piedra de STONE_SPIT

Carpeta propia a propósito (GDD §8): `assets/sprites/bosses/` la regenera
`tools/generate_all_assets.py`, que es código del profesor y pisaría esto.

Ejecutar desde la raíz del proyecto:  python tools/gen_paburu_art.py

Por qué generado y no dibujado a mano: GDD §6.3 lo prevé explícitamente, y
el pipeline mismo es evidencia de curso —
  - Unidad V  — modelo de iluminación (Lambert sobre un superelipsoide),
                rampa de tonos cuantizada y paleta canónica del cementerio.
  - Unidad VI — texturizado procedural: ruido de valor con interpolación
                suave (smoothstep) para el desgaste y el musgo.
Todo es determinista: mismo código, mismo PNG. No hay `random`.
"""
from __future__ import annotations

import math
import os
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

W = H = 64
CX = 32
CXf = 32.0

OUT_DIR = Path("assets/sprites/boss_paburu")

# ── Paleta ────────────────────────────────────────────────────────
# Rampa de 7 tonos de piedra verde. Deriva del verde espectral #00c864
# del Asset Bible desaturado hacia la piedra: es el mismo material que
# el tileset del cementerio, no un color nuevo.
RAMP = [
    (14, 22, 18), (24, 38, 29), (36, 54, 41), (50, 72, 55),
    (66, 90, 69), (86, 112, 86), (112, 138, 108),
]
MOSS = [(26, 58, 36), (38, 80, 48)]
EYE_DARK = (10, 28, 18)
EYE_LIT = (20, 240, 140)
EYE_CORE = (215, 255, 232)
CRACK_GLOW = (120, 255, 180)


def hw(y: int) -> float:
    """Semiancho de la cabeza por fila: define la silueta."""
    if y < 3:
        return 17
    if y < 7:
        return 23
    if y < 12:
        return 28
    if y < 19:
        return 30
    if y < 47:
        return 31
    if y < 54:
        return 30
    if y < 59:
        return 28
    return 26


# ── Ruido de valor determinista (Unidad VI) ───────────────────────
def _hash(x: int, y: int, s: int = 0) -> float:
    n = (x * 374761393 + y * 668265263 + s * 982451653) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 0xFFFF


def vnoise(x: float, y: float, scale: float, s: int = 0) -> float:
    """Ruido de valor con interpolación smoothstep 3t²−2t³."""
    fx, fy = x / scale, y / scale
    ix, iy = int(fx), int(fy)
    tx, ty = fx - ix, fy - iy
    tx = tx * tx * (3 - 2 * tx)
    ty = ty * ty * (3 - 2 * ty)
    a, b = _hash(ix, iy, s), _hash(ix + 1, iy, s)
    c, d = _hash(ix, iy + 1, s), _hash(ix + 1, iy + 1, s)
    return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty


def fbm(x: float, y: float, scale: float, s: int = 0) -> float:
    """Dos octavas: rompe la regularidad de una sola frecuencia."""
    return vnoise(x, y, scale, s) * 0.65 + vnoise(x, y, scale / 2.4, s + 31) * 0.35


class Head:
    """Mapa de tonos de la cabeza. Se esculpe desplazando índices de RAMP."""

    def __init__(self) -> None:
        self.tone: list[list[int | None]] = [[None] * W for _ in range(H)]
        self.moss: list[list[bool]] = [[False] * W for _ in range(H)]

    def inside(self, x: int, y: int) -> bool:
        return 0 <= y < H and 0 <= x < W and abs(x - CXf) <= hw(y)

    def shift(self, x: int, y: int, d: int) -> None:
        if self.inside(x, y) and self.tone[y][x] is not None:
            self.tone[y][x] = max(0, min(6, self.tone[y][x] + d))

    def build(self) -> None:
        """Volumen base: Lambert sobre un superelipsoide (Unidad V).

        El exponente 3.2 achata el frente y redondea solo los cantos —
        una esfera daría una bola, y una caja no daría volumen. La piedra
        tallada está en el medio.
        """
        for y in range(H):
            for x in range(W):
                if not self.inside(x, y):
                    continue
                nx = (x - CXf) / hw(y)
                ny = (y - 30) / 34.0
                z = max(1 - abs(nx) ** 3.2 - abs(ny) ** 3.4, 0.02) ** (1 / 3.2)
                length = math.sqrt(nx * nx + ny * ny + z * z) or 1.0
                lam = (nx / length) * -0.46 + (ny / length) * -0.58 + (z / length) * 0.68
                lam += (vnoise(x, y, 5.5) - 0.5) * 0.11
                lam += (vnoise(x, y, 2.1, 7) - 0.5) * 0.06
                self.tone[y][x] = max(0, min(6, round((lam + 0.16) * 6.9)))

    def outline(self) -> None:
        for y in range(H):
            for x in range(W):
                if not self.inside(x, y):
                    continue
                if not (self.inside(x - 1, y) and self.inside(x + 1, y)
                        and self.inside(x, y - 1) and self.inside(x, y + 1)):
                    self.tone[y][x] = 0

    def carve(self, x0: int, y0: int, x1: int, y1: int,
              depth: int = -4, round_bottom: int = 0) -> None:
        """Hueco tallado: pared superior en sombra, inferior con rebote."""
        for y in range(y0, y1 + 1):
            ins = max(0, y - (y1 - round_bottom)) if round_bottom else 0
            for x in range(x0 + ins, x1 - ins + 1):
                self.shift(x, y, depth)
        for x in range(x0, x1 + 1):
            self.shift(x, y0, -2)
            self.shift(x, y1, +3)
        for y in range(y0, y1 + 1):
            self.shift(x0, y, -1)
            self.shift(x1, y, +2)


def greca(h: Head, y0: int, y1: int) -> None:
    """Greca escalonada tallada en el tocado (motivo precolombino)."""
    n = y1 - y0
    for y in range(y0, y1 + 1):
        v = y - y0
        for x in range(W):
            if not h.inside(x, y):
                continue
            u = (x - 4) % 10
            on = (u in (0, 1)) or (v == 0 and u < 8) \
                or (v == n and 2 <= u < 10) or (u in (5, 6) and v >= n // 2)
            if on:
                h.shift(x, y, -4)
            elif u in (2, 3) and v == 1:
                h.shift(x, y, +2)


def greca_cells() -> list[list[tuple[int, int]]]:
    """Las celdas de la greca, agrupadas de izquierda a derecha.

    Sirven para encender los glifos en secuencia durante EL SELLO.
    """
    cells: dict[int, list[tuple[int, int]]] = {}
    for y in range(12, 19):
        for x in range(W):
            if abs(x - CXf) > hw(y):
                continue
            cells.setdefault((x - 4) // 10, []).append((x, y))
    return [cells[k] for k in sorted(cells)]


def sculpt(h: Head) -> None:
    """Los rasgos. El orden importa: cada paso pisa al anterior."""
    # ── Tocado ──
    for x in range(W):
        h.shift(x, 2, +3)
        h.shift(x, 10, -3)
        h.shift(x, 21, -4)
    for y in range(3, 10):
        for x in range(W):
            h.shift(x, y, +1)
    greca(h, 12, 18)
    for y in (19, 20):
        for x in range(W):
            h.shift(x, y, +2)

    # ── Ceja: cornisa saliente, inset de la silueta ──
    for y in range(30, 35):
        for x in range(CX - 26, CX + 27):
            h.shift(x, y, +2)
    for x in range(CX - 26, CX + 27):
        h.shift(x, 29, +3)
        h.shift(x, 35, -5)
        h.shift(x, 36, -3)

    # ── Cuencas: la fila 38 es la línea del EYE_BEAM ──
    h.carve(9, 36, 21, 43, -4)
    h.carve(43, 36, 55, 43, -4)

    # ── Nariz: pirámide truncada, tres planos ──
    # Sin línea de contorno ni sombra proyectada: el contraste entre los
    # planos hace todo el volumen. Una diagonal al costado se leía como
    # una cicatriz, no como sombra.
    for y in range(42, 50):
        w = 2 + (y - 42)
        for x in range(CX - w, CX + w + 1):
            if x < CX - w + 3:
                d = +3          # plano izquierdo, a la luz
            elif x > CX + w - 3:
                d = -2          # plano derecho, en sombra
            else:
                d = +1          # frente
            h.shift(x, y, d)
    for x in range(CX - 5, CX - 2):
        for y in (47, 48):
            h.shift(x, y, -6)
    for x in range(CX + 3, CX + 6):
        for y in (47, 48):
            h.shift(x, y, -6)
    for x in range(CX - 11, CX + 12):
        h.shift(x, 50, -5)

    # ── Boca de jaguar: comisuras caídas ──
    for x in range(15, 50):
        h.shift(x, 51, +3)
    h.carve(17, 52, 47, 57, -5, round_bottom=2)
    for x in range(20, 45, 6):          # dientes insinuados
        for y in range(53, 56):
            h.shift(x, y, +3)
    for x in range(16, 49):
        h.shift(x, 58, +3)
        h.shift(x, 59, +1)

    # ── Base ──
    for y in range(61, 64):
        for x in range(W):
            h.shift(x, y, -1)


def weather(h: Head) -> None:
    """Desgaste y musgo. Más musgo abajo y en las grietas: el agua baja."""
    for y in range(H):
        for x in range(W):
            if h.tone[y][x] is None or h.tone[y][x] == 0:
                continue
            bias = (y / H) ** 2 * 0.14
            if fbm(x, y, 5.0, 3) + bias > 0.88:
                h.moss[y][x] = True
            elif fbm(x, y, 2.8, 11) > 0.86:
                h.shift(x, y, -1)


EYE_PIXELS = [(x, y) for sx in (11, 45) for y in range(38, 42)
              for x in range(sx, sx + 9)]


FLASH = (200, 255, 220)


def render(h: Head, glow: float = 0.05, lit_cells: int = 0,
           brighten: int = 0, flash: float = 0.0) -> pygame.Surface:
    """`brighten` desplaza índices de la rampa; `flash` mezcla hacia un color.

    Para el golpe se usa `flash` y no `brighten`: subir índices satura todo
    en el tono 6 y aplana los rasgos tallados. Mezclar hacia un color
    conserva el contraste relativo — la cara sigue leyéndose iluminada.
    """
    s = pygame.Surface((W, H), pygame.SRCALPHA)
    cells = greca_cells()
    lit_set: set[tuple[int, int]] = set()
    for i in range(min(lit_cells, len(cells))):
        lit_set.update(cells[i])
    for y in range(H):
        for x in range(W):
            t = h.tone[y][x]
            if t is None:
                continue
            if brighten:
                t = max(0, min(6, t + brighten))
            col = MOSS[min(1, t // 4)] if h.moss[y][x] else RAMP[t]
            if (x, y) in lit_set and h.tone[y][x] is not None and h.tone[y][x] <= 2:
                col = CRACK_GLOW
            if flash > 0.0:
                col = tuple(int(col[i] + (FLASH[i] - col[i]) * flash) for i in range(3))
            s.set_at((x, y), col)
    for (x, y) in EYE_PIXELS:
        c = tuple(int(EYE_DARK[i] + (EYE_LIT[i] - EYE_DARK[i]) * glow) for i in range(3))
        s.set_at((x, y), c)
    if glow > 0.5:
        for (x, y) in EYE_PIXELS:
            if y in (39, 40) and (x % 9) in (3, 4, 5):
                s.set_at((x, y), EYE_CORE)
    return s


# ══════════════════════════════════════════════════════════════════
#  Fractura de la transición 1→2
# ══════════════════════════════════════════════════════════════════
#
# Cómo se rompe la piedra de verdad, y por qué importa el orden:
#
#   1. La fractura nace de un punto de presión INTERNO y se abre en
#      radios hacia la silueta. No son rayos dibujados encima.
#   2. Primero se ve SOMBRA, no luz: una piedra que se parte muestra el
#      hueco antes que cualquier brillo.
#   3. La fisura se ensancha y recién entonces la luz sale DESDE ADENTRO,
#      con el labio superior en sombra y el inferior encendido.
#   4. Al final la cáscara se cae: los píxeles de las fisuras más anchas
#      se vuelven transparentes y se ven agujeros reales en la silueta.
#      Es lo que pide el GDD §4 — "la cáscara de piedra cae".
#
# El brillo NUNCA se aplica a toda la cabeza: eso aplana los rasgos
# tallados. La luz vive solo dentro de las fisuras.

# El origen va ARRIBA de la ceja, no entre los ojos: con el origen bajo,
# los radios salían atravesando las cuencas y a los tres frames la cara ya
# no se leía como cara. Desde el tocado, la fractura baja y llega al rostro
# recién al final, que además es lo que cuenta el canon — la cabeza se
# agrieta y de las grietas salen los tres espíritus.
CRACK_ORIGIN = (32.0, 20.0)
CRACK_RAYS = 7
CRACK_STEP = 4.6
CRACK_SEGMENTS = 11


def _crack_paths() -> list[list[tuple[float, float]]]:
    """Radios de fractura con desvío determinista, más ramas secundarias."""
    paths: list[list[tuple[float, float]]] = []
    for i in range(CRACK_RAYS):
        ang = math.radians(-90 + i * (360.0 / CRACK_RAYS) + 13)
        x, y = CRACK_ORIGIN
        pts = [(x, y)]
        for k in range(CRACK_SEGMENTS):
            ang += (_hash(i, k, 5) - 0.5) * 0.85     # la grieta serpentea
            x += math.cos(ang) * CRACK_STEP
            y += math.sin(ang) * CRACK_STEP
            pts.append((x, y))
            if not (-4 <= x <= W + 4 and -4 <= y <= H + 4):
                break
        paths.append(pts)
        # Rama: sale a media altura del radio, con menos recorrido.
        if len(pts) > 5:
            bx, by = pts[4]
            bang = ang + (0.9 if i % 2 else -0.9)
            bpts = [(bx, by)]
            for k in range(5):
                bang += (_hash(i, k, 17) - 0.5) * 0.7
                bx += math.cos(bang) * CRACK_STEP
                by += math.sin(bang) * CRACK_STEP
                bpts.append((bx, by))
            paths.append(bpts)
    return paths


CRACK_PATHS = _crack_paths()


def crack_field(progress: float) -> dict[tuple[int, int], float]:
    """Intensidad de fractura por píxel, 0..1 (1 = centro de la fisura).

    El ancho crece con el avance: hilo de 1 px al principio, fisura de
    ~3 px al final. Se estampa un disco por punto del trazo y se queda
    con el máximo, que es lo que da el perfil suave del borde.
    """
    field: dict[tuple[int, int], float] = {}
    radius = 0.6 + 2.6 * progress
    for pi, path in enumerate(CRACK_PATHS):
        # Cada grieta arranca en un momento distinto y tarda en completarse.
        start = (pi % 5) * 0.055
        local = (progress - start) / 0.50
        if local <= 0:
            continue
        local = min(local, 1.0)
        upto = max(2, int(len(path) * local))
        for k in range(upto - 1):
            x0, y0 = path[k]
            x1, y1 = path[k + 1]
            steps = max(int(max(abs(x1 - x0), abs(y1 - y0))) + 1, 2)
            for s in range(steps):
                cx = x0 + (x1 - x0) * s / steps
                cy = y0 + (y1 - y0) * s / steps
                r = int(radius) + 1
                for dy in range(-r, r + 1):
                    for dx in range(-r, r + 1):
                        px, py = int(cx) + dx, int(cy) + dy
                        if not (0 <= px < W and 0 <= py < H):
                            continue
                        d = math.hypot(cx - px, cy - py)
                        if d > radius:
                            continue
                        v = 1.0 - d / radius
                        if v > field.get((px, py), 0.0):
                            field[(px, py)] = v
    return field


CRACK_SHADOW = (8, 14, 11)      # el hueco: más oscuro que el tono 0
CRACK_LIP = (150, 195, 155)     # labio inferior de la fisura, a la luz


def build_crack(h: Head) -> list[pygame.Surface]:
    """Los 8 frames de la fractura, del primer hilo a la cáscara caída."""
    frames: list[pygame.Surface] = []
    for i in range(8):
        p = (i + 1) / 8.0
        # El brillo de los ojos sí crece parejo: es la presión de adentro.
        f = render(h, glow=min(1.0, 0.15 + p * 1.15))
        field = crack_field(p)
        # La luz aparece recién pasada la mitad: primero solo hay sombra.
        light = max(0.0, (p - 0.42) / 0.58)
        eyes = set(EYE_PIXELS)
        for (x, y), v in field.items():
            if f.get_at((x, y)).a == 0:
                continue
            # Los ojos encendidos son el hilo conductor de la animación:
            # no se tapan con grieta hasta el final.
            if (x, y) in eyes and p < 0.80:
                continue
            if v > 0.72:
                # Núcleo de la fisura: de sombra pura a luz. No se vuelve
                # transparente — sobre el fondo oscuro de la arena un
                # agujero se ve idéntico a una grieta negra, así que la
                # rotura la vende la luz, no la ausencia de píxeles.
                if v > 0.92 and light > 0.5:
                    f.set_at((x, y), EYE_CORE)       # centro incandescente
                    continue
                col = tuple(
                    int(CRACK_SHADOW[c] + (CRACK_GLOW[c] - CRACK_SHADOW[c]) * light)
                    for c in range(3)
                )
                f.set_at((x, y), col)
            elif v > 0.42:
                # Labio de la fisura: arriba en sombra, abajo iluminado.
                below = field.get((x, y - 1), 0.0) > v
                if below and light > 0.25:
                    col = tuple(
                        int(RAMP[3][c] + (CRACK_LIP[c] - RAMP[3][c]) * light)
                        for c in range(3)
                    )
                else:
                    col = CRACK_SHADOW
                f.set_at((x, y), col)
        frames.append(f)
    return frames


def save_sheet(frames: list[pygame.Surface], name: str,
               fw: int = W, fh: int = H) -> None:
    sheet = pygame.Surface((fw * len(frames), fh), pygame.SRCALPHA)
    for i, f in enumerate(frames):
        sheet.blit(f, (i * fw, 0))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    path = OUT_DIR / name
    pygame.image.save(sheet, str(path))
    print(f"  {path}  {len(frames)}f  {fw}x{fh}")


def build_projectile() -> list[pygame.Surface]:
    """La piedra de STONE_SPIT: 3 rotaciones de un fragmento de 8×8."""
    shapes = [
        ["..XXX...", ".XXXXX..", "XXXXXXX.", "XXXXXXX.", ".XXXXXX.", "..XXXX..", "...XX...", "........"],
        ["...XX...", "..XXXX..", ".XXXXXX.", "XXXXXXXX", ".XXXXXX.", ".XXXXX..", "..XXX...", "........"],
        ["..XXX...", ".XXXXXX.", ".XXXXXX.", "XXXXXXX.", "XXXXXX..", ".XXXX...", "..XX....", "........"],
    ]
    def solid(sh: list[str], x: int, y: int) -> bool:
        return 0 <= x < 8 and 0 <= y < 8 and sh[y][x] == "X"

    out = []
    for sh in shapes:
        s = pygame.Surface((8, 8), pygame.SRCALPHA)
        for y, row in enumerate(sh):
            for x, ch in enumerate(row):
                if ch != "X":
                    continue
                # Contorno oscuro, luz arriba-izquierda, sombra abajo-derecha.
                # Sin dither: a 8px el tramado se lee como ruido, no como textura.
                if not (solid(sh, x - 1, y) and solid(sh, x + 1, y)
                        and solid(sh, x, y - 1) and solid(sh, x, y + 1)):
                    col = RAMP[1]
                elif not solid(sh, x - 1, y - 1):
                    col = RAMP[5]
                elif not solid(sh, x + 1, y + 1):
                    col = RAMP[2]
                else:
                    col = RAMP[4]
                s.set_at((x, y), col)
        out.append(s)
    return out


def main() -> None:
    pygame.init()
    pygame.display.set_mode((1, 1))

    h = Head()
    h.build()
    sculpt(h)
    h.outline()
    weather(h)

    print("Generando arte de la Forma 1 de Paburu:")

    # idle: los ojos apenas laten, la cabeza está dormida
    save_sheet([render(h, glow=0.05 + 0.05 * math.sin(i / 4 * 2 * math.pi))
                for i in range(4)], "boss_paburu_stone.png")

    # hurt: destello y vuelta (mezcla de color, no salto de rampa)
    save_sheet([render(h, glow=0.35, flash=f) for f in (0.62, 0.40, 0.20, 0.06)],
               "boss_paburu_hurt.png")

    # EL SELLO: los glifos de la greca se encienden en secuencia
    slam = []
    cells = len(greca_cells())
    for i in range(8):
        lit = int(cells * min(1.0, i / 5.0))
        slam.append(render(h, glow=min(1.0, 0.2 + i * 0.16), lit_cells=lit,
                           brighten=1 if i >= 5 else 0))
    save_sheet(slam, "boss_paburu_stone_slam.png")

    save_sheet(build_crack(h), "boss_paburu_stone_crack.png")

    save_sheet(build_projectile(), "boss_paburu_stone_proyectil.png", 8, 8)
    print("Listo.")


if __name__ == "__main__":
    main()
