"""
Generador del TMX de la arena de Paburu (Stage 4-2).

Produce assets/maps/boss_paburu/boss_paburu.tmx siguiendo:
  - 06_TMX_SPEC (8 capas obligatorias, tipos de objeto, spawn = pies)
  - GDD §3 (croquis de la arena)
  - El formato exacto de assets/maps/boss_venado/boss_venado.tmx

Arena: 50 x 38 tiles = 800 x 608 px (una pantalla, cámara fija).
Ejecutar desde la raíz del proyecto:  python tools/gen_paburu_tmx.py

Depende de dos generadores que hay que correr antes si no existen:
    python tools/gen_paburu_tileset.py   →  assets/tilesets/tileset_paburu.png
    python tools/gen_paburu_fondos.py    →  assets/backgrounds/paburu/

TILESET Y FONDOS PROPIOS: `tileset_cemetery.png` y `backgrounds/final/`
son placeholders que regenera `tools/generate_all_assets.py` (código del
profesor) con tres colores planos. Usarlos significaba perder el trabajo
la próxima vez que alguien corriera ese script. Ver los dos generadores.

LA COLISIÓN NO SE TOCA. La geometría jugable está verificada —saltos de
80 px alcanzables, refugios accesibles, one-way correctas, y las dos
plataformas bajas flanqueando la zona del sello— así que este archivo
puede cambiar todo lo visual pero los rects de `<objectgroup Collision>`
quedan exactamente como estaban.
"""
from pathlib import Path

# ── Dimensiones ────────────────────────────────────────────────
TW = TH = 16                 # tamaño de tile
COLS, ROWS = 50, 38          # 800 x 608 px
W_PX, H_PX = COLS * TW, ROWS * TH

# ── GIDs de tileset_paburu.png (ver tools/gen_paburu_tileset.py) ──
G_EMPTY = 1
G_SLAB = (2, 3, 4, 5)        # losa del suelo, 4 variantes
G_WALL = (6, 7, 8)           # piedra de muro
G_EARTH = (9, 10, 11)        # tierra bajo el suelo
G_TOMB_BASE, G_TOMB_BODY, G_TOMB_TOP = 12, 13, 14
G_CROSS_TOP, G_CROSS_LOW = 15, 16
G_OBELISK = (17, 18, 19)     # remate, fuste, base
G_GLYPH = (20, 21, 22)       # losa grabada
G_RUBBLE = (23, 24, 25)      # escombro
G_BRAZIER = 26               # cuenco de fuego
# Siluetas de fondo: mismas formas, valor muy oscuro. Son las que crean la
# separación de profundidad entre el fondo y la zona jugable.
G_SIL_BODY, G_SIL_TOP, G_SIL_CROSS_TOP, G_SIL_CROSS_LOW = 27, 28, 29, 30
# Arquitectura del templo (ver gen_paburu_tileset.py, GIDs 31-45).
G_COL_CAP, G_COL_SHAFT, G_COL_BASE, G_COL_BROKEN = 31, 32, 33, 34
G_ARCH = (35, 36, 37)              # arranque izq, clave, arranque der
G_LEDGE = (38, 39, 40)             # cornisa: extremo izq, centro, extremo der
G_SIL_COL_CAP, G_SIL_COL_SHAFT, G_SIL_COL_BASE = 41, 42, 43
G_SIL_ARCH_L, G_SIL_ARCH_R = 44, 45
G_SIL_BLOCK_L, G_SIL_BLOCK_R = 46, 47      # fuste del pilar, mitades L/R
G_SIL_BROKEN_L, G_SIL_BROKEN_R = 48, 49    # remate quebrado, mitades L/R
G_FAR_BODY, G_FAR_TOP, G_FAR_CROSS = 50, 51, 52   # cementerio lejano

# ── Geometría (px) — ver GDD §3.1 ──────────────────────────────
FLOOR_Y = 560                      # superficie del suelo
CEIL_H = 16
WALL_W = 16
NICHE_Y = 480                      # techo de los refugios laterales
PLAT_LOW_Y = 480                   # plataformas one-way bajas
PLAT_HIGH_Y = 400                  # plataformas one-way altas

NICHE_L = (16, NICHE_Y, 96, 16)    # x, y, w, h  (SÓLIDO: alero del refugio izq)
NICHE_R = (688, NICHE_Y, 96, 16)   # (SÓLIDO: alero del refugio der)
PLAT_LL = (144, PLAT_LOW_Y, 144, 16)   # one-way
PLAT_RL = (512, PLAT_LOW_Y, 144, 16)   # one-way
PLAT_LH = (192, PLAT_HIGH_Y, 112, 16)  # one-way
PLAT_RH = (496, PLAT_HIGH_Y, 112, 16)  # one-way

SEAL_ZONE = (288, FLOOR_Y, 224, 48)    # zona central libre: aquí se graba el sello
BOSS_POS = (368, 496)                  # cabeza de piedra 64x64 apoyada en el suelo
SPAWN = (64, FLOOR_Y)                  # spawn: Y = PIES del jugador (spec §6.1)

# Cuencos de fuego (GDD §3.1). Fuera de la zona del sello a propósito:
# ahí emergen las columnas y se pisarían visualmente.
BRAZIERS = (128, 240, 560, 672)


def blank():
    return [[0] * COLS for _ in range(ROWS)]


def fill_rect(grid, x, y, w, h, gid):
    """Rellena en coordenadas de PÍXEL con un GID fijo."""
    for ty in range(y // TH, (y + h) // TH):
        for tx in range(x // TW, (x + w) // TW):
            if 0 <= ty < ROWS and 0 <= tx < COLS:
                grid[ty][tx] = gid


def fill_varied(grid, x, y, w, h, gids, seed=0):
    """Igual que fill_rect pero alternando variantes.

    El hash es determinista: mismo código, mismo mapa. Rompe la
    repetición sin usar `random`, que daría un TMX distinto cada vez.
    """
    for ty in range(y // TH, (y + h) // TH):
        for tx in range(x // TW, (x + w) // TW):
            if 0 <= ty < ROWS and 0 <= tx < COLS:
                n = (tx * 73856093 ^ ty * 19349663 ^ seed * 83492791) & 0xFFFF
                grid[ty][tx] = gids[n % len(gids)]


def put(grid, x, y, gid):
    """Un tile suelto en coordenadas de PÍXEL."""
    tx, ty = x // TW, y // TH
    if 0 <= ty < ROWS and 0 <= tx < COLS:
        grid[ty][tx] = gid


def ledge(grid, x, y, w, h):
    """Una cornisa: extremos rematados y tramo central repetido.

    Antes las seis salientes (los dos aleros y las cuatro plataformas
    one-way) se rellenaban con la MISMA losa del suelo, así que en pantalla
    eran tiras de ladrillo flotando en el aire: nada indicaba dónde empezaba
    y dónde terminaba la pieza. Con extremos propios y la sombra que trae el
    tile, se leen como salientes de un templo.
    """
    n = max(1, w // TW)
    for i in range(n):
        gid = G_LEDGE[0] if i == 0 else G_LEDGE[2] if i == n - 1 else G_LEDGE[1]
        put(grid, x + i * TW, y, gid)
    # Si la pieza es más alta que un tile, lo de abajo es muro macizo.
    for ty in range(y + TH, y + h, TH):
        fill_varied(grid, x, ty, w, TH, G_WALL, seed=7)


def column(grid, x, y_top, y_base, cap=G_COL_CAP, shaft=G_COL_SHAFT,
           base=G_COL_BASE):
    """Columna desde `y_top` (capitel) hasta `y_base` (basa), en píxeles."""
    put(grid, x, y_top, cap)
    for y in range(y_top + TH, y_base, TH):
        put(grid, x, y, shaft)
    put(grid, x, y_base, base)


def tomb(grid, x, y_base, height=2, top=G_TOMB_TOP):
    """Una lápida apoyada en `y_base`, de `height` tiles + remate."""
    for i in range(height):
        put(grid, x, y_base - TH * (i + 1), G_TOMB_BODY)
    put(grid, x, y_base - TH * (height + 1), top)
    put(grid, x, y_base, G_TOMB_BASE)


def csv(grid):
    return ",".join(str(v) for row in grid for v in row)


# ── Capa Terrain: la geometría sólida y visible ────────────────
terrain = blank()
fill_varied(terrain, 0, FLOOR_Y, W_PX, TH, G_SLAB, seed=1)              # superficie
fill_varied(terrain, 0, FLOOR_Y + TH, W_PX, H_PX - FLOOR_Y - TH, G_EARTH, seed=2)
fill_varied(terrain, 0, 0, W_PX, CEIL_H, G_WALL, seed=3)                # techo
fill_varied(terrain, 0, 0, WALL_W, H_PX, G_WALL, seed=4)                # muro izq
fill_varied(terrain, W_PX - WALL_W, 0, WALL_W, H_PX, G_WALL, seed=5)    # muro der
# Aleros y plataformas: cornisas, no losa de suelo. La GEOMETRÍA no cambia
# —mismos rectángulos, misma capa Collision—, cambia solo cómo se ven.
for r in (NICHE_L, NICHE_R, PLAT_LL, PLAT_RL, PLAT_LH, PLAT_RH):
    ledge(terrain, *r)

# Columnas que sostienen los aleros de los refugios. Son decorativas —van
# en Terrain pero fuera de todo rectángulo de colisión—, y dan la lectura
# de que el alero se apoya en algo en vez de flotar.
for cx in (96, 688):
    column(terrain, cx, NICHE_Y + TH, FLOOR_Y - TH)

# ── Capa Terrain_Detail: el cementerio propiamente dicho ───────
# Decorativo puro: no tiene colisión. Todo lo que está acá se puede
# atravesar. Por eso las lápidas van contra los bordes y no en el centro,
# donde estorbarían la lectura de los ataques.
detail = blank()

# Losas grabadas en el suelo, a los flancos de la zona del sello. En la
# zona misma NO: ahí el boss dibuja su propio sello y se ensuciaría.
for gx in (96, 160, 224, 576, 640, 704):
    put(detail, gx, FLOOR_Y, G_GLYPH[(gx // 64) % 3])

# Lápidas contra las paredes, detrás de los refugios.
for gx in (32, 64):
    tomb(detail, gx, FLOOR_Y - TH, height=1)
for gx in (720, 752):
    tomb(detail, gx, FLOOR_Y - TH, height=1)

# Cruces y obelisco bajo las plataformas altas, para dar profundidad.
put(detail, 176, FLOOR_Y - TH * 2, G_CROSS_TOP)
put(detail, 176, FLOOR_Y - TH, G_CROSS_LOW)
put(detail, 608, FLOOR_Y - TH * 2, G_CROSS_TOP)
put(detail, 608, FLOOR_Y - TH, G_CROSS_LOW)
for gx in (272, 528):
    put(detail, gx, FLOOR_Y - TH * 3, G_OBELISK[0])
    put(detail, gx, FLOOR_Y - TH * 2, G_OBELISK[1])
    put(detail, gx, FLOOR_Y - TH, G_OBELISK[2])

# Escombro repartido sobre el suelo.
for gx in (112, 336, 464, 688):
    put(detail, gx, FLOOR_Y - TH, G_RUBBLE[(gx // 48) % 3])

# Segunda fila de lápidas, apoyada sobre las plataformas one-way. Antes
# esta capa tenía 36 tiles en todo el mapa —un 1% de ocupación— y el
# cementerio se veía como cuatro adornos sueltos contra las paredes. Las
# plataformas son el sitio natural: dan una línea de horizonte intermedia
# sin invadir el suelo, donde el jugador esquiva.
for gx in (160, 256, 528, 624):
    tomb(detail, gx, PLAT_LOW_Y - TH, height=1)
for gx in (208, 576):
    put(detail, gx, PLAT_HIGH_Y - TH * 2, G_CROSS_TOP)
    put(detail, gx, PLAT_HIGH_Y - TH, G_CROSS_LOW)

# Musgo y escombro sobre las cornisas: las ata al resto del cementerio.
for gx in (176, 272, 544, 640):
    put(detail, gx, PLAT_LOW_Y - TH, G_RUBBLE[(gx // 32) % 3])

# Los cuatro cuencos de fuego (las luces las pone la escena).
for gx in BRAZIERS:
    put(detail, gx, FLOOR_Y - TH, G_BRAZIER)

# ── Capa BG_Near: lápidas al fondo, entre el parallax y la arena ──
# Los fondos de `assets/backgrounds/paburu/` ya traen el cementerio
# lejano. Esta capa agrega una fila intermedia a la escala de la arena,
# para que no haya un salto entre el fondo pintado y el suelo jugable.
bg_near = blank()
for gx in range(48, W_PX - 48, 80):
    n = gx // 80
    if n % 4 == 2:                       # una cruz cada tantas lápidas
        put(bg_near, gx, FLOOR_Y - TH * 2, G_SIL_CROSS_TOP)
        put(bg_near, gx, FLOOR_Y - TH, G_SIL_CROSS_LOW)
        continue
    h = 1 + (n % 2)
    for i in range(h):
        put(bg_near, gx, FLOOR_Y - TH * (i + 1), G_SIL_BODY)
    put(bg_near, gx, FLOOR_Y - TH * (h + 1), G_SIL_TOP)

# Columnata del templo. El problema no era el suelo ni el cielo: era que
# entre uno y otro había ~300 px de vacío morado, justo la franja donde
# ocurre el combate. Estas columnas dan escala vertical y encierran la
# arena, y van en silueta (GIDs 41-43) para quedar DETRÁS de la zona
# jugable — si usaran la piedra iluminada competirían con el boss.
# Se dejan libres los 160 px centrales: ahí vuela el STONE_SPIT y baja el
# EYE_BEAM, y cualquier cosa ahí ensucia la lectura del ataque.
#   (x del borde izquierdo, y del quiebre). Cada pilar mide 32 px de ancho.
#   Las alturas son desparejas a propósito: cuatro ruinas de la misma altura
#   vuelven a leerse como una valla.
RUINAS = ((64, 208), (208, 320), (560, 288), (704, 176))
RUINA_BASE_Y = 544
for cx, top_y in RUINAS:
    put(bg_near, cx, top_y, G_SIL_BROKEN_L)
    put(bg_near, cx + TW, top_y, G_SIL_BROKEN_R)
    for y in range(top_y + TH, RUINA_BASE_Y + TH, TH):
        put(bg_near, cx, y, G_SIL_BLOCK_L)
        put(bg_near, cx + TW, y, G_SIL_BLOCK_R)

# ── Capa BG_Far: el cementerio que se pierde en la distancia ───
# Antes esta capa iba VACÍA y todo el fondo lejano lo resolvían los PNG de
# parallax. Funcionaba, pero dejaba dos de las ocho capas del TMX sin un
# solo tile. Acá va una hilera apretada de lápidas pequeñas, en el valor
# más oscuro del atlas (GID 50-52): sugiere que el camposanto sigue más
# allá de la arena en vez de terminar en el borde de la pantalla.
bg_far = blank()
FAR_BASE_Y = 496
for i, gx in enumerate(range(32, W_PX - 32, 32)):
    if i % 5 == 3:
        put(bg_far, gx, FAR_BASE_Y - TH, G_FAR_CROSS)
        continue
    alto = 1 + (i % 3) // 2               # una o dos lápidas de alto
    for k in range(alto):
        put(bg_far, gx, FAR_BASE_Y - TH * k, G_FAR_BODY)
    put(bg_far, gx, FAR_BASE_Y - TH * alto, G_FAR_TOP)

# ── Capa BG_Mid: ruinas a media distancia ──────────────────────
# Escalón intermedio entre el cementerio lejano y los pilares de BG_Near.
# Usa las columnas de UN tile de ancho (GID 41-43) contra los pilares de
# DOS de la capa de adelante: el ancho es lo que ordena la profundidad,
# porque a esta escala no hay perspectiva que ayude.
bg_mid = blank()
for cx, top_y in ((112, 352), (304, 400), (464, 384), (656, 336)):
    column(bg_mid, cx, top_y, 512,
           cap=G_SIL_COL_CAP, shaft=G_SIL_COL_SHAFT, base=G_SIL_COL_BASE)

# ── Capa FG_Overlay: primer plano, se dibuja sobre el jugador ──
# Escombro en las cuatro esquinas y un borde de tierra abajo. Enmarca la
# escena y da profundidad sin tapar nada de la zona de combate: todo lo de
# acá vive fuera del rectángulo donde el jugador pelea.
fg = blank()
for gx in (0, 16):
    put(fg, gx, H_PX - TH * 2, G_RUBBLE[0])
    put(fg, gx, H_PX - TH, G_RUBBLE[1])
for gx in (W_PX - 32, W_PX - 16):
    put(fg, gx, H_PX - TH * 2, G_RUBBLE[2])
    put(fg, gx, H_PX - TH, G_RUBBLE[0])
# Franja de tierra suelta contra el borde inferior, de lado a lado.
for gx in range(0, W_PX, TW):
    if (gx // TW) % 3:
        put(fg, gx, H_PX - TH, G_RUBBLE[(gx // TW) % 3])

layers = [
    ("BG_Far", bg_far),       # + bg_paburu_far.png (cielo, luna, montañas)
    ("BG_Mid", bg_mid),       # + bg_paburu_mid.png (los guardianes, niebla)
    ("BG_Near", bg_near),
    ("Terrain", terrain),
    ("Terrain_Detail", detail),
]

# ── Objetos ────────────────────────────────────────────────────
objects = f'''  <object id="1" type="PlayerSpawn" name="PlayerSpawn_01" x="{SPAWN[0]}" y="{SPAWN[1]}"/>
  <object id="2" type="BossPaburu" name="BossPaburu_01" x="{BOSS_POS[0]}" y="{BOSS_POS[1]}">
   <properties>
    <property name="max_health" type="float" value="20.0"/>
   </properties>
  </object>
  <object id="3" type="CameraLock" name="ArenaLock" x="0" y="0" width="{W_PX}" height="{H_PX}">
   <properties>
    <property name="lock_x" type="bool" value="true"/>
    <property name="lock_y" type="bool" value="true"/>
   </properties>
  </object>
  <object id="4" type="NextTrigger" name="NextTrigger_01" x="{W_PX - 32}" y="-64" width="16" height="16"/>
  <object id="5" type="Checkpoint" name="Checkpoint_01" x="{SPAWN[0]}" y="{SPAWN[1]}" width="16" height="32">
   <properties>
    <property name="checkpoint_id" type="int" value="1"/>
   </properties>
  </object>'''

# ── Colisión: sólidos primero, one-way (type="Platform") después ──
collision = f'''   <object id="10" name="Floor" x="0" y="{FLOOR_Y}" width="{W_PX}" height="{H_PX - FLOOR_Y}"/>
   <object id="11" name="Ceiling" x="0" y="0" width="{W_PX}" height="{CEIL_H}"/>
   <object id="12" name="LeftWall" x="0" y="0" width="{WALL_W}" height="{H_PX}"/>
   <object id="13" name="RightWall" x="{W_PX - WALL_W}" y="0" width="{WALL_W}" height="{H_PX}"/>
   <object id="14" name="NicheLeft" x="{NICHE_L[0]}" y="{NICHE_L[1]}" width="{NICHE_L[2]}" height="{NICHE_L[3]}"/>
   <object id="15" name="NicheRight" x="{NICHE_R[0]}" y="{NICHE_R[1]}" width="{NICHE_R[2]}" height="{NICHE_R[3]}"/>
   <object id="16" name="PlatformLeftLow" type="Platform" x="{PLAT_LL[0]}" y="{PLAT_LL[1]}" width="{PLAT_LL[2]}" height="{PLAT_LL[3]}"/>
   <object id="17" name="PlatformRightLow" type="Platform" x="{PLAT_RL[0]}" y="{PLAT_RL[1]}" width="{PLAT_RL[2]}" height="{PLAT_RL[3]}"/>
   <object id="18" name="PlatformLeftHigh" type="Platform" x="{PLAT_LH[0]}" y="{PLAT_LH[1]}" width="{PLAT_LH[2]}" height="{PLAT_LH[3]}"/>
   <object id="19" name="PlatformRightHigh" type="Platform" x="{PLAT_RH[0]}" y="{PLAT_RH[1]}" width="{PLAT_RH[2]}" height="{PLAT_RH[3]}"/>'''

# ── Ensamblado del TMX ─────────────────────────────────────────
parts = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    (
        f'<map version="1.10" tiledversion="1.11.0" orientation="orthogonal" '
        f'renderorder="right-down" width="{COLS}" height="{ROWS}" '
        f'tilewidth="{TW}" tileheight="{TH}" infinite="0" '
        f'nextlayerid="9" nextobjectid="20">'
    ),
    ' <properties>',
    '  <property name="stage_id" value="boss_paburu"/>',
    '  <property name="stage_name" value="4-2  EL GRAN SHAMAN PABURU"/>',
    '  <property name="time_limit" type="int" value="0"/>',
    '  <property name="bgm_track" value="bgm_paburu"/>',
    '  <property name="background_zone" value="paburu"/>',
    '  <property name="gravity_multiplier" type="float" value="1.0"/>',
    ' </properties>',
    ' <tileset firstgid="1" name="tileset_paburu" tilewidth="16" tileheight="16" tilecount="64" columns="8">',
    '  <image source="../../tilesets/tileset_paburu.png" width="128" height="128"/>',
    ' </tileset>',
]

for i, (name, grid) in enumerate(layers, start=1):
    parts.append(f' <layer id="{i}" name="{name}" width="{COLS}" height="{ROWS}">')
    parts.append(f'  <data encoding="csv">{csv(grid)}</data>')
    parts.append(' </layer>')

parts.append(' <objectgroup id="6" name="Objects">')
parts.append(objects)
parts.append(' </objectgroup>')
parts.append(' <objectgroup id="7" name="Collision">')
parts.append(collision)
parts.append(' </objectgroup>')
parts.append(f' <layer id="8" name="FG_Overlay" width="{COLS}" height="{ROWS}">')
parts.append(f'  <data encoding="csv">{csv(fg)}</data>')
parts.append(' </layer>')
parts.append('</map>')

out = Path("assets/maps/boss_paburu/boss_paburu.tmx")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text("\n".join(parts), encoding="utf-8")

_filled = {n: sum(1 for r in g for v in r if v) for n, g in layers}
_filled["FG_Overlay"] = sum(1 for r in fg for v in r if v)
print(f"TMX generado: {out}")
print(f"  Arena: {COLS}x{ROWS} tiles = {W_PX}x{H_PX} px (una pantalla, cámara fija)")
print("  Tileset: tileset_paburu.png   ·   Fondos: backgrounds/paburu/")
print(f"  Spawn del jugador: {SPAWN} (Y = pies)")
print(f"  Paburu: {BOSS_POS} (cabeza de piedra 64x64 apoyada en el suelo)")
print(f"  Zona del sello: x={SEAL_ZONE[0]}..{SEAL_ZONE[0]+SEAL_ZONE[2]} (libre de decorado)")
print(f"  Cuencos de fuego en x={BRAZIERS}")
for n, c in _filled.items():
    print(f"  capa {n:16s} {c:5d} tiles")
