# Reporte de bugs del motor — hallazgos y correcciones

**Autor:** Alejandro Josué Rodríguez Zamora
**Contexto:** trabajo sobre Stage 4-2 (El Gran Shaman Paburu). Los bugs
aparecieron al construir el boss y el escenario; se corrigieron con permiso
explícito del profesor.

**Línea base antes de tocar nada:** `601 passed, 34 warnings`
**Después de 29 correcciones:** `601 passed, 27 warnings` — sin regresiones.

Los 601 de ahora **valen más que los 601 de antes**: once de aquellos no podían
fallar nunca (BUG-101). Al hacerlos asertar de verdad aparecieron cuatro fallas
ocultas, todas corregidas.

Cada cambio está marcado en el código con `BUG-0XX FIX`:
`grep -rn "BUG-[01][0-9][0-9] FIX" src/ scripts/ tests/`

**Numeración:** los BUG-071 a 081 salieron del trabajo sobre Stage 4-2. Los
BUG-101 en adelante son de la auditoría posterior. Se saltó el rango 082-099
a propósito para no chocar con la serie que el profesor usa en su rama.

---

## Resumen

| # | Archivo | Severidad | Qué estaba roto |
|---|---|---|---|
| 071 | `framework/stage/stage_loader.py` | **Alta** | El parallax no se veía en ningún stage |
| 072 | `framework/stage/drawing_system.py` | **Alta** | Las capas de fondo perdían la transparencia |
| 073 | `framework/stage/drawing_system.py` | Baja | Caché de mosaico sin considerar el tamaño |
| 074 | `engine/audio/audio_manager.py` | **Alta** | El juego moría si faltaba un archivo de música |
| 075 | `framework/stage/stage_loader.py` + `scenes/stage_scene.py` | **Alta** | `StageData.zone` no existía: iluminación por zona y música dinámica eran código muerto |
| 076 | `framework/scenes/stage_scene.py` | Media | Luces posicionadas para la resolución vieja |
| 077 | `framework/entities/boss_base.py` | Media | `_load_boss_sprites` solo servía para el Venado |
| 078 | `framework/entities/boss_base.py` | **Alta** | Los bosses heredaban rango de detección de enemigo de patrulla |
| 079 | `scripts/grade_boss.py` | Media | Categoría de nota imposible de aprobar |
| 080 | `scripts/grade_boss.py` | Baja | Crash con rutas relativas |
| 081 | `engine/utils/asset_loader.py` | Baja | `ZeroDivisionError` sin contexto |
| 101 | `tests/test_menu_navigation.py` | **Alta** | Once tests que no podían fallar nunca |
| 102 | `tests/test_menu_navigation.py` | **Alta** | El harness no consumía la cola de eventos |
| 103 | `engine/scenes/keybinding_scene.py` | **Alta** | La pantalla de controles crasheaba al reasignar una tecla |
| 104 | `engine/scenes/scene_registry.py` | **Alta** | La entrada "Achievements" del menú no hacía nada |
| 105 | `framework/stage/stage_loader.py` | Media | Las zonas de daño ignoraban su cooldown en el primer golpe |
| 106 | `framework/entities/player.py` | **Alta** | El save guardaba una vida máxima incorrecta |
| 107 | `engine/ui/bitmap_font.py` | Media | Caché de texto sin techo |
| 108 | `engine/utils/surface_pool.py` | Media | Caché de sprites espejados sin techo y con clave reciclable |
| 109 | `framework/entities/boss_base.py` | Baja | `speed_multiplier` se leía y se descartaba |
| 110 | `engine/scenes/bestiary_scene.py` | **Alta** | Salir de la bestiary desde el título dejaba el juego en negro |
| 111 | `tests/test_menu_navigation.py` | Baja | El test medía más corto que los fundidos |
| 112 | `engine/core/difficulty.py` | **Alta** | Guardar la dificultad como texto rompía el spawn de **todos** los enemigos |
| 113 | `engine/core/app.py` | **Alta** | La dificultad guardada nunca se aplicaba al arrancar |
| 114 | `framework/stage/boss_rush_mode.py` | Media | El Boss Rush no podía terminarse ni puntuaba al jefe final |
| 115 | `framework/scenes/stage_scene.py` | Media | `on_enter()` no era idempotente; la limpieza estaba duplicada y divergida |
| 116 | `engine/scenes/achievement_screen.py` | Baja | Escena rota e inalcanzable (eliminada) |
| 117 | `framework/scenes/stage_scene.py` | **Crítica** | El primer golpe conectado dejaba el juego en cámara lenta permanente |
| 118 | `engine/core/clock.py` + `framework/stage/collision_system.py` | Media | El hitstop duraba 27 frames en vez de 4 |

---

## BUG-071 · El parallax no se veía en ningún stage

**Archivo:** `src/framework/stage/stage_loader.py`, en `StageLoader.load()`

**Síntoma.** La propiedad `background_zone` del TMX cargaba las tres imágenes
en `stage.background_layers` correctamente, pero en pantalla el cielo era
negro puro. En **todos** los stages del proyecto, desde siempre.

**Causa.** El renderer se construía así:

```python
pyscroll.BufferedRenderer(map_data, (W, H), clamp_camera=True)
```

Sin `alpha` ni `colorkey`. Con los dos en `None`, pyscroll crea el buffer del
mapa como `Surface(size)` **opaco** y lo limpia a negro
(`pyscroll/orthographic.py`, `_create_buffers`). Y `DrawingSystem.draw()`
dibuja primero los fondos y **después** el mapa encima, así que las celdas
vacías del mapa pintaban un rectángulo negro sobre el parallax.

**Corrección.** Pasar `alpha=True`. Se eligió sobre `colorkey` porque no
reserva ningún color: con colorkey, cualquier píxel de un tileset que
coincidiera con el color reservado se volvería transparente sin aviso.

Se acota un `warnings.catch_warnings()` a esa llamada: con `alpha=True`,
pyscroll usa `Surface.convert_alpha(parent)`, que pygame-ce 2.5 marcó como
deprecado. Es ruido de una dependencia y ensuciaba 35 líneas por corrida de
tests.

**Impacto.** stage0 y boss_venado tenían fondos de parallax dibujados que
**nunca se habían visto**. Ahora stage0 muestra su cielo nocturno con
siluetas de edificios y boss_venado su selva.

Se los menciona como evidencia de que el bug afectaba a todo el proyecto y de
que la corrección no rompe nada existente: ninguno de los dos stages fue
modificado.

---

## BUG-072 · Las capas de fondo perdían la transparencia

**Archivo:** `src/framework/stage/drawing_system.py`, en `_draw_background()`

**Síntoma.** Incluso con BUG-071 corregido, el cielo seguía negro al 100%
cuando había más de una capa de fondo.

**Causa.** El buffer de mosaico se creaba sin la bandera de alpha:

```python
tiled = pygame.Surface((tw, th))
```

`pygame.Surface` sin `SRCALPHA` nace opaco y negro. Cualquier capa con
transparencia perdía el alpha: sus zonas vacías se volvían negro sólido. Con
tres capas, `BG_Mid` y `BG_Near` tapaban por completo a `BG_Far`. El sistema
solo podía funcionar con una única capa totalmente opaca — es decir, nunca
funcionó como parallax.

**Corrección.** `pygame.Surface((tw, th), pygame.SRCALPHA)`.

**Nota.** Este bug y el 071 son independientes y ambos bastaban por separado
para romper el parallax. Por eso arreglar solo uno no mostraba ninguna mejora.

---

## BUG-073 · Caché de mosaico sin considerar el tamaño

**Archivo:** `src/framework/stage/drawing_system.py`

La clave del caché `_bg_tiles` era solo el índice de capa, así que un fondo de
distinto tamaño reusaba el mosaico anterior. Ahora la clave es
`(índice, ancho, alto)`.

---

## BUG-074 · El juego moría si faltaba un archivo de música

**Archivo:** `src/engine/audio/audio_manager.py`, en `play_music()` y
`play_dynamic_music()`

**Síntoma.** Un typo en la propiedad `bgm_track` del TMX mataba el juego al
entrar al stage, con un traceback crudo.

**Causa.** El manejo de errores era:

```python
except pygame.error as e:
```

Pero `pygame.mixer.music.load()` lanza **`FileNotFoundError`**, no
`pygame.error`, cuando el archivo no existe. El `except` no lo atrapaba. El
docstring decía *"Falls back silently"* y no lo hacía.

`StageScene` arma la ruta desde el TMX sin validarla, así que la única
protección era ese `except`.

**Corrección.** `except (pygame.error, FileNotFoundError, OSError)`.

---

## BUG-075 · `StageData.zone` no existía

**Archivos:** `src/framework/stage/stage_loader.py`,
`src/framework/scenes/stage_scene.py`

**Síntoma.** Todos los stages usaban la iluminación de la zona 0
(`ambient_brightness = 1.0`, dos luces cálidas), sin importar la zona.

**Causa.** `StageScene.on_enter()` hacía, en dos lugares distintos:

```python
zone = int(getattr(self._stage_data, "zone", 0))
```

`StageData` **nunca tuvo** un campo `zone`, así que el `getattr` siempre
devolvía el default `0`. Las ramas de las zonas 1, 2 y 3+ eran código
inalcanzable. Lo mismo con `self._dynamic_music.set_zone(zone, ...)`.

Y el atributo de clase `ZONE` que declaran las escenas —`stage0` y
`boss_venado` con 0, `boss_paburu` con 4— no se leía en ningún lado.

**Corrección.** Se agregó el campo `zone: int = 0` a `StageData`, se lee de las
propiedades del TMX, y `StageScene` cae al atributo `ZONE` de la escena si el
TMX no lo declara.

**Impacto.** Ninguno sobre stage0 y boss_venado, que declaran `ZONE = 0` y
conservan exactamente el comportamiento anterior.

---

## BUG-076 · Luces posicionadas para la resolución vieja

**Archivo:** `src/framework/scenes/stage_scene.py`

Las posiciones estaban escritas a mano para 320×224: `(80, 70)`, `(180, 50)`,
`(280, 90)`. A 800×600 quedaban amontonadas en el tercio superior izquierdo.
Ahora se escalan por `INTERNAL_WIDTH / 320` y `INTERNAL_HEIGHT / 224`.

---

## BUG-077 · `_load_boss_sprites` solo servía para el Venado

**Archivo:** `src/framework/entities/boss_base.py`

**Causa.** El helper buscaba seis claves fijas —`drift`, `hurt`, `charge`,
`stomp`, `vine`, `death`— y un único tamaño de frame para todas. Son las
animaciones del Venado. Un boss con otro conjunto, o con tamaños distintos
por fase, no podía usarlo: Paburu tiene hojas de 64×64, 56×72, 32×32 y 64×80
según la forma, y ninguna cargaba.

**Corrección.** Se agregaron dos parámetros opcionales:

```python
_load_boss_sprites(prefix, fw, fh, sheets=None, base_dir=None)
```

`sheets` es un mapa `{clave: (ancho, alto)}` y `base_dir` permite una
subcarpeta propia. Sin argumentos nuevos el comportamiento es idéntico al
anterior, así que `boss_venado` no cambia.

De paso: antes se logueaba un `WARNING` por cada hoja ausente y ensuciaba la
consola en cada arranque. Ahora se verifica que el archivo exista y la
ausencia se registra en `DEBUG`, que es lo correcto para un boss en
desarrollo con arte a medio hacer.

**Verificación.** Este mismo cambio permitió borrar el cargador propio que yo
había escrito para esquivar la limitación.

---

## BUG-078 · Los bosses heredaban rango de enemigo de patrulla

**Archivo:** `src/framework/entities/boss_base.py`

**Síntoma.** Un boss estático en el centro de una arena de 800 px **nunca
atacaba**.

**Causa.** `BossBase.__init__` no pasaba `detection_range_x/y` al `super()`,
así que heredaba el default de `EnemyBase`: 160×64, pensado para enemigos que
patrullan un tramo. Con el jugador a más de 160 px, `_check_detection_range()`
daba `False`, el boss se quedaba en `PATROL` y `_alert_behavior` no corría
nunca.

**Corrección.** `BossBase` ahora declara su propio default (640×480) y lo
expone como parámetro. El rango de un boss es su arena, no un radio de
patrulla.

---

## BUG-079 · Categoría de nota imposible de aprobar

**Archivo:** `scripts/grade_boss.py`

La categoría `boss_name_config` (10 puntos) solo detectaba una asignación
literal `self.boss_name = ...`. Pero `BossBase.boss_name` es un `@property`
de solo lectura: asignarlo lanza `AttributeError`. La única forma que
funciona es `set_boss_name(...)`, que el script no reconocía.

**Ningún alumno que usara bien el framework podía sacar esos puntos.** Ahora
el script también acepta la llamada a `set_boss_name`.

---

## BUG-080 · El autograder crasheaba con rutas relativas

**Archivo:** `scripts/grade_boss.py`

`pyf.relative_to(_PROJECT_ROOT)` lanza `ValueError` si la ruta es relativa, así
que `python scripts/grade_boss.py src/stages/x/x.py` reventaba y había que
pasar ruta absoluta. Ahora resuelve la ruta y, si queda fuera del proyecto,
muestra la original.

---

## BUG-081 · `ZeroDivisionError` sin contexto

**Archivo:** `src/engine/utils/asset_loader.py`

`load_sprite_sheet` con `frame_width` o `frame_height` en 0 reventaba con un
`ZeroDivisionError` pelado. Ahora valida y lanza un `ValueError` que dice qué
archivo y qué tamaño se pidió.

---

## BUG-101 · Once tests que no podían fallar nunca

**Archivo:** `tests/test_menu_navigation.py`

**Síntoma.** El archivo reportaba 11 tests en verde. Los warnings de pytest
decían `PytestReturnNotNoneWarning: Test functions should return None`.

**Causa.** Las once funciones `test_*` devolvían `bool`: `return False` al
fallar, `return True` al pasar. **pytest ignora el valor de retorno de un
test** — solo emite ese warning. Un test sin `assert` y sin excepción se
considera aprobado.

**Verificación de que el bug era real:** se saboteó `test_splash_to_title`
poniéndole `return False` en la primera línea. pytest siguió reportando
`1 passed`.

**Corrección.** La lógica se conserva en funciones `check_*` porque `main()`
las usa como script y devuelve el conteo de fallos. Los `test_*` que pytest
recolecta ahora son envoltorios finos que hacen `assert check_x(ctx)`.

**Impacto.** Al destaparlos, 10 de los 11 fallaban. Toda la navegación de
menús —splash, título, opciones, demos, tutorial, mapa, inventario,
bestiario, logros, salir— llevaba sin verificarse desde que el archivo se
integró a pytest.

---

## BUG-102 · El harness de tests no consumía la cola de eventos

**Archivo:** `tests/test_menu_navigation.py`, en `ContextManager.step()`

**Causa.** `press_key()` hace `pygame.event.post(...)`, pero `step()` solo
llamaba a `scene_manager.update()`. El bucle real del juego (`App.run`) llama
además a `_process_events()` cada frame, que hace `pygame.event.get()` y se
los pasa al `InputManager` con `pump()`. Sin eso, las teclas quedaban en la
cola sin procesar: ninguna navegación ocurría y todo fallaba con
*"expected XScene, got TitleScene"*.

**Corrección.** `step()` ahora llama a `_process_events()` y a
`event_bus.dispatch()` antes de actualizar la escena, igual que el bucle real.

**Impacto.** De 1/11 a 10/11 tests pasando de verdad.

---

## BUG-103 · La pantalla de controles crasheaba

**Archivo:** `src/engine/scenes/keybinding_scene.py`

**Síntoma.** `TypeError: Iterating over key states is not supported` al entrar
a reasignar una tecla. Este bug lo encontró el test de opciones una vez que
BUG-101 y BUG-102 lo dejaron correr de verdad.

**Causa.** `pygame.key.get_pressed()` devuelve un `ScancodeWrapper` que en
pygame-ce 2.5 **no es iterable**, solo indexable. El código hacía
`tuple(keys)` y `enumerate(keys)`, y ambas lanzan `TypeError`. La pantalla
crasheaba apenas se presionaba CONFIRM.

**Corrección.** Se agregó `_snapshot_keys()`, que construye la tupla
indexando: `tuple(bool(keys[k]) for k in range(len(keys)))`.

---

## Lo que destapó arreglar los tests falsos

Hacer que los once tests de menús asertaran de verdad (BUG-101) y que el
harness procesara el input (BUG-102) expuso cuatro cosas que llevaban ocultas:

- **BUG-103** — la pantalla de controles crasheaba.
- **BUG-104** — la entrada "Achievements" del menú no abría nada.
- **BUG-110** — salir de la bestiary desde el título dejaba el juego en negro.
- **BUG-111** — y una que **no** era bug del juego: el test medía más corto que
  los fundidos de las escenas. Vale la pena anotarlo porque es el caso opuesto,
  y distinguirlo importa tanto como encontrar los otros tres.

---

## BUG-104 · La entrada "Achievements" del menú no hacía nada

**Archivo:** `src/engine/scenes/scene_registry.py`

Hay **dos** clases `AchievementScene`, en `achievement_scene.py` y en
`achievement_screen.py`. La segunda es **abstracta**: nunca implementa
`on_exit`, que `BaseScene` declara abstracto, así que instanciarla lanza
`TypeError`. El registro apuntaba justo a esa.

Y `SceneRegistry.build()` atrapa `TypeError` y devuelve `None`, así que el
menú de progreso ofrecía "Achievements" y al elegirlo no pasaba nada, sin
error visible. Se apuntó el registro a la clase que sí funciona.

`achievement_screen.py` queda como código muerto: nadie más lo importa.

---

## BUG-106 · El save guardaba una vida máxima incorrecta

**Archivo:** `src/framework/entities/player.py`

`SceneManager` guarda con `getattr(player, 'max_health', 5.0)`, pero `Player`
**no tenía** esa propiedad, así que siempre caía al default 5.0. Con objetos
del inventario que suman vida —el bono real medido es de 2.0— el save quedaba
con 5.0 en vez de 7.0. Corrupción silenciosa al completar un stage.

Se agregó la propiedad, que suma `PLAYER_MAX_HEALTH` y el bono del inventario.

---

## BUG-110 · Salir de la bestiary desde el título dejaba el juego en negro

**Archivo:** `src/engine/scenes/bestiary_scene.py`

`CANCEL` hacía `scene_manager.pop()` a secas. Está bien cuando la bestiary se
abre **desde un stage** con TAB, porque debajo queda el stage. Pero desde el
menú del título es la única escena de la pila: el `pop()` la dejaba vacía y el
juego quedaba en negro, sin nada que procesara el input. Soft-lock sin
traceback. Ahora, si no hay nada debajo, vuelve al título.

---

## BUG-105, 107, 108, 109 · Confirmados de la auditoría del profesor

Estos cuatro salieron de su auditoría y se verificaron con evidencia de
ejecución en esta copia antes de tocarlos:

- **105** — `HazardZone.timer` arrancaba en 0.0, así que al primer frame de
  contacto quedaba negativo y la zona hacía daño ignorando su propio cooldown.
- **107** — el caché de `BitmapFont` no tenía techo. Medido: 500 textos únicos
  dejaban 500 Surfaces retenidas. Ahora hay tope de 256 con desalojo FIFO.
- **108** — el caché de sprites espejados usaba `id(frames)` como clave, sin
  techo y con riesgo de que CPython reciclara el `id` de una lista liberada y
  devolviera los frames de otro sprite. Tope de 128 y clave reforzada.
- **109** — `BossPhase.speed_multiplier` se leía en un `if` cuyo cuerpo era
  `pass`. Ahora se expone en `phase_speed_multiplier` para que las subclases
  lo apliquen; `BossBase` no puede hacerlo solo porque no impone el movimiento.

---

## Validación de la auditoría externa

Se recibió una auditoría hecha con IA sobre **otra copia del proyecto** —la
del profesor, con 12 fases de librerías integradas (ModernGL, pymunk, lupa,
numba, orjson, pydantic, pygame-gui) que esta copia no tiene. Se verificó
hallazgo por hallazgo cuáles aplican acá, con pruebas de ejecución.

**No aplican** (código que esta copia no tiene): todo lo de GL, pymunk, Lua y
audio pipeline.

**No se reproducen** (reportados como bugs, pero acá el código es correcto):

| Hallazgo externo | Estado real en esta copia |
|---|---|
| H1 `_display_surf` nunca inicializado | **Falso** — se inicializa en `app.py` línea 46 |
| H3 rects del TMX sin validar | **Falso** — `obj.width or 32` en las líneas 235+ |
| M10 `_collision_rects` puede faltar | **Falso** — viene inicializado; verificado construyendo un `EnemyWalker` |

**Confirmados y corregidos:** M7 → BUG-105, H2 → BUG-106, M5 → BUG-107,
M4 → BUG-108, L7 → BUG-109.

**Confirmado con matiz:** M2 dice que `hitbox` se computa por frame y *nunca*
se consume. Es casi cierto: sí se lee, pero **solo** en el dibujo de debug
(`drawing_system.py:202`). El daño por contacto usa `hurtbox`, no `hitbox`, así
que los ocho enemigos con `hitbox == hurtbox` no tienen ningún efecto sobre la
jugabilidad. Se decidió no modificarlos; el razonamiento completo, con el
rastreo de todos los lectores de `enemy.hitbox`, está en la sección **M2** más
abajo.

**Riesgo teórico, no reproducible:** L1, el `float("inf")` de invencibilidad en
las transiciones de fase. Se midió: durante la transición vale `inf`, y al
terminar vuelve a `0.0` correctamente. La preocupación es válida como estilo
—usar un timer para expresar un estado booleano— pero no hay camino que lo
deje colgado.

---

## BUG-112 · Guardar la dificultad rompía el spawn de todos los enemigos

**Archivo:** `src/engine/core/difficulty.py`

`set_difficulty()` asignaba a la variable global lo que le pasaran, sin
validar. La dificultad se persiste en `config.json` como texto (`"hard"`), así
que restaurarla —lo natural— dejaba `_current_difficulty` con un string en vez
del enum `Difficulty`. Ese string no es clave de `DIFFICULTY_PRESETS`.

El síntoma no aparecía ahí. Aparecía mucho después, con un `KeyError` dentro de
`get_config()`, que se llama desde `EnemyBase.__init__`: **dejaba de poder
crearse cualquier enemigo del juego**. Un error de tipeo en un archivo de
configuración dejaba el juego sin enemigos y con un traceback que apuntaba al
lugar equivocado.

**Corrección:** `set_difficulty()` acepta el enum o su texto, y ante un valor
desconocido registra una advertencia y **mantiene el valor anterior** en lugar
de envenenar el estado global. `get_config()` usa `.get()` con NORMAL como
respaldo, de modo que ni siquiera un estado corrupto puede tumbar un spawn.

---

## BUG-113 · La dificultad guardada nunca se aplicaba al arrancar

**Archivo:** `src/engine/core/app.py`

`config.json` guardaba la dificultad, pero **nadie la leía al iniciar**. La
única ruta que llamaba a `set_difficulty()` era el `on_exit()` de la pantalla de
Opciones. Consecuencia: quien elegía Hard, cerraba el juego y volvía a entrar,
jugaba en Normal —hasta que entrara y saliera del menú de Opciones. Lo mismo
con el modo daltónico y los subtítulos.

Es el tipo de bug que no se nota porque el jugador supone que el ajuste quedó
puesto.

**Corrección:** se agregó `App._apply_saved_options()`, llamado en el
constructor antes de que exista cualquier entidad. Lee dificultad, modo
daltónico, subtítulos y volúmenes. Si el archivo falta o está corrupto no pasa
nada: quedan los valores por defecto. Verificado: con `"difficulty": "hard"` en
el archivo, el juego arranca con `enemy_health_mult = 1.5`.

---

## BUG-114 · El Boss Rush no podía terminarse

**Archivo:** `src/framework/stage/boss_rush_mode.py`

Dos defectos que se tapaban entre sí.

`advance_to_next()` solo entraba a su bloque de cierre cuando **quedaban jefes
por delante** (`if self._current_index < len(self._stages) - 1`). Al derrotar al
último se salía por el `return None` sin marcarlo `defeated` y sin sumarle su
puntaje: el jugador completaba el gauntlet entero y el marcador ignoraba la
pelea final.

`is_complete()` pedía `self._active and self._current_index >= len(...)`. Pero
`advance_to_next()` pone `_active = False` justo al terminar. Las dos
condiciones no podían ser verdaderas a la vez, así que **el método devolvía
`False` siempre**: no existía forma de detectar que el modo había terminado.

Medido antes de corregir, con tres jefes:

```
derrotados: [('Boss 0', True), ('Boss 1', True), ('Boss 2', False)]
puntaje: 1900        is_complete(): False
```

Después:

```
derrotados: [('Boss 0', True), ('Boss 1', True), ('Boss 2', True)]
puntaje: 2850        is_complete(): True
```

**Corrección:** el cierre del jefe actual ocurre siempre y el avance de índice
se evalúa después; `is_complete()` deja de depender de `_active` y exige que la
lista no esté vacía, para que un Boss Rush sin jefes no cuente como completado.
`progress` se acota para no mostrar "4/3" al terminar.

---

## BUG-115 · `on_enter()` no era idempotente y la limpieza estaba duplicada

**Archivo:** `src/framework/scenes/stage_scene.py`

`_sfx_handlers` y `_vfx_handlers` son diccionarios indexados por evento, y
guardan closures creadas dentro de `on_enter()`. Si `on_enter()` corría dos
veces seguidas sin limpiar en medio, el segundo juego de closures **pisaba al
primero en el diccionario**: las 58 suscripciones viejas quedaban conectadas al
bus sin ninguna referencia que permitiera soltarlas. `on_exit()` ya no podía
alcanzarlas.

La limpieza estaba escrita **dos veces** —en `on_exit()` y en `respawn()`— y las
copias ya habían divergido: `respawn()` no llamaba a
`_achievements.unsubscribe_events()`. Esa duplicación existía precisamente para
esquivar el problema anterior: `respawn()` llama a `on_enter()` de nuevo, así
que tenía que desconectar todo a mano primero.

**Corrección:** un solo método `_unsubscribe_scene_handlers()` que usan los tres
caminos, y `on_enter()` lo llama de entrada. Ahora es idempotente. Verificado
sobre tres ciclos de cada flujo:

```
push/pop        : [2, 2, 2]      sin fuga
respawn()       : [62, 62, 62]   sin fuga
on_enter() x3   : [62, 62, 62]   sin fuga  (antes: 62 -> 120 -> 178)
```

---

## Lo que se revisó y estaba bien

Para que quede constancia de dónde **no** hay problemas:

- **Física del jugador.** Sin tunneling: probado con `dt` de 1/60 hasta 0.5 s,
  el jugador nunca atraviesa el suelo. `dt = 0` y `dt` negativo no rompen.
- **Vida.** No baja de 0 con daño masivo.
- **`EventBus`.** Sin fugas de suscriptores en ningún flujo real: se midió el
  conteo de suscriptores sobre tres ciclos completos de `push` → 30 frames →
  `pop`, tres `respawn()` seguidos, y el arranque limpio. Todos vuelven
  exactamente al valor base. El guard de reentrada de `dispatch()` funciona.
  (La única forma de fugar era llamar `on_enter()` dos veces a mano — BUG-115,
  ya corregido.)
- **Transiciones.** `is_done` devuelve `self.is_complete` sin paréntesis, lo que
  parece el clásico bug de retornar el método en vez de llamarlo. No lo es:
  ambos están decorados con `@property`, así que el acceso ya evalúa. Se
  verificó antes de tocar nada.
- **`CurveTools`.** Listas vacías, un solo punto, `n_samples=0` y grado mayor
  que la cantidad de puntos: todos devuelven algo válido sin excepción.
- **`math_utils`.** `vec2_normalize` del vector cero devuelve cero.
- **`AssetLoader`.** Imágenes, spritesheets y fuentes faltantes generan
  placeholder sin crashear.
- **`FilterTools`.** Los `ValueError` de `gaussian_blur(sigma=0)` y
  `adjust_brightness(-1)` son validación intencional con mensaje claro, no
  bugs.
- **Cámara.** Sin `follow` y con `map_size` en cero no rompe.

---

## BUG-116 · `achievement_screen.py` — escena rota e inalcanzable (eliminado)

**Archivo:** `src/engine/scenes/achievement_screen.py` (borrado)

Al corregir BUG-104 se descubrió que el registro de escenas apuntaba a este
archivo en vez de a `achievement_scene.py`. Revisado ahora en detalle:
`AchievementScene` hereda de `BaseScene` pero **no implementa `on_exit`**, que
es abstracto. La clase no se puede instanciar:

```
TypeError: Can't instantiate abstract class AchievementScene
           with abstract method on_exit
```

Es decir: 74 líneas que nunca pudieron ejecutarse. Tras el fix de BUG-104
ninguna referencia en código apuntaba ya al módulo. Se eliminó el archivo en
lugar de repararlo, porque dejarlo significaba mantener dos escenas de logros
—una funcional y una imposible de construir— y arriesgar que en EP2 alguien
importara la equivocada. La suite sigue en 601 passed tras borrarlo.

---

## M2 · Por qué NO se tocaron los 8 enemigos con `hitbox == hurtbox`

La auditoría del profesor señala que ocho enemigos (`archer`, `assassin`,
`brute`, `caster`, `charger`, `flying`, `shooter`, `walker`) definen:

```python
def _build_hitbox(self) -> pygame.Rect:
    return self._build_hurtbox()
```

y lo marca como colisión mal modelada. El hallazgo es correcto en lo semántico
—`_build_hurtbox` es "dónde me pueden pegar" y `_build_hitbox` es "dónde pego
yo", y colapsarlos borra la distinción— pero antes de cambiar diez clases se
rastreó **quién consume realmente `enemy.hitbox`**:

```
src/framework/stage/drawing_system.py:202     hb2 = enemy.hitbox   <- overlay de debug
src/framework/entities/enemy_base.py:98       inicialización
src/framework/entities/enemy_base.py:553      asignación en _update_rects
```

Un solo lector, y es el dibujado de depuración. El daño por contacto se
resuelve en `_check_player_contact`, que compara **`self.hurtbox` contra el
hurtbox del jugador** (línea 513), tal como dice su propio docstring. O sea que
`hitbox` no participa de ninguna decisión de jugabilidad.

**Consecuencia real del defecto:** en el overlay de debug el rectángulo rojo se
dibuja exactamente encima del naranja, así que nunca se puede ver por separado
la zona de daño de un enemigo. Nada más.

**Decisión:** no se modifica. Darles a los ocho una hitbox distinta produciría
código que ningún sistema lee —decorativo—, y cambiar `_check_player_contact`
para que use `hitbox` alteraría el combate de todo el juego y contradice el
diseño explícito del motor. El defecto de fondo es otro, y queda anotado como
observación de diseño:

> `_build_hitbox` es un método `@abstractmethod` que obliga a las diez
> subclases de `EnemyBase` a implementar algo que el motor solo usa para
> depuración. O se le da un consumidor real, o debería dejar de ser abstracto.

---

## BUG-117 · El primer golpe dejaba el juego en cámara lenta permanente

**Archivo:** `src/framework/scenes/stage_scene.py`

El más grave de todo el reporte. Reproducible en **cualquier stage y con
cualquier enemigo**: bastaba conectar un ataque para que el juego entero
quedara al 15 % de velocidad hasta morir o salir del stage.

`CollisionSystem` implementa *hitstop*: al conectar un golpe pone
`clock.time_scale = 0.15` durante unos frames, para dar sensación de impacto.
`StageScene.update` lo envolvía así:

```python
original_time_scale = self.context.clock.time_scale     # ANTES del bloque
try:
    ...                                                  # acá el golpe pone 0.15
finally:
    self._collision.update_hitstop(dt, clock)            # al terminar, repone 1.0
    if self._collision._hitstop_timer <= 0:
        self.context.clock.time_scale = original_time_scale   # y lo vuelve a pisar
```

Parece correcto, pero el golpe cambia `time_scale` **dentro** del `try`. En
los frames siguientes lo que se capturaba como "original" ya era `0.15`. Así
que cuando el temporizador llegaba a cero y `update_hitstop` devolvía la
escala a `1.0`, la última línea la sobrescribía otra vez con `0.15` — y de ahí
no salía nunca.

Medido: `time_scale` clavado en `0.15` durante 400 frames después de un solo
impacto. Solo se recuperaba porque `respawn()` y `on_exit()` reponen la escala
a mano — de ahí que muriendo se "arreglara".

**Corrección:** fuera del hitstop la escala correcta es `1.0` y no hay ningún
otro sistema que la altere, así que se repone ese valor directamente y se
elimina la captura de `original_time_scale`.

---

## BUG-118 · El hitstop duraba siete veces más de lo pedido

**Archivos:** `src/engine/core/clock.py`, `src/framework/stage/collision_system.py`

Al arreglar BUG-117 quedó a la vista el segundo defecto. `update_hitstop`
descontaba su temporizador con el `dt` de la escena:

```python
self._hitstop_timer -= dt
```

Pero ese `dt` ya viene multiplicado por `time_scale`, y el propio hitstop es
quien pone esa escala en `0.15`. El temporizador se descontaba 6.7 veces más
lento de lo que debía: un hitstop pedido de **4 frames duraba unos 27**, casi
medio segundo. En vez del golpe seco que busca la técnica, se sentía como un
tirón del juego.

Es un error de razonamiento clásico al escalar el tiempo: un temporizador que
mide *cuánto debe durar una alteración del tiempo* no puede medirse con el
tiempo ya alterado.

**Corrección:** `DeltaClock` expone `raw_dt`, el delta sin escalar, y
`update_hitstop` lo usa. Verificado: el hitstop vuelve a durar lo que pide
`hitstop_frames`, y `time_scale` regresa a `1.0` en golpes sucesivos.

---

## Nota sobre los 13 ERROR de `tests/benchmarks/`

Al correr la suite completa aparecían 13 errores con el mensaje
`fixture 'benchmark' not found`. **No eran bugs del motor ni del boss.** El
paquete `pytest-benchmark` estaba declarado en `pyproject.toml` (línea 27) pero
faltaba en `requirements.txt`, que es el archivo que se instala — de hecho
`requirements.txt` no incluía **ninguna** dependencia de testing, así que nadie
que siguiera las instrucciones de instalación podía correr la suite completa.

**Corrección:** se agregaron a `requirements.txt`:

```
pytest~=8.3
pytest-benchmark~=5.2
pytest-subtests~=0.13
```

Verificado: `tests/benchmarks/test_startup_benchmark.py` pasa 2/2 tras
instalarlas.

---

## Cómo verificar

```bash
# suite completa — 601 passed, misma línea base que antes de tocar nada
python -m pytest tests/ -q --ignore=tests/benchmarks

# encontrar cada corrección en el código
grep -rn "BUG-0[78]\|BUG-1[01][0-9]" src/ scripts/ tests/
# (BUG-116 es el único sin marcador: consistió en borrar un archivo)

# el autograder ya corre con ruta relativa
python scripts/grade_boss.py src/stages/boss_paburu/boss_paburu.py
```
