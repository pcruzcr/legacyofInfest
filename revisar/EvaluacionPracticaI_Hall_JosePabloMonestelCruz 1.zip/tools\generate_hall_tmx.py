#!/usr/bin/env python3
"""Generate the Stage 3-2 "El Hall" TMX map (Zona 3 - Sede Heredia).

Follows the same generation pattern as generate_stage0_tmx.py: build the
tile grids and object list as Python data, then serialize to Tiled's XML/CSV
format. Uses the real tileset_gavilan_ciudad tileset (60 named tiles).

Layout (bottom to top):
  - main floor (spawn, WalkerPalom, checkpoint, the two staircases, a
    crate obstacle, and a small pit crossing under the balcony's own gap)
  - balcony with a 3-tile central gap, reached by the two staircases
    (ShooterBuitre stationed here)
  - open flight band where the 6 FlyingHalcon patrol Bezier loops, and two
    parkour paths — one climbing straight out of the balcony (west), one
    launching off the floor-level pedestal near the checkpoint (east) —
    that converge on a single shared landing near the hall's horizontal
    middle, where the door + NextTrigger sit, reachable from either side
  - a tall arched skylight band right at ceiling height (3 of them), drawn
    on FG_Overlay so they show through/over the solid ceiling tile

SIZE NOTE: the internal camera resolution is 800x600
(src/engine/core/settings.py INTERNAL_WIDTH/HEIGHT). Camera.update() clamps
its scroll offset to `max(0, map_size - screen_size)` — a map smaller than
the screen in either axis gets that clamp forced to exactly 0 every frame,
so the level renders pinned in a corner of a much larger black canvas with
entities positioned by raw world coordinates instead of by what's on
screen. This map (68x38 tiles = 1088x608px) exceeds 800x600 in both axes,
same convention as stage0.tmx (1600x608), so the camera always has room to
scroll.

JUMP ENVELOPE (verified against the real player controller, not just
settings.py — see src/framework/entities/states/airborne.py):
  - GRAVITY=800, PLAYER_JUMP_FORCE=-380 -> max rise ~90px. This part
    matches src/framework/stage/level_metrics.py's JumpEnvelope.
  - Horizontal air speed is HALF ground speed (airborne.py: `move_x *
    player.walk_speed * 0.5` = 90*0.5 = 45px/s), applied instantly (no
    ramp-up), for ~0.95s of air time -> a real single-jump horizontal
    reach of ~43px, not the ~85px a naive `PLAYER_WALK_SPEED * air_time`
    calculation gives (that naive number is what level_metrics.py's own
    estimator uses, and it's the wrong one for actual play — the first
    draft of this file's gauntlet used it and produced unreachable gaps).
  - Every single-jump horizontal gap in this file is kept to <=32px
    (margin under the real ~43px max). Every platform a player is meant to
    stand on (especially next to a DeathPit) is >=2 tiles (32px) wide —
    the player's own collision rect is 20px wide, so a 16px (1-tile)
    platform left part of that rect hanging over an adjacent hazard even
    while "standing on it successfully", which is what caused false
    deaths on the pit crossing in an earlier draft.
  - CEILING CLEARANCE. A jump's vertical ascent is a fixed ballistic arc
    (initial velocity -380, decelerated by gravity 800) — the game doesn't
    know "the target is only 32px up, jump less". If a solid ceiling tile
    sits within that arc's ~90px reach above a takeoff platform, the
    player's head clips it, velocity.y gets zeroed/reversed early, and
    they lose both the rest of their ascent AND the horizontal air-time
    they needed to cover the gap — a "successful-looking" jump that falls
    short right after bonking the ceiling. CEILING_ROW=5 (solid tile
    bottom edge at y=96px), so every platform a player is meant to jump
    FROM here is kept at row>=13 (y>=208px, i.e. >=112px of clear air
    above it — comfortably over the ~90px max arc) whenever the path runs
    near the ceiling. An earlier draft put the final approach at row 7-9
    (only 16-48px of headroom) and that's what caused this exact bug.
"""
import random
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
TMX_PATH = PROJECT_ROOT / "assets" / "maps" / "hall" / "hall.tmx"
# Embedded (not external-source) tileset declaration, matching stage0.tmx's
# convention: scripts/grade_stage.py's tileset_valid check only recognizes a
# <tileset> with a nested <image>, not an external <tileset source="...tsx"/>.
TILESET_IMAGE_REL_PATH = "../../tilesets/tileset_gavilan_ciudad.png"
TILESET_TILECOUNT = 60
TILESET_COLUMNS = 8
TILESET_IMG_W, TILESET_IMG_H = 128, 128

MW, MH = 68, 38  # map dimensions in tiles (1088x608 px)
TS = 16  # tile size

# ── row plan ──
CEIL_ARCH_ROW = 2       # skylight arch top (FG_Overlay, drawn over the ceiling)
CEIL_GLASS_ROWS = range(3, 9)
CEIL_SILL_ROW = 9
CEILING_ROW = 5          # solid ceiling (Terrain + Collision), sits inside the glass span
BALCONY_ROW = 24
FLOOR_ROW = 33
FLOOR_FILL_ROWS = range(FLOOR_ROW + 1, MH)

# ── tileset_gavilan_ciudad tile ids, in .tsx order (id 0..59 -> gid 1..60) ──
TILE_NAMES = [
    "suelo_sup", "suelo_rel", "muro", "muro_sup", "panel", "zocalo", "techo", "columna",
    "plat_izq", "plat_med", "plat_der", "plat_sola", "reja", "tuberia_h", "tuberia_v", "luz_suelo",
    "lej_cuerpo", "lej_cuerpo2", "lej_luz", "lej_luz2", "lej_sup", "lej_sup_caseton", "lej_sup_antena", "lej_deposito",
    "med_cuerpo", "med_cuerpo2", "med_luz", "med_luz2", "med_sup", "med_sup_caseton", "med_sup_antena", "med_deposito",
    "cer_cuerpo", "cer_cuerpo2", "cer_luz", "cer_luz2", "cer_sup", "cer_sup_caseton", "cer_sup_antena", "cer_deposito",
    "parteluz_v", "travesano_h", "cruce", "marco_izq", "marco_der", "marco_sup", "alfeizar", "brillo",
    "grieta_1", "grieta_2", "mancha", "brillo_suave", "bruma_lej", "bruma_med", "cortina_izq", "cortina_der",
    "lampara", "cuadro", "caja", "muro_fondo",
]
G = {name: i + 1 for i, name in enumerate(TILE_NAMES)}


def _blank_grid():
    return [[0] * MW for _ in range(MH)]


# ── BG_Far / BG_Mid / BG_Near: irregular Heredia skyline at night, glimpsed
# through the hall's own windows — not a repeating texture. Roofline height
# varies per column via a seeded RNG (deterministic across regenerations),
# reusing the existing roofline/body/window tile variants for each depth.
# This is what the hall's skylights and open ceiling void look out onto;
# kept behind the architecture (BG layers, parallax factor << 1) so it
# reads as a distant backdrop, not competing with the hall itself. ──
_rng = random.Random(20260730)


def _skyline_layer(grid, sup, sup_caseton, sup_antena, deposito, cuerpo, cuerpo2, luz, luz2,
                    min_h, max_h, variant_chance, luz_chance, deposito_chance, top_row=24):
    for x in range(MW):
        h = _rng.randint(min_h, max_h)
        roof_row = max(0, top_row - h)
        variant = deposito if _rng.random() < deposito_chance else (
            sup_caseton if _rng.random() < variant_chance else (
                sup_antena if _rng.random() < variant_chance else sup))
        grid[roof_row][x] = G[variant]
        for y in range(roof_row + 1, top_row):
            grid[y][x] = G[cuerpo2] if _rng.random() < 0.35 else G[cuerpo]
            if _rng.random() < luz_chance:
                grid[y][x] = G[luz] if _rng.random() < 0.5 else G[luz2]


bg_far = _blank_grid()
_skyline_layer(bg_far, "lej_sup", "lej_sup_caseton", "lej_sup_antena", "lej_deposito",
               "lej_cuerpo", "lej_cuerpo2", "lej_luz", "lej_luz2",
               min_h=3, max_h=10, variant_chance=0.22, luz_chance=0.05, deposito_chance=0.08)

bg_mid = _blank_grid()
_skyline_layer(bg_mid, "med_sup", "med_sup_caseton", "med_sup_antena", "med_deposito",
               "med_cuerpo", "med_cuerpo2", "med_luz", "med_luz2",
               min_h=2, max_h=8, variant_chance=0.2, luz_chance=0.08, deposito_chance=0.06)

bg_near = _blank_grid()
_skyline_layer(bg_near, "cer_sup", "cer_sup_caseton", "cer_sup_antena", "cer_deposito",
               "cer_cuerpo", "cer_cuerpo2", "cer_luz", "cer_luz2",
               min_h=2, max_h=6, variant_chance=0.18, luz_chance=0.1, deposito_chance=0.05)

# Moon — a soft cluster of glow tiles on the farthest layer, placed once
# high in the sky near the start of the hall, clear of the three real
# skylights (cols 15-18/35-38/52-55) and the shared door landing (~col 45).
MOON_COL, MOON_ROW = 6, 1
_moon_cells = ((1, 0), (2, 0), (0, 1), (1, 1), (2, 1), (3, 1), (1, 2), (2, 2))
for dx, dy in _moon_cells:
    bg_far[MOON_ROW + dy][MOON_COL + dx] = G["brillo_suave"]
bg_far[MOON_ROW][MOON_COL + 1] = G["brillo"]
bg_far[MOON_ROW + 1][MOON_COL + 2] = G["brillo"]

# ── Terrain: structural / walkable geometry ──
terrain = _blank_grid()
for x in range(MW):
    terrain[CEILING_ROW][x] = G["techo"]
for y in range(MH):
    terrain[y][0] = G["muro"]
    terrain[y][MW - 1] = G["muro"]
# Floor pit (col 25, under the balcony's own gap) — left open in the CSV
# fill below, see PIT_COLS. Only 1 tile = 16px: the real single-jump reach
# is ~43px, but landing right at the far edge still leaves the player's
# 20px-wide rect straddling the boundary — a 32px pit (used previously)
# only left ~11px of margin for that, which is why the "successful"-
# looking crossing was still registering as a death intermittently. 16px
# leaves a full ~27px of margin, so the rect is fully clear of the pit
# even on a mediocre jump, not just a maximum-distance one.
PIT_COLS = range(25, 26)
for x in range(1, MW - 1):
    if x in PIT_COLS:
        continue
    terrain[FLOOR_ROW][x] = G["suelo_sup"]
    for fy in FLOOR_FILL_ROWS:
        terrain[fy][x] = G["zocalo"]

# Balcony: west segment, 3-tile central gap, east segment.
terrain[BALCONY_ROW][10] = G["plat_izq"]
for x in range(11, 24):
    terrain[BALCONY_ROW][x] = G["plat_med"]
terrain[BALCONY_ROW][24] = G["plat_der"]
terrain[BALCONY_ROW][28] = G["plat_izq"]
for x in range(29, 42):
    terrain[BALCONY_ROW][x] = G["plat_med"]
terrain[BALCONY_ROW][42] = G["plat_der"]

# Staircase A (left, floor -> balcony west end)
terrain[29][4], terrain[29][5] = G["plat_izq"], G["plat_der"]
terrain[27][7], terrain[27][8] = G["plat_izq"], G["plat_der"]

# Crate obstacle on the floor, directly below and between the staircase's
# first two aerial platforms (step1 at cols 4-5, step2 at cols 7-8) —
# without this the floor is a flat, unbroken line from spawn to the exit
# climb and the whole balcony/staircase structure above is entirely
# optional; a player could just walk straight underneath it and never
# engage with any of it. Solid (not one-way), 2 tiles tall (32px, a
# trivial single jump — a beat, not a wall) so it can't be walked through,
# only jumped.
CRATE_OBSTACLE_COLS = (6,)
for cx in CRATE_OBSTACLE_COLS:
    terrain[FLOOR_ROW - 2][cx] = G["caja"]
    terrain[FLOOR_ROW - 1][cx] = G["caja"]
# Staircase B (right, balcony east end -> floor)
terrain[27][44], terrain[27][45] = G["plat_izq"], G["plat_der"]
terrain[29][47], terrain[29][48] = G["plat_izq"], G["plat_der"]

# Two parkour paths — one from each side of the hall — converging on a
# single shared landing near the map's horizontal middle, where the door
# sits. Reachable from either direction, per the request that the door be
# a midpoint both sides actually lead to, not a dead end past one long
# gauntlet. No hazard underneath any of it — a missed jump just drops the
# player back onto a lower platform, the balcony, or the floor. Every step
# is verified against the REAL jump envelope (real single-jump horizontal
# reach ~43px, so every dx here is <=32px; every rise is <=64px, well
# under the ~90px max) and stays at row>=13 (>=112px clear of the solid
# ceiling at row 5 — see the CEILING CLEARANCE note up top).

# West path: climbs straight out of the balcony, then levels off and
# traverses right to the shared landing.
WEST_STEPS = [
    (20, 12, 13),  # rise 64 from the balcony
    (17, 16, 17),  # rise 48 / dx 32
    (14, 20, 21),  # rise 48 / dx 32
    (14, 24, 25),  # dx 32 — settle onto the row-13/14 safe band and traverse
    (14, 28, 29),  # dx 32
    (14, 32, 33),  # dx 32
    (14, 36, 37),  # dx 32
    (14, 40, 41),  # dx 32
]
for row, c0, c1 in WEST_STEPS:
    terrain[row][c0] = G["plat_izq"]
    terrain[row][c1] = G["plat_der"]

# Floor pit crossing (col 24 box -> direct jump over the pit -> col 26
# floor), right under the balcony's own central gap — the second "you have
# to actually jump" beat the player asked for, same idea as the first
# crate: the box gives a running start; the pit itself is a single 16px
# hop, well inside the real single-jump horizontal reach with margin.
terrain[FLOOR_ROW - 2][24] = G["caja"]
terrain[FLOOR_ROW - 1][24] = G["caja"]

# East path: launches off the floor-level pedestal (a required waypoint,
# not a disconnected bonus — reachable directly from the checkpoint) and
# climbs up and left to the same shared landing.
PEDESTAL_COL = 58
terrain[FLOOR_ROW - 2][PEDESTAL_COL] = G["caja"]
terrain[FLOOR_ROW - 1][PEDESTAL_COL] = G["caja"]

EAST_STEPS = [
    (29, 60, 61),  # rise 32 / dx 16 from the pedestal
    (25, 56, 57),  # rise 64 / dx 32 (heading left)
    (21, 52, 53),  # rise 64 / dx 32
    (17, 48, 49),  # rise 64 / dx 32
]
for row, c0, c1 in EAST_STEPS:
    terrain[row][c0] = G["plat_izq"]
    terrain[row][c1] = G["plat_der"]

# Shared landing — the door — reachable from the west path (traversing
# right) and the east path (climbing up-left from the pedestal).
LANDING_ROW = 14
terrain[LANDING_ROW][44] = G["plat_izq"]
for x in range(45, 47):
    terrain[LANDING_ROW][x] = G["plat_med"]
terrain[LANDING_ROW][47] = G["plat_der"]

# ── Terrain_Detail: non-colliding decoration ──
terrain_detail = _blank_grid()
for col in (15, 35, 52):
    for y in range(CEIL_SILL_ROW + 1, FLOOR_ROW):
        terrain_detail[y][col] = G["columna"]
for x in range(10, 24):
    terrain_detail[BALCONY_ROW - 1][x] = G["reja"]
for x in range(28, 42):
    terrain_detail[BALCONY_ROW - 1][x] = G["reja"]
terrain_detail[BALCONY_ROW][24] = G["grieta_1"]
terrain_detail[BALCONY_ROW][28] = G["grieta_2"]
for x, y, name in ((6, FLOOR_ROW - 1, "grieta_1"), (22, FLOOR_ROW - 1, "mancha"),
                    (50, FLOOR_ROW - 1, "grieta_2"), (18, FLOOR_ROW, "mancha")):
    terrain_detail[y][x] = G[name]
terrain_detail[16][1] = G["cuadro"]
terrain_detail[16][MW - 2] = G["cuadro"]
terrain_detail[FLOOR_ROW - 2][2] = G["caja"]
terrain_detail[FLOOR_ROW - 2][54] = G["caja"]

# ── FG_Overlay: tall arched skylights (drawn over the ceiling tile since
# FG_Overlay is the last tile layer), light shafts, mist/glow accents. ──
fg_overlay = _blank_grid()


def _skylight(wx: int) -> None:
    fg_overlay[CEIL_ARCH_ROW][wx] = G["marco_sup"]
    fg_overlay[CEIL_ARCH_ROW][wx + 1] = G["marco_sup"]
    for gy in CEIL_GLASS_ROWS:
        fg_overlay[gy][wx - 1] = G["cortina_izq"]
        fg_overlay[gy][wx] = G["marco_izq"]
        fg_overlay[gy][wx + 1] = G["marco_der"]
        fg_overlay[gy][wx + 2] = G["cortina_der"]
    fg_overlay[CEIL_SILL_ROW][wx] = G["alfeizar"]
    fg_overlay[CEIL_SILL_ROW][wx + 1] = G["alfeizar"]
    # Light shaft reaching down toward the floor below the skylight.
    for ly in (FLOOR_ROW - 3, FLOOR_ROW - 2):
        fg_overlay[ly][wx] = G["luz_suelo"]
        fg_overlay[ly][wx + 1] = G["luz_suelo"]


for wx in (16, 36, 53):
    _skylight(wx)
for x, y, name in ((25, 12, "bruma_lej"), (45, 15, "bruma_med"), (12, 18, "brillo_suave"), (62, 20, "brillo")):
    fg_overlay[y][x] = G[name]

# Sealed door — the visible "goal" marker above the landing platform, built
# from the same frame/panel tiles as the rest of the hall (no new tile
# needed): an arched top, two panel tiles for the slab, a crossed mullion
# read as a locking bar, and a sill resting on the landing.
DOOR_COL = 45
fg_overlay[LANDING_ROW - 4][DOOR_COL] = G["marco_sup"]
fg_overlay[LANDING_ROW - 4][DOOR_COL + 1] = G["marco_sup"]
fg_overlay[LANDING_ROW - 3][DOOR_COL] = G["panel"]
fg_overlay[LANDING_ROW - 3][DOOR_COL + 1] = G["panel"]
fg_overlay[LANDING_ROW - 2][DOOR_COL] = G["cruce"]
fg_overlay[LANDING_ROW - 2][DOOR_COL + 1] = G["cruce"]
fg_overlay[LANDING_ROW - 1][DOOR_COL] = G["alfeizar"]
fg_overlay[LANDING_ROW - 1][DOOR_COL + 1] = G["alfeizar"]


def _grid_to_csv(grid):
    return ",".join(str(grid[y][x]) for y in range(MH) for x in range(MW))


# ── Collision (Solid / Platform rects) ──
def _iter_collision():
    oid = 200
    rects = [
        ("Solid", 0, CEILING_ROW * TS, MW * TS, TS),
        ("Solid", 0, 0, TS, MH * TS),
        ("Solid", (MW - 1) * TS, 0, TS, MH * TS),
        # Floor, split around the pit (cols 25-27) instead of one continuous rect.
        ("Solid", TS, FLOOR_ROW * TS, (PIT_COLS.start - 1) * TS, (MH - FLOOR_ROW) * TS),
        ("Solid", PIT_COLS.stop * TS, FLOOR_ROW * TS, (MW - 1 - PIT_COLS.stop) * TS, (MH - FLOOR_ROW) * TS),
        ("Solid", CRATE_OBSTACLE_COLS[0] * TS, (FLOOR_ROW - 2) * TS, len(CRATE_OBSTACLE_COLS) * TS, 2 * TS),
        ("Solid", 24 * TS, (FLOOR_ROW - 2) * TS, TS, 2 * TS),
        ("Platform", 10 * TS, BALCONY_ROW * TS, (24 - 10 + 1) * TS, TS),
        ("Platform", 28 * TS, BALCONY_ROW * TS, (42 - 28 + 1) * TS, TS),
        ("Platform", 4 * TS, 29 * TS, 2 * TS, TS),
        ("Platform", 7 * TS, 27 * TS, 2 * TS, TS),
        ("Platform", 44 * TS, 27 * TS, 2 * TS, TS),
        ("Platform", 47 * TS, 29 * TS, 2 * TS, TS),
        ("Solid", PEDESTAL_COL * TS, (FLOOR_ROW - 2) * TS, TS, 2 * TS),
    ]
    for row, c0, c1 in WEST_STEPS:
        rects.append(("Platform", c0 * TS, row * TS, (c1 - c0 + 1) * TS, TS))
    for row, c0, c1 in EAST_STEPS:
        rects.append(("Platform", c0 * TS, row * TS, (c1 - c0 + 1) * TS, TS))
    rects.append(("Platform", 44 * TS, LANDING_ROW * TS, 4 * TS, TS))
    for otype, x, y, w, h in rects:
        yield f'  <object id="{oid}" name="{otype}" type="{otype}" x="{x}" y="{y}" width="{w}" height="{h}"/>'
        oid += 1


# ── Objects (spawn, checkpoints, trigger, enemies, waypoints, lamps) ──
def _halcon_waypoints(cx, cy, owner, start_id):
    pts = [(cx - 48, cy), (cx, cy - 20), (cx + 48, cy), (cx, cy + 20)]
    entries = []
    for idx, (wx, wy) in enumerate(pts):
        entries.append(
            (start_id + idx, f"Waypoint_{owner}_{idx}", "Waypoint", wx, wy, 8, 8, {"owner_id": owner})
        )
    return entries


FLOOR_Y = FLOOR_ROW * TS
BALCONY_Y = BALCONY_ROW * TS


def _iter_objects():
    objs = []
    oid = 1

    objs.append((oid, "PlayerSpawn_01", "PlayerSpawn", 2 * TS, FLOOR_Y, 16, 16, {}))
    oid += 1

    # Pit under the balcony's own gap: box(24) -> platform(26) -> floor(28).
    # Falling in respawns at the last checkpoint instead of soft-locking.
    objs.append((oid, "DeathPit_hall", "DeathPit", PIT_COLS.start * TS, FLOOR_Y,
                 len(PIT_COLS) * TS, (MH - FLOOR_ROW) * TS, {}))
    oid += 1

    checkpoints = [
        (56 * TS, "0"),  # right before the final climb to the exit
    ]
    for x, cid in checkpoints:
        objs.append((oid, f"Checkpoint_{cid.zfill(2)}", "Checkpoint", x, FLOOR_Y - 32, 16, 32, {"checkpoint_id": cid}))
        oid += 1

    # Elevated exit — reached only by clearing the full end-of-hall gauntlet.
    objs.append((oid, "NextTrigger_01", "NextTrigger", DOOR_COL * TS, (LANDING_ROW - 2) * TS, 16, 64, {}))
    oid += 1

    # WalkerPalom x5 (floor) — first one placed past the crate obstacle
    # (col 6 / x=96) so it doesn't spawn inside solid geometry.
    for x in (176, 256, 480, 704, 832):
        objs.append((oid, f"WalkerPalom_{oid}", "WalkerPalom", x, FLOOR_Y - 32, 16, 32, {}))
        oid += 1

    # ShooterBuitre x2 (balcony)
    for x in (14 * TS, 34 * TS):
        objs.append((oid, f"ShooterBuitre_{oid}", "ShooterBuitre", x, BALCONY_Y - 32, 16, 32, {}))
        oid += 1

    # FlyingHalcon x6, patrolling the open flight band on closed Bezier loops
    # via CurveTools (flight_mode=bezier overrides the species' sine default).
    halcon = [(10 * TS, 16), (20 * TS, 18), (30 * TS, 14), (39 * TS, 18), (47 * TS, 16), (54 * TS, 18)]
    wp_id = 500
    for idx, (cx, row) in enumerate(halcon):
        cy = row * TS
        name = f"FlyingHalcon_{idx}"
        objs.append((oid, name, "FlyingHalcon", cx, cy, 16, 16, {"flight_mode": "bezier"}))
        oid += 1
        for wp in _halcon_waypoints(cx, cy, name, wp_id):
            objs.append(wp)
            wp_id += 4

    # NOTE: the two decorative SwingingLamp entities are NOT placed as TMX
    # objects. scripts/grade_stage.py (run standalone by CI, per
    # .github/workflows/ci.yml) analyzes TMX files without importing the
    # owning stage module, so it can never learn a stage-local
    # StageLoader.register_entity() type — an unknown object type makes its
    # playthrough analysis raise FrameworkUsageError and zeroes out
    # design_completable/geometry/pacing plus enemies_placed/valid_types for
    # the whole file. Hall.on_stage_start() instantiates them directly in
    # Python instead (see src/stages/hall/hall.py), the same
    # stage.entity_list.append() pattern StageScene itself uses for
    # boss-summoned minions.

    lines = []
    for oid, name, otype, x, y, w, h, props in objs:
        prop_str = ""
        if props:
            pxml = "".join(f'<property name="{k}" value="{v}"/>' for k, v in props.items())
            prop_str = f" <properties>{pxml}</properties>"
        lines.append(f'  <object id="{oid}" name="{name}" type="{otype}" x="{x}" y="{y}" width="{w}" height="{h}">{prop_str}</object>')
    return "\n".join(lines)


def generate_tmx():
    object_entries = _iter_objects()
    collision_entries = "\n".join(_iter_collision())

    tmx = f"""<?xml version="1.0" encoding="UTF-8"?>
<map version="1.10" tiledversion="1.12.2" orientation="orthogonal" renderorder="right-down" width="{MW}" height="{MH}" tilewidth="{TS}" tileheight="{TS}" infinite="0" nextlayerid="9" nextobjectid="700">
 <properties>
  <property name="stage_id" value="hall"/>
  <property name="stage_name" value="3-2  EL HALL"/>
  <property name="author" value="Jose Pablo Monestel Cruz"/>
  <property name="zone" type="int" value="3"/>
  <property name="time_limit" type="int" value="170"/>
  <property name="bgm_track" value="bgm_stage0"/>
  <property name="climate" value="clear"/>
  <property name="ambient_light" type="float" value="0.85"/>
 </properties>
 <tileset firstgid="1" name="tileset_gavilan_ciudad" tilewidth="{TS}" tileheight="{TS}" tilecount="{TILESET_TILECOUNT}" columns="{TILESET_COLUMNS}">
  <image source="{TILESET_IMAGE_REL_PATH}" width="{TILESET_IMG_W}" height="{TILESET_IMG_H}"/>
 </tileset>
 <layer id="1" name="BG_Far" width="{MW}" height="{MH}">
  <data encoding="csv">
{_grid_to_csv(bg_far)}
  </data>
 </layer>
 <layer id="2" name="BG_Mid" width="{MW}" height="{MH}">
  <data encoding="csv">
{_grid_to_csv(bg_mid)}
  </data>
 </layer>
 <layer id="3" name="BG_Near" width="{MW}" height="{MH}">
  <data encoding="csv">
{_grid_to_csv(bg_near)}
  </data>
 </layer>
 <layer id="4" name="Terrain" width="{MW}" height="{MH}">
  <data encoding="csv">
{_grid_to_csv(terrain)}
  </data>
 </layer>
 <layer id="5" name="Terrain_Detail" width="{MW}" height="{MH}">
  <data encoding="csv">
{_grid_to_csv(terrain_detail)}
  </data>
 </layer>
 <objectgroup id="7" name="Collision">
{collision_entries}
 </objectgroup>
 <objectgroup id="6" name="Objects">
{object_entries}
 </objectgroup>
 <layer id="8" name="FG_Overlay" width="{MW}" height="{MH}">
  <data encoding="csv">
{_grid_to_csv(fg_overlay)}
  </data>
 </layer>
</map>"""

    TMX_PATH.parent.mkdir(parents=True, exist_ok=True)
    TMX_PATH.write_text(tmx, encoding="utf-8")
    print(f"Created Hall TMX: {TMX_PATH}")
    print(f"  Map: {MW}x{MH} tiles ({MW * TS}x{MH * TS} px)")
    print("  Enemies: 5 WalkerPalom, 2 ShooterBuitre, 6 FlyingHalcon (bezier)")
    print("  Checkpoints: 1 (before the gauntlet), elevated NextTrigger + sealed-door marker, SwingingLamp: 2")


if __name__ == "__main__":
    generate_tmx()
