#!/usr/bin/env python3
"""Generate tileset_gavilan_ciudad.png — procedural pixel art for Stage 3-2
"El Hall" (Zona 3, Sede Heredia).

Follows the same approach as _gen_tileset_stage0() in
tools/pixel_asset_generator.py: NVG/Castlevania-style, fixed 16-color
palette, simple flat fills + borders + speckle noise, drawn per-tile with
PIL. 60 tiles, 16x16px, 8 columns — matches assets/tileset_gavilan_ciudad.tsx
tile-by-tile (same order, same names).

Mood: dark stone hall (per the approved gothic-hall reference image) kept
close enough to the documented Zone 3 palette (docs/16_WORLD_DESIGN.md
"warm stone beige, cool interior shadow, gold afternoon light") that the
skylights still read as sunlit rather than fully nocturnal.
"""
from __future__ import annotations

import random
from pathlib import Path

from PIL import Image, ImageDraw

PROJECT_ROOT = Path(__file__).resolve().parent.parent
OUT_PATH = PROJECT_ROOT / "assets" / "tilesets" / "tileset_gavilan_ciudad.png"

TS = 16
COLS = 8
SHEET_W, SHEET_H = 128, 128

random.seed(20260)

# ── palette (indices only used for readability in comments below) ──
C = {
    "stone_dark": (46, 42, 58),
    "stone_mid": (74, 68, 90),
    "stone_light": (112, 104, 130),
    "stone_hi": (152, 144, 172),
    "mortar": (28, 24, 38),
    "gold": (230, 188, 108),
    "gold_dim": (150, 112, 58),
    "gold_soft": (240, 210, 150),
    "glass": (210, 210, 232),
    "glass_dim": (150, 150, 182),
    "metal": (58, 52, 66),
    "metal_hi": (96, 90, 106),
    "wood": (86, 60, 40),
    "wood_dark": (58, 40, 26),
    "banner": (108, 30, 58),
    "banner_dark": (70, 18, 38),
    "banner_trim": (198, 158, 70),
    "crack": (20, 16, 26),
    "sky_far": (74, 68, 104),
    "sky_far2": (58, 54, 88),
    "sky_mid": (86, 78, 118),
    "sky_mid2": (66, 62, 100),
    "sky_near": (100, 90, 132),
    "sky_near2": (78, 72, 112),
    "window_lit": (238, 200, 120),
}

TILE_NAMES = [
    "suelo_sup", "suelo_rel", "muro", "muro_sup", "panel", "zocalo", "techo", "columna",
    "plat_izq", "plat_med", "plat_der", "plat_sola", "reja", "tuberia_h", "tuberia_v", "luz_suelo",
    "lej_cuerpo", "lej_cuerpo2", "lej_luz", "lej_luz2", "lej_sup", "lej_sup_caseton", "lej_sup_antena", "lej_deposito",
    "med_cuerpo", "med_cuerpo2", "med_luz", "med_luz2", "med_sup", "med_sup_caseton", "med_sup_antena", "med_deposito",
    "cer_cuerpo", "cer_cuerpo2", "cer_luz", "cer_luz2", "cer_sup", "cer_sup_caseton", "cer_sup_antena", "cer_deposito",
    "parteluz_v", "travesano_h", "cruce", "marco_izq", "marco_der", "marco_sup", "alfeizar", "brillo",
    "grieta_1", "grieta_2", "mancha", "brillo_suave", "bruma_lej", "bruma_med", "cortina_izq", "cortina_der",
    "lampara", "cuadro", "caja", "muro_fondo",
]

img = Image.new("RGBA", (SHEET_W, SHEET_H), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)


def _origin(idx: int) -> tuple[int, int]:
    return (idx % COLS) * TS, (idx // COLS) * TS


def fill(idx: int, color: tuple[int, int, int]) -> None:
    x0, y0 = _origin(idx)
    draw.rectangle([x0, y0, x0 + TS - 1, y0 + TS - 1], fill=color)


def border(idx: int, color: tuple[int, int, int]) -> None:
    x0, y0 = _origin(idx)
    draw.rectangle([x0, y0, x0 + TS - 1, y0 + TS - 1], outline=color)


def speckle(idx: int, colors: list[tuple[int, int, int]], count: int) -> None:
    x0, y0 = _origin(idx)
    for _ in range(count):
        x = x0 + random.randint(0, TS - 1)
        y = y0 + random.randint(0, TS - 1)
        draw.point((x, y), fill=random.choice(colors))


def hline(idx: int, y: int, color: tuple[int, int, int], x0: int = 0, x1: int = TS - 1) -> None:
    ox, oy = _origin(idx)
    draw.line([(ox + x0, oy + y), (ox + x1, oy + y)], fill=color)


def vline(idx: int, x: int, color: tuple[int, int, int], y0: int = 0, y1: int = TS - 1) -> None:
    ox, oy = _origin(idx)
    draw.line([(ox + x, oy + y0), (ox + x, oy + y1)], fill=color)


def rect(idx: int, box: tuple[int, int, int, int], color: tuple[int, int, int], fill_it: bool = True) -> None:
    ox, oy = _origin(idx)
    x0, y0, x1, y1 = box
    if fill_it:
        draw.rectangle([ox + x0, oy + y0, ox + x1, oy + y1], fill=color)
    else:
        draw.rectangle([ox + x0, oy + y0, ox + x1, oy + y1], outline=color)


def ellipse(idx: int, box: tuple[int, int, int, int], color: tuple[int, int, int]) -> None:
    ox, oy = _origin(idx)
    x0, y0, x1, y1 = box
    draw.ellipse([ox + x0, oy + y0, ox + x1, oy + y1], fill=color)


def i(name: str) -> int:
    return TILE_NAMES.index(name)


# ── structural (solid) ──────────────────────────────────────────

# suelo_sup: floor top surface — light stone slab, bright top edge, mortar seam
fill(i("suelo_sup"), C["stone_light"])
speckle(i("suelo_sup"), [C["stone_mid"], C["stone_hi"]], 10)
hline(i("suelo_sup"), 0, C["stone_hi"])
hline(i("suelo_sup"), 1, C["stone_hi"])
hline(i("suelo_sup"), 8, C["mortar"])
vline(i("suelo_sup"), 8, C["mortar"], 9, 15)

# suelo_rel: floor relief — darker slab variant with a groove
fill(i("suelo_rel"), C["stone_mid"])
speckle(i("suelo_rel"), [C["stone_dark"], C["stone_light"]], 10)
hline(i("suelo_rel"), 0, C["stone_light"])
hline(i("suelo_rel"), 6, C["mortar"])

# muro: wall — mid stone with brick mortar grid
fill(i("muro"), C["stone_mid"])
hline(i("muro"), 5, C["mortar"])
hline(i("muro"), 11, C["mortar"])
vline(i("muro"), 4, C["mortar"], 0, 5)
vline(i("muro"), 12, C["mortar"], 0, 5)
vline(i("muro"), 8, C["mortar"], 6, 11)
vline(i("muro"), 0, C["mortar"], 12, 15)
vline(i("muro"), 8, C["mortar"], 12, 15)
speckle(i("muro"), [C["stone_dark"], C["stone_light"]], 6)

# muro_sup: wall top cap — darker band with highlight lip
fill(i("muro_sup"), C["stone_dark"])
rect(i("muro_sup"), (0, 0, 15, 3), C["stone_hi"])
hline(i("muro_sup"), 4, C["mortar"])
speckle(i("muro_sup"), [C["stone_mid"]], 6)

# panel: decorative inset wall panel
fill(i("panel"), C["stone_mid"])
rect(i("panel"), (2, 2, 13, 13), C["stone_dark"])
rect(i("panel"), (2, 2, 13, 13), C["gold_dim"], fill_it=False)
rect(i("panel"), (4, 4, 11, 11), C["stone_light"], fill_it=False)

# zocalo: baseboard — dark strip, bright top lip
fill(i("zocalo"), C["stone_dark"])
hline(i("zocalo"), 0, C["stone_hi"])
hline(i("zocalo"), 1, C["stone_light"])
speckle(i("zocalo"), [C["stone_mid"]], 8)

# techo: ceiling — dark stone with beam lines
fill(i("techo"), C["stone_dark"])
hline(i("techo"), 15, C["mortar"])
vline(i("techo"), 3, C["mortar"], 0, 15)
vline(i("techo"), 12, C["mortar"], 0, 15)
speckle(i("techo"), [C["stone_mid"]], 6)

# columna: column shaft — fluted vertical stone
fill(i("columna"), C["stone_light"])
vline(i("columna"), 2, C["stone_dark"])
vline(i("columna"), 6, C["stone_hi"])
vline(i("columna"), 9, C["stone_dark"])
vline(i("columna"), 13, C["stone_hi"])
vline(i("columna"), 0, C["mortar"])
vline(i("columna"), 15, C["mortar"])

# ── platforms (balcony / stairs) ────────────────────────────────

def _platform_top(idx: int) -> None:
    fill(idx, C["stone_light"])
    hline(idx, 0, C["gold"])
    hline(idx, 1, C["gold_dim"])
    hline(idx, 5, C["mortar"])
    speckle(idx, [C["stone_mid"], C["stone_hi"]], 6)


_platform_top(i("plat_izq"))
rect(i("plat_izq"), (0, 0, 2, 15), C["stone_dark"])
vline(i("plat_izq"), 0, C["gold_dim"], 0, 4)

_platform_top(i("plat_med"))

_platform_top(i("plat_der"))
rect(i("plat_der"), (13, 0, 15, 15), C["stone_dark"])
vline(i("plat_der"), 15, C["gold_dim"], 0, 4)

_platform_top(i("plat_sola"))
rect(i("plat_sola"), (0, 0, 2, 15), C["stone_dark"])
rect(i("plat_sola"), (13, 0, 15, 15), C["stone_dark"])

# reja: railing — vertical dark bars over transparent gaps
for x in (2, 5, 8, 11, 14):
    vline(i("reja"), x, C["metal"], 0, 12)
hline(i("reja"), 0, C["metal_hi"], 0, 15)
hline(i("reja"), 12, C["metal_hi"], 0, 15)

# tuberia_h / tuberia_v: pipes
rect(i("tuberia_h"), (0, 6, 15, 9), C["metal"])
hline(i("tuberia_h"), 6, C["metal_hi"])
hline(i("tuberia_h"), 9, C["mortar"])

rect(i("tuberia_v"), (6, 0, 9, 15), C["metal"])
vline(i("tuberia_v"), 6, C["metal_hi"])
vline(i("tuberia_v"), 9, C["mortar"])

# luz_suelo: warm light pool on the floor
fill(i("luz_suelo"), C["stone_light"])
ellipse(i("luz_suelo"), (1, 5, 14, 15), C["gold_soft"])
ellipse(i("luz_suelo"), (4, 7, 11, 13), C["gold"])

# ── parallax skyline (far / mid / near) ─────────────────────────

def _skyline_set(prefix: str, base: tuple[int, int, int], base2: tuple[int, int, int], lit: tuple[int, int, int]) -> None:
    # cuerpo: building body block
    fill(i(f"{prefix}_cuerpo"), base)
    for y in range(0, 16, 4):
        hline(i(f"{prefix}_cuerpo"), y, base2)
    # cuerpo2: alternate body, slightly darker
    fill(i(f"{prefix}_cuerpo2"), base2)
    for y in range(2, 16, 4):
        hline(i(f"{prefix}_cuerpo2"), y, base)
    # luz / luz2: lit window dots on the body tone
    fill(i(f"{prefix}_luz"), base)
    for gx, gy in ((3, 3), (9, 3), (3, 9), (9, 9)):
        rect(i(f"{prefix}_luz"), (gx, gy, gx + 1, gy + 1), lit)
    fill(i(f"{prefix}_luz2"), base2)
    for gx, gy in ((5, 5), (11, 2), (2, 11)):
        rect(i(f"{prefix}_luz2"), (gx, gy, gx + 1, gy + 1), lit)
    # sup: roofline — body below, sky above (transparent)
    x0, y0 = _origin(i(f"{prefix}_sup"))
    draw.rectangle([x0, y0 + 6, x0 + 15, y0 + 15], fill=base)
    hline(i(f"{prefix}_sup"), 6, base2)
    # sup_caseton: roofline with a notch/parapet
    x0, y0 = _origin(i(f"{prefix}_sup_caseton"))
    draw.rectangle([x0, y0 + 8, x0 + 15, y0 + 15], fill=base)
    draw.rectangle([x0 + 2, y0 + 4, x0 + 6, y0 + 15], fill=base)
    draw.rectangle([x0 + 10, y0 + 4, x0 + 13, y0 + 15], fill=base)
    # sup_antena: roofline with a thin antenna/spire
    x0, y0 = _origin(i(f"{prefix}_sup_antena"))
    draw.rectangle([x0, y0 + 7, x0 + 15, y0 + 15], fill=base)
    draw.line([(x0 + 8, y0), (x0 + 8, y0 + 7)], fill=base2)
    # deposito: blocky tank/silo shape
    fill(i(f"{prefix}_deposito"), base2)
    rect(i(f"{prefix}_deposito"), (3, 2, 12, 15), base)
    hline(i(f"{prefix}_deposito"), 2, base2)


_skyline_set("lej", C["sky_far"], C["sky_far2"], (150, 140, 180))
_skyline_set("med", C["sky_mid"], C["sky_mid2"], (200, 180, 160))
_skyline_set("cer", C["sky_near"], C["sky_near2"], C["window_lit"])

# ── window elements ──────────────────────────────────────────────

# parteluz_v / travesano_h / cruce: window mullions on glass
fill(i("parteluz_v"), C["glass"])
vline(i("parteluz_v"), 7, C["stone_dark"])
vline(i("parteluz_v"), 8, C["stone_dark"])

fill(i("travesano_h"), C["glass"])
hline(i("travesano_h"), 7, C["stone_dark"])
hline(i("travesano_h"), 8, C["stone_dark"])

fill(i("cruce"), C["glass"])
vline(i("cruce"), 7, C["stone_dark"])
vline(i("cruce"), 8, C["stone_dark"])
hline(i("cruce"), 7, C["stone_dark"])
hline(i("cruce"), 8, C["stone_dark"])

# marco_izq / marco_der: vertical frame posts
fill(i("marco_izq"), C["stone_dark"])
rect(i("marco_izq"), (10, 0, 15, 15), C["glass"])
vline(i("marco_izq"), 9, C["stone_hi"])

fill(i("marco_der"), C["stone_dark"])
rect(i("marco_der"), (0, 0, 5, 15), C["glass"])
vline(i("marco_der"), 6, C["stone_hi"])

# marco_sup: arched top
fill(i("marco_sup"), C["stone_dark"])
draw_ = _origin(i("marco_sup"))
draw.ellipse([draw_[0] + 1, draw_[1] + 6, draw_[0] + 14, draw_[1] + 22], fill=C["glass"])
rect(i("marco_sup"), (0, 0, 15, 6), C["stone_dark"])
hline(i("marco_sup"), 5, C["stone_hi"])

# alfeizar: windowsill ledge
fill(i("alfeizar"), C["stone_mid"])
rect(i("alfeizar"), (0, 0, 15, 4), C["stone_light"])
hline(i("alfeizar"), 4, C["mortar"])
rect(i("alfeizar"), (0, 10, 15, 15), C["stone_dark"])

# ── light / wear / atmosphere accents (small marks on transparent bg) ──

ellipse(i("brillo"), (5, 5, 10, 10), C["gold"])
ellipse(i("brillo"), (6, 6, 9, 9), C["gold_soft"])

vline(i("grieta_1"), 6, C["crack"], 2, 8)
vline(i("grieta_1"), 7, C["crack"], 8, 13)
vline(i("grieta_1"), 8, C["crack"], 4, 9)

vline(i("grieta_2"), 9, C["crack"], 3, 7)
vline(i("grieta_2"), 8, C["crack"], 7, 11)
vline(i("grieta_2"), 10, C["crack"], 9, 14)

ellipse(i("mancha"), (3, 8, 13, 15), (24, 22, 18))

ellipse(i("brillo_suave"), (4, 4, 11, 11), (110, 100, 80))

rect(i("bruma_lej"), (0, 0, 15, 15), (90, 88, 110))
rect(i("bruma_med"), (0, 0, 15, 15), (78, 74, 100))

# ── curtains ─────────────────────────────────────────────────────

fill(i("cortina_izq"), C["banner"])
for x in (2, 5, 8, 11, 14):
    vline(i("cortina_izq"), x, C["banner_dark"], 0, 15)
hline(i("cortina_izq"), 0, C["banner_trim"])

fill(i("cortina_der"), C["banner"])
for x in (1, 4, 7, 10, 13):
    vline(i("cortina_der"), x, C["banner_dark"], 0, 15)
hline(i("cortina_der"), 0, C["banner_trim"])

# ── props ────────────────────────────────────────────────────────

# lampara: hanging candle fixture
vline(i("lampara"), 8, C["metal"], 0, 4)
rect(i("lampara"), (4, 4, 11, 8), C["metal"])
ellipse(i("lampara"), (6, 1, 9, 4), C["gold"])
ellipse(i("lampara"), (5, 5, 10, 9), C["gold_dim"])

# cuadro: framed painting
fill(i("cuadro"), C["wood_dark"])
rect(i("cuadro"), (2, 2, 13, 13), (60, 52, 70))
rect(i("cuadro"), (2, 2, 13, 13), C["gold_dim"], fill_it=False)
rect(i("cuadro"), (5, 5, 10, 10), (90, 60, 60))

# caja: wooden crate
fill(i("caja"), C["wood"])
rect(i("caja"), (0, 0, 15, 15), C["wood_dark"], fill_it=False)
draw.line([_origin(i("caja"))[0], _origin(i("caja"))[1], _origin(i("caja"))[0] + 15, _origin(i("caja"))[1] + 15], fill=C["wood_dark"])
draw.line([_origin(i("caja"))[0] + 15, _origin(i("caja"))[1], _origin(i("caja"))[0], _origin(i("caja"))[1] + 15], fill=C["wood_dark"])

# muro_fondo: flat background wall, less detail than muro
fill(i("muro_fondo"), C["stone_dark"])
speckle(i("muro_fondo"), [C["stone_mid"]], 5)

img.save(OUT_PATH)
print(f"Wrote {OUT_PATH} ({SHEET_W}x{SHEET_H}, {len(TILE_NAMES)} tiles)")
