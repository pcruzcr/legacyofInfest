﻿"""
Module: stage2_1_oficinas
System: src.stages.stage2_1_oficinas
Description: Zona 2 (Distrito Central) - Oficinas.
Escenario horizontal de recorrido y combate contra guardias a pie
(Walker / Charger / Brute). Sin jefe.
"""
from __future__ import annotations

from pathlib import Path

from src.framework.scenes.stage_scene import StageScene


class Stage21Oficinas(StageScene):
    TMX_PATH: Path = Path(__file__).parent / "stage2_1_oficinas.tmx"
    ZONE: int = 2
