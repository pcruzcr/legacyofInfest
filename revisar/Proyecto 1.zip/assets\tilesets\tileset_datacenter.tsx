<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="tileset_datacenter" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="tileset_datacenter.png" width="128" height="128"/>
</tileset>
