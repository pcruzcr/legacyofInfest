# Evaluación Práctica I — Stage 2-2 "Entrada y Antenas"

**Estudiante:** César Ubáu Calvo · **`assignment_id`:** `stage2_2`
**Asignación:** Zona 2, sub-zona 1 — Entrada y Antenas

---

## Dónde va cada archivo

Las rutas replican las del repositorio: copiar respetando la estructura desde
la raíz del proyecto.

| Archivo | Nota |
|---|---|
| `src/stages/stage2_2/stage2_2.py` | Clase `Stage2_2(StageScene)` |
| `src/stages/stage2_2/camara_seguridad.py` | Unidad II — matemática vectorial |
| `src/stages/stage2_2/patrulla_bspline.py` | Unidad III — curva B-Spline |
| `src/stages/stage2_2/atmosfera.py` | Unidad V — espacios de color |
| `src/stages/stage2_2/__init__.py` | — |
| `src/stages/stage2_2/README.md` | **Documentación académica + hoja de trabajo** |
| `assets/maps/stage2_2/stage2_2.tmx` | Mapa 120 × 50, 8 capas, 50 objetos |
| `student_assets/tilesets/tileset_parqueo.png` | **Tileset propio**, 128 tiles de 16 × 16 |
| `assets/tilesets/tileset_datacenter_ext.png` | Provisto por el curso. Se incluye solo para que el `.tmx` abra en Tiled desde esta carpeta |

## Cómo ejecutar

```powershell
python main.py --stage stage2_2
```

Modo de pruebas (enemigos visibles pero sin daño):

```powershell
$env:LOI_SIN_ENEMIGOS=1
python main.py --stage stage2_2
```

## Cómo verificar

```powershell
python scripts\validate_tmx.py assets\maps\stage2_2\stage2_2.tmx
python scripts\grade_stage.py assets\maps\stage2_2\stage2_2.tmx
```

`validate_tmx.py`: 1/1 passed · `grade_stage.py`: **129/130 (99.2 %)**

Sin errores ni advertencias en consola durante 900 fotogramas de ejecución.
